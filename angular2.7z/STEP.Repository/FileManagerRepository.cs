﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using STEP.Interfaces;
using STEP.Repository.Interfaces;
using STEP.Models;

namespace STEP.Repository
{
    public class FileManagerRepository : IFileManagerRepository
    {
        #region Variables

        private const string snFolderPath = "FileManagerFolderPath",
                             snPostBack = "FileManagerPostBackData",
                             snPageIndex = "FileManagerPageIndex";

        private const string cFileFormat = "{0:#,### bytes}", cDateFormat = "{0:MM/dd/yyyy hh:mm tt}";

        private const string cDownload = "Download",
                             cNavigate = "Navigate",
                             cUp = "Up",
                             cUpload = "Upload",
                             cDelete = "Delete";

        private const string cImgFolder = "~/images/folder.png",
                             cImgXML = "~/images/xml.png",
                             cImgOther = "~/images/otherfile.png";

        private const string cFolder = "Folder",
                             cXML = "XML File",
                             cOther = "Other File",
                             cTrue = "True",
                             cDot = ".",
                             cDotXML = ".xml";

        private const string cFileTip = "Please click to download the file.",
                             cFolderTip = "Please click to view the contents of the folder.";

        private const char cSlash = '\\';

        #endregion

        public ICollection<FileManagerDetails> GetFolderFiles(FileManagerSearchFilter objFileManagerSearchFilter)
        {
            ICollection<FileManagerDetails> objFilesInfo = new List<FileManagerDetails>();
            try
            {
                DirectoryInfo directoryInfo;
                FileInfo fileInfo;
                if (!string.IsNullOrEmpty(objFileManagerSearchFilter.FullName) &&
                    objFileManagerSearchFilter.FullName.StartsWith("~/"))
                {
                    objFileManagerSearchFilter.FullName =
                        HttpContext.Current.Server.MapPath(objFileManagerSearchFilter.FullName.Trim());
                }
                string SFolderPath = string.IsNullOrEmpty(objFileManagerSearchFilter.FullName)
                                         ? STEP.Common.AppConfig.FileURL
                                         : objFileManagerSearchFilter.FullName.Trim();
                foreach (string directory in Directory.GetDirectories(SFolderPath))
                {
                    directoryInfo = new DirectoryInfo(directory);
                    objFilesInfo.Add(new FileManagerDetails
                        {
                            IconUrl = cImgFolder,
                            FullName = directoryInfo.FullName + cSlash,
                            Name = directoryInfo.Name,
                            Type = cFolder,
                            LastModified = string.Format(cDateFormat, directoryInfo.LastWriteTime),
                        });
                }

                foreach (string file in Directory.GetFiles(SFolderPath))
                {
                    fileInfo = new FileInfo(file);
                    if (!fileInfo.Name.Contains(cDot) ||
                        fileInfo.Name.EndsWith(cDotXML, StringComparison.OrdinalIgnoreCase))
                    {
                        objFilesInfo.Add(new FileManagerDetails
                            {
                                IconUrl = cImgXML,
                                FullName = fileInfo.FullName,
                                Name = fileInfo.Name,
                                Type = cXML,
                                LastModified = string.Format(cDateFormat, fileInfo.LastWriteTime),
                                FileSize = string.Format(cFileFormat, fileInfo.Length)
                            });
                    }
                    else
                    {
                        objFilesInfo.Add(new FileManagerDetails
                            {
                                IconUrl = cImgOther,
                                FullName = fileInfo.FullName,
                                Name = fileInfo.Name,
                                Type = cOther,
                                LastModified = string.Format(cDateFormat, fileInfo.LastWriteTime),
                                FileSize = string.Format(cFileFormat, fileInfo.Length)
                            });

                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            return objFilesInfo;
        }

        public ICollection<FileManagerDetails> GetSearchFiles(FileManagerSearchFilter objFileManagerSearchFilter)
        {
            ICollection<FileManagerDetails> objFilesInfo = GetFolderFiles(objFileManagerSearchFilter);
            return objFilesInfo.Where(x =>
                                      (string.IsNullOrEmpty(objFileManagerSearchFilter.FileName) ||
                                       x.Name.ToLower().Contains(objFileManagerSearchFilter.FileName.ToLower().Trim())) &&
                                      (string.IsNullOrEmpty(objFileManagerSearchFilter.LastModified) ||
                                       x.LastModified.ToLower()
                                        .Contains(objFileManagerSearchFilter.LastModified.ToLower().Trim()))
                //&&(string.IsNullOrEmpty(objFileManagerSearchFilter.FullName) || x.FullName.ToLower().Contains(objFileManagerSearchFilter.FullName.ToLower().Trim()))
                ).ToList();
            //return objFilesInfo;
        }

        public string uploadFileManagerDocument(Document filedocument)
        {
            Document newdocument = null;
            var objFolder = new AppFolderConnect();
            if (!string.IsNullOrEmpty(filedocument.FileContent))
            {
                newdocument = new Document
                    {
                        FileContent = filedocument.FileContent,
                        FilePath = filedocument.FilePath,
                        FileType = filedocument.FileType,
                        Name = filedocument.Name
                    };
            }
            return objFolder.UploadDocument(newdocument);
        }
    }
}
