using System.Data.Entity;
using STEP.Models;

namespace STEP.Repository
{
    public partial class STEPContext : DbContext
    {
        /*static STEPContext()
      {
          Database.SetInitializer<STEPContext>(null);
      }

        public STEPContext()
            : base("Name=STEPContext")
      {
      }*/
        public DbSet<Action> Actions { get; set; }
        public DbSet<AMSCO> AMSCOs { get; set; }
        public DbSet<Approval_Process> Approval_Process { get; set; }
        public DbSet<Approval_Process_Email_Config> Approval_Process_Email_Config { get; set; }
        public DbSet<Audit> Audits { get; set; }
        public DbSet<Audit_Details> Audit_Details { get; set; }
        public DbSet<Audit_Display> Audit_Display { get; set; }
        public DbSet<Catalog> Catalogs { get; set; }
        public DbSet<Catalog_AMSCO> Catalog_AMSCO { get; set; }
        public DbSet<Catalog_Questions> Catalog_Questions { get; set; }
        public DbSet<Code> Codes { get; set; }
        public DbSet<Code_Value> Code_Value { get; set; }
        public DbSet<Fiscal_Year> Fiscal_Year { get; set; }
        public DbSet<MDEP> MDEP { get; set; }
        public DbSet<Hierarchy_Data> Hierarchy_Data { get; set; }
        public DbSet<Pillar_LawReg_Mapping> Pillar_LawReg_Mapping { get; set; }
        public DbSet<Pillar_PB28_Mapping> Pillar_PB28_Mapping { get; set; }
        public DbSet<Project> Project { get; set; }
        public DbSet<Project_Answer> Project_Answer { get; set; }
        public DbSet<Help_Documents> Help_Documents { get; set; }
        public DbSet<Project_Document> Project_Document { get; set; }
        public DbSet<Project_Funding> Project_Funding { get; set; }
        public DbSet<Project_Note> Project_Note { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Role_Action> Role_Action { get; set; }
        public DbSet<Role_Invitation_Mapping> Role_Invitation_Mapping { get; set; }
        public DbSet<User_Preference> User_Preference { get; set; }
        public DbSet<User_Role> User_Role { get; set; }
        public DbSet<User_Role_Hierarchy_Assoication> User_Role_Hierarchy_Assoication { get; set; }
        public DbSet<User_Role_Pillar_Association> User_Role_Pillar_Association { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<User_Audit> User_Audit { get; set; }
        public DbSet<Hierarchy_Data_Planning> Hierarchy_Data_Planning { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new ActionMap());
            modelBuilder.Configurations.Add(new AMSCOMap());
            modelBuilder.Configurations.Add(new Approval_ProcessMap());
            modelBuilder.Configurations.Add(new Approval_Process_Email_ConfigMap());
            modelBuilder.Configurations.Add(new User_AuditMap());
            modelBuilder.Configurations.Add(new CatalogMap());
            modelBuilder.Configurations.Add(new Catalog_AMSCOMap());
            modelBuilder.Configurations.Add(new Catalog_QuestionsMap());
            modelBuilder.Configurations.Add(new CodeMap());
            modelBuilder.Configurations.Add(new Code_ValueMap());
            modelBuilder.Configurations.Add(new Fiscal_YearMap());
            modelBuilder.Configurations.Add(new MDEPMap());
            modelBuilder.Configurations.Add(new Hierarchy_DataMap());
            modelBuilder.Configurations.Add(new Pillar_LawReg_MappingMap());
            modelBuilder.Configurations.Add(new Pillar_PB28_MappingMap());
            modelBuilder.Configurations.Add(new ProjectMap());
            modelBuilder.Configurations.Add(new Project_AnswerMap());
            modelBuilder.Configurations.Add(new AuditMap());
            modelBuilder.Configurations.Add(new Audit_DetailsMap());
            modelBuilder.Configurations.Add(new Audit_DisplayMap());
            modelBuilder.Configurations.Add(new Project_DocumentMap());
            modelBuilder.Configurations.Add(new Project_FundingMap());
            modelBuilder.Configurations.Add(new Project_NoteMap());
            modelBuilder.Configurations.Add(new Help_DocumentsMap());
            modelBuilder.Configurations.Add(new RoleMap());
            modelBuilder.Configurations.Add(new Role_ActionMap());
            modelBuilder.Configurations.Add(new Role_Invitation_MappingMap());
            modelBuilder.Configurations.Add(new User_PreferenceMap());
            modelBuilder.Configurations.Add(new User_RoleMap());
            modelBuilder.Configurations.Add(new User_Role_Hierarchy_AssoicationMap());
            modelBuilder.Configurations.Add(new User_Role_Pillar_AssociationMap());
            modelBuilder.Configurations.Add(new UserMap());
            modelBuilder.Configurations.Add(new Hierarchy_Data_PlanningMap());
        }
    }
}
