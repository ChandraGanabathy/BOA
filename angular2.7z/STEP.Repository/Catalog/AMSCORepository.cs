﻿using STEP.Models;

namespace STEP.Repository
{
    public class AMSCORepository : EntityBaseRepository<AMSCO>, IAMSCORepository
    {
        public AMSCORepository(STEPContext context)
            : base(context)
        {

        }
    }
}
