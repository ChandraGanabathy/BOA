﻿using System;
using System.Data.Entity;
using System.Linq;
using STEP.Common;
using STEP.Models;

namespace STEP.Repository
{
    public class CatalogRepository : EntityBaseRepository<Catalog>, ICatalogRepository
    {
        public readonly STEPContext Context;

        public CatalogRepository(STEPContext context)
            : base(context)
        {
            Context = context;
        }

        public Catalog CreateUpdateCatalog(Catalog catalog)
        {


            // Insert catalog Info
            if (catalog != null)
            {
                if (catalog.Pillar_LawReg_Mapping != null && catalog.Pillar_Lawreg_Mapping_Id == 0)
                {
                    catalog.Pillar_LawReg_Mapping.Pillar_Id = AppConstants.CodeCategories.Pillar;
                    catalog.Pillar_LawReg_Mapping.LawReg_Id = AppConstants.CodeCategories.LawReg;
                    catalog.Pillar_LawReg_Mapping.ProgramArea_Id = AppConstants.CodeCategories.ProgramArea;
                    catalog.Pillar_LawReg_Mapping.Created_By = GetLoggedUserInfo();
                    catalog.Pillar_LawReg_Mapping.Created_Date = DateTime.UtcNow;
                    catalog.Pillar_LawReg_Mapping.Modified_By = GetLoggedUserInfo();
                    catalog.Pillar_LawReg_Mapping.Modified_Date = DateTime.UtcNow;
                }
                else
                {
                    catalog.Pillar_LawReg_Mapping = null;
                }
                if (catalog.Pillar_PB28_Mapping != null && catalog.Pillar_PB28_Mapping_Id == 0)
                {
                    catalog.Pillar_PB28_Mapping.Pillar_Id = AppConstants.CodeCategories.Pillar;
                    catalog.Pillar_PB28_Mapping.Title_Id = AppConstants.CodeCategories.PB28Title;
                    catalog.Pillar_PB28_Mapping.Category_Id = AppConstants.CodeCategories.PB28Category;
                    catalog.Pillar_PB28_Mapping.SubCategory_Id = AppConstants.CodeCategories.PB28SubCategory;
                    catalog.Pillar_PB28_Mapping.Created_By = GetLoggedUserInfo();
                    catalog.Pillar_PB28_Mapping.Created_Date = DateTime.UtcNow;
                    catalog.Pillar_PB28_Mapping.Modified_By = GetLoggedUserInfo();
                    catalog.Pillar_PB28_Mapping.Modified_Date = DateTime.UtcNow;
                }
                else
                {
                    catalog.Pillar_PB28_Mapping = null;
                }

                if (catalog.Id == 0)
                {
                    catalog.Created_By = GetLoggedUserInfo();
                    catalog.Created_Date = DateTime.UtcNow;
                    catalog.Modified_By = GetLoggedUserInfo();
                    catalog.Modified_Date = DateTime.UtcNow;

                    catalog.Status_Id = AppConstants.CodeCategories.Status;
                    catalog.Class_Id = AppConstants.CodeCategories.Class;


                    if (catalog.Catalog_Questions != null)
                    {
                        catalog.Catalog_Questions.ToList().ForEach(cq =>
                            {
                                cq.Answer_Type_Id = AppConstants.CodeCategories.AnswerType;
                                cq.Created_By = GetLoggedUserInfo();
                                cq.Created_Date = DateTime.UtcNow;
                                cq.Modified_By = GetLoggedUserInfo();
                                cq.Modified_Date = DateTime.UtcNow;
                            });
                    }

                    if (catalog.Catalog_AMSCO != null)
                    {
                        catalog.Catalog_AMSCO.ToList().ForEach(ca =>
                            {
                                ca.Created_By = GetLoggedUserInfo();
                                ca.Created_Date = DateTime.UtcNow;
                                ca.Modified_By = GetLoggedUserInfo();
                                ca.Modified_Date = DateTime.UtcNow;
                            });
                    }

                    this.Add(catalog);
                    this.Commit();

                }

                    // Update catalog Info
                else
                {
                    if (catalog != null)
                    {
                        var dbcatalog = GetSingle(x => x.Id == catalog.Id, x => x.Catalog_Questions,
                                                  x => x.Catalog_AMSCO);

                        dbcatalog.Catalog_Narrative = catalog.Catalog_Narrative;
                        dbcatalog.Catalog_Name = catalog.Catalog_Name;
                        dbcatalog.Pillar_Lawreg_Mapping_Id = catalog.Pillar_Lawreg_Mapping_Id;
                        dbcatalog.Pillar_PB28_Mapping_Id = catalog.Pillar_PB28_Mapping_Id;
                        dbcatalog.Status_Key = catalog.Status_Key;
                        dbcatalog.Class_Key = catalog.Class_Key;

                        catalog.Status_Id = AppConstants.CodeCategories.Status;
                        catalog.Class_Id = AppConstants.CodeCategories.Class;
                        catalog.Created_By = dbcatalog.Created_By;
                        catalog.Created_Date = dbcatalog.Created_Date;
                        catalog.Modified_By = GetLoggedUserInfo();
                        catalog.Modified_Date = DateTime.UtcNow;

                        if (catalog.Pillar_LawReg_Mapping != null && catalog.Pillar_Lawreg_Mapping_Id == 0)
                        {
                            Context.Pillar_LawReg_Mapping.Add(catalog.Pillar_LawReg_Mapping);
                        }

                        if (catalog.Pillar_PB28_Mapping != null && catalog.Pillar_PB28_Mapping_Id == 0)
                        {
                            Context.Pillar_PB28_Mapping.Add(catalog.Pillar_PB28_Mapping);
                        }

                        if (catalog.Catalog_Questions != null)
                        {
                            catalog.Catalog_Questions.ToList().ForEach(cq =>
                                {
                                    cq.Answer_Type_Id = AppConstants.CodeCategories.AnswerType;
                                    cq.Modified_By = GetLoggedUserInfo();
                                    cq.Modified_Date = DateTime.UtcNow;
                                });
                        }

                        if (catalog.Catalog_AMSCO != null)
                        {
                            catalog.Catalog_AMSCO.ToList().ForEach(cq =>
                                {
                                    cq.Modified_By = GetLoggedUserInfo();
                                    cq.Modified_Date = DateTime.UtcNow;
                                });
                        }

                        Context.Entry(dbcatalog).CurrentValues.SetValues(catalog);

                        if (catalog != null && (catalog.Catalog_Questions != null && catalog.Catalog_Questions.Any()))
                        {
                            foreach (var childCatalogQuestions in catalog.Catalog_Questions)
                            {
                                var existingChildCatalogQuestions =
                                    dbcatalog.Catalog_Questions.SingleOrDefault(c => c.Id == childCatalogQuestions.Id &&
                                                                                     childCatalogQuestions.Id != 0);

                                if (existingChildCatalogQuestions != null)
                                {
                                    childCatalogQuestions.Created_By = existingChildCatalogQuestions.Created_By;
                                    childCatalogQuestions.Created_Date = existingChildCatalogQuestions.Created_Date;
                                    childCatalogQuestions.Modified_By = GetLoggedUserInfo();
                                    childCatalogQuestions.Modified_Date = CreatedUpdatedDateTime();
                                    Context.Entry(existingChildCatalogQuestions)
                                           .CurrentValues.SetValues(childCatalogQuestions);
                                }
                                else
                                {
                                    // Insert child 
                                    var newCatalogQuestions = new Catalog_Questions()
                                        {
                                            Catalog_Id = childCatalogQuestions.Catalog_Id,
                                            Question = childCatalogQuestions.Question,
                                            Answer_Type_Id = AppConstants.CodeCategories.AnswerType,
                                            Answer_Type_Key = childCatalogQuestions.Answer_Type_Key,
                                            CodeValueAnswerType = childCatalogQuestions.CodeValueAnswerType,
                                            Start_FY = childCatalogQuestions.Start_FY,
                                            End_FY = childCatalogQuestions.End_FY,
                                            IsRequired = childCatalogQuestions.IsRequired,
                                            Created_By = GetLoggedUserInfo(),
                                            Created_Date = CreatedUpdatedDateTime(),
                                            Modified_By = GetLoggedUserInfo(),
                                            Modified_Date = CreatedUpdatedDateTime(),
                                        };
                                    dbcatalog.Catalog_Questions.Add(newCatalogQuestions);
                                }
                            }
                        }
                        if (catalog != null && (catalog.Catalog_AMSCO != null && catalog.Catalog_AMSCO.Any()))
                        {
                            foreach (var childCatalogAMSCO in catalog.Catalog_AMSCO)
                            {
                                var existingChildCatalogAMSCO =
                                    dbcatalog.Catalog_AMSCO.SingleOrDefault(c => c.Id == childCatalogAMSCO.Id &&
                                                                                 childCatalogAMSCO.Id != 0);

                                if (existingChildCatalogAMSCO != null)
                                {
                                    childCatalogAMSCO.Created_By = existingChildCatalogAMSCO.Created_By;
                                    childCatalogAMSCO.Created_Date = existingChildCatalogAMSCO.Created_Date;
                                    childCatalogAMSCO.Modified_By = GetLoggedUserInfo();
                                    childCatalogAMSCO.Modified_Date = CreatedUpdatedDateTime();
                                    Context.Entry(existingChildCatalogAMSCO).CurrentValues.SetValues(childCatalogAMSCO);
                                }
                                else
                                {
                                    // Insert child 
                                    var newCatalogAMSCO = new Catalog_AMSCO()
                                        {
                                            AMSCO = childCatalogAMSCO.AMSCO,
                                            AMSCO_Id = childCatalogAMSCO.AMSCO_Id,
                                            Catalog_Id = childCatalogAMSCO.Catalog_Id,
                                            //Start_FY = childCatalogAMSCO.Start_FY,
                                            //End_FY = childCatalogAMSCO.End_FY,
                                            Created_By = GetLoggedUserInfo(),
                                            Created_Date = CreatedUpdatedDateTime(),
                                            Modified_By = GetLoggedUserInfo(),
                                            Modified_Date = CreatedUpdatedDateTime(),
                                        };
                                    dbcatalog.Catalog_AMSCO.Add(newCatalogAMSCO);
                                }
                            }
                        }
                        Context.Entry<Catalog>(dbcatalog).State = EntityState.Modified;
                        Context.SaveChanges();
                        Context.Entry<Catalog>(dbcatalog).Reload();

                        foreach (var questions in dbcatalog.Catalog_Questions)
                        {
                            questions.FiscalYear =
                                Context.Project_Answer.Where(
                                    x => x.Catalog_Question_Id == questions.Id && x.Answer != "").FirstOrDefault() ==
                                null
                                    ? 0
                                    : Context.Project_Answer.Where(
                                        x => x.Catalog_Question_Id == questions.Id && x.Answer != "")
                                             .FirstOrDefault()
                                             .FY.Value;
                            questions.Answer =
                                Context.Project_Answer.Where(
                                    x => x.Catalog_Question_Id == questions.Id && x.Answer != "").FirstOrDefault() ==
                                null
                                    ? ""
                                    : Context.Project_Answer.Where(
                                        x => x.Catalog_Question_Id == questions.Id && x.Answer != "")
                                             .FirstOrDefault()
                                             .Answer;
                            questions.ProjectId = Context.Project_Answer.Where(x => x.Catalog_Question_Id == questions.Id).Select(y => y.Project_Id).FirstOrDefault();
                        }
                        return dbcatalog;
                    }

                }
            }

            return catalog;
        }

        public object SearchCatalogs(string SharedPageKey, CatalogSearchFilter filter)
        {
            var codeValueTable = Context.Code_Value.AsNoTracking();
            var result = (from c in Context.Catalogs.AsNoTracking()
                          join plm in Context.Pillar_LawReg_Mapping.AsNoTracking() on c.Pillar_Lawreg_Mapping_Id equals plm.Id
                          join pb28 in Context.Pillar_PB28_Mapping.AsNoTracking() on c.Pillar_PB28_Mapping_Id equals pb28.Id
                          join cv_pillar in codeValueTable on new { ID = plm.Pillar_Id, Key = plm.Pillar_Key } equals new { ID = cv_pillar.Code_ID, Key = cv_pillar.Code_Value_Key }
                          join cv_lawreg in codeValueTable on new { ID = plm.LawReg_Id, Key = plm.LawReg_Key } equals new { ID = cv_lawreg.Code_ID, Key = cv_lawreg.Code_Value_Key }
                          join cv_pa in codeValueTable on new { ID = plm.ProgramArea_Id, Key = plm.ProgramArea_Key } equals new { ID = cv_pa.Code_ID, Key = cv_pa.Code_Value_Key }
                          join cv_title in codeValueTable on new { ID = pb28.Title_Id, Key = pb28.Title_Key } equals new { ID = cv_title.Code_ID, Key = cv_title.Code_Value_Key }
                          join cv_cata in codeValueTable on new { ID = pb28.Category_Id, Key = pb28.Category_Key } equals new { ID = cv_cata.Code_ID, Key = cv_cata.Code_Value_Key }
                          join cv_subCata in codeValueTable on new { ID = pb28.SubCategory_Id, Key = pb28.SubCategory_Key } equals new { ID = cv_subCata.Code_ID, Key = cv_subCata.Code_Value_Key }
                          join cv_status in codeValueTable on new { ID = c.Status_Id, Key = c.Status_Key } equals new { ID = cv_status.Code_ID, Key = cv_status.Code_Value_Key }
                          where
                          ((string.IsNullOrEmpty(filter.CatalogName) || c.Catalog_Name.ToLower().Contains(filter.CatalogName.ToLower().Trim())) &&
                            (string.IsNullOrEmpty(filter.CatalogNumber) || c.Catalog_Number.ToLower().Contains(filter.CatalogNumber.ToLower().Trim())) &&
                            (string.IsNullOrEmpty(filter.Pillar) || plm.Pillar_Key == filter.Pillar) &&
                             (string.IsNullOrEmpty(filter.LawReg) || plm.LawReg_Key == filter.LawReg) &&
                             (string.IsNullOrEmpty(filter.ProgramArea) || plm.ProgramArea_Key == filter.ProgramArea))
                          select new
                          {
                              Catalog_Id = c.Id,
                              c.Catalog_Number,
                              c.Catalog_Name,
                              c.Catalog_Narrative,
                              Status = cv_status.Code_Value_Description,
                              Pillar = cv_pillar.Code_Value_Description,
                              LawReg = cv_lawreg.Code_Value_Description,
                              ProgramArea = cv_pa.Code_Value_Description,
                              PB28Title = cv_title.Code_Value_Description,
                              PB28Category = cv_cata.Code_Value_Description,
                              PB28SubCategory = cv_subCata.Code_Value_Description,
                              StatusId = c.Status_Id,
                              StatusKey = c.Status_Key
                          });

            if (SharedPageKey.Equals(AppConstants.PageSharedKey.AddEditProject))
            {
                result = result.Where(x => x.StatusId.Equals(AppConstants.CodeCategories.Status) && x.StatusKey.Equals(AppConstants.CatalogStatus.Active));
            }
            return result.OrderBy(x => x.Catalog_Number).ToList();
        }

        public object GetCatalogMasterData()
        {
            var codeValue =
                Context.Code_Value.AsNoTracking()
                       .Where(x => x.Code_Value_Key != (AppConstants.CodeCategories.ALL))
                       .Select(x =>
                               new
                                   {
                                       ID = x.Code_ID,
                                       Key = x.Code_Value_Key,
                                       Description = x.Code_Value_Description
                                   }).ToList();
            var masterList = new
                {
                    //PillarList = codeValue.Where(x => x.ID == AppConstants.CodeCategories.Pillar),

                    //LawRegList =
                    //    codeValue.Where(x => x.ID == AppConstants.CodeCategories.LawReg).OrderBy(y => y.Description),
                    //ProgramAreaList =
                    //    codeValue.Where(x => x.ID == AppConstants.CodeCategories.ProgramArea)
                    //             .OrderBy(y => y.Description),
                    PillarList = AppContext.CurrentUserRolePillars.Distinct().OrderBy(y => y.PillarDescription),
                    LawRegList = AppContext.CurrentUserRoleLawRegs.Distinct().OrderBy(y => y.LawRegDescription),
                    ProgramAreaList = AppContext.CurrentUserRoleProgramAreas.Distinct().OrderBy(y => y.ProgramAreaDescription),
                    TitleList =
                        codeValue.Where(x => x.ID == AppConstants.CodeCategories.PB28Title).OrderBy(y => y.Description),
                    CategoryList =
                        codeValue.Where(x => x.ID == AppConstants.CodeCategories.PB28Category)
                                 .OrderBy(y => y.Description),
                    SubCategoryList =
                        codeValue.Where(x => x.ID == AppConstants.CodeCategories.PB28SubCategory)
                                 .OrderBy(y => y.Description),
                    AnswerTypeList = codeValue.Where(x => x.ID == AppConstants.CodeCategories.AnswerType),
                    ClassList = codeValue.Where(x => x.ID == AppConstants.CodeCategories.Class),
                    StatusList = codeValue.Where(x => x.ID == AppConstants.CodeCategories.Status),
                    StartFYList = AppContext.FiscalYears.Select(x => new {Year = x.FY}).ToList(),
                    EndFYList = AppContext.FiscalYears.Select(x => new {Year = x.FY}).ToList(),
                    AMSCOList =
                        Context.AMSCOs.AsNoTracking()
                               .Select(
                                   x =>
                                   new
                                       {
                                           x.AMSCO_Code,
                                           x.AMSCO_Description,
                                           x.Id,
                                           x.Start_FY,
                                           x.End_FY,
                                           AMSCOCodeDesc = x.AMSCO_Code + " - " + x.AMSCO_Description
                                       })
                               .ToList()
                };
            return masterList;
        }

        public object GetCatalogById(int catalogId)
        {

            int fy = AppContext.CurrentFiscalYear.FY;
            var mdepTable = Context.MDEP.AsNoTracking();
            var codeValueTable = Context.Code_Value.AsNoTracking();

            var result = (from c in Context.Catalogs.AsNoTracking()
                          join plm in Context.Pillar_LawReg_Mapping.AsNoTracking() on c.Pillar_Lawreg_Mapping_Id equals
                              plm.Id
                          join pb28 in Context.Pillar_PB28_Mapping.AsNoTracking() on c.Pillar_PB28_Mapping_Id equals
                              pb28.Id
                          join cv_pillar in codeValueTable on new {ID = plm.Pillar_Id, Key = plm.Pillar_Key} equals
                              new {ID = cv_pillar.Code_ID, Key = cv_pillar.Code_Value_Key}
                          join cv_lawreg in codeValueTable on new {ID = plm.LawReg_Id, Key = plm.LawReg_Key} equals
                              new {ID = cv_lawreg.Code_ID, Key = cv_lawreg.Code_Value_Key}
                          join cv_pa in codeValueTable on new {ID = plm.ProgramArea_Id, Key = plm.ProgramArea_Key}
                              equals new {ID = cv_pa.Code_ID, Key = cv_pa.Code_Value_Key}
                          join cv_title in codeValueTable on new {ID = pb28.Pillar_Id, Key = pb28.Pillar_Key} equals
                              new {ID = cv_title.Code_ID, Key = cv_title.Code_Value_Key}
                          join cv_cata in codeValueTable on new {ID = pb28.Category_Id, Key = pb28.Category_Key} equals
                              new {ID = cv_cata.Code_ID, Key = cv_cata.Code_Value_Key}
                          join cv_subCata in codeValueTable on
                              new {ID = pb28.SubCategory_Id, Key = pb28.SubCategory_Key} equals
                              new {ID = cv_subCata.Code_ID, Key = cv_subCata.Code_Value_Key}
                          join cv_status in codeValueTable on new {ID = c.Status_Id, Key = c.Status_Key} equals
                              new {ID = cv_status.Code_ID, Key = cv_status.Code_Value_Key}
                          join cq in Context.Catalog_Questions.Include(x => x.Project_Answer).AsNoTracking() on c.Id
                              equals cq.Catalog_Id into questionList
                          join ca in Context.Catalog_AMSCO.Include(x => x.AMSCO).AsNoTracking() on c.Id equals
                              ca.Catalog_Id into amscoList
                          join p in Context.Project.AsNoTracking() on c.Id equals p.Catalog_Id into projectList
                          where c.Id == catalogId
                          let mdep =
                              mdepTable.Where(
                                  y =>
                                  (y.Pillar_Key == plm.Pillar_Key && y.Start_FY <= fy &&
                                   (y.End_FY == null || y.End_FY >= fy))).Select(x => x.MDEP_Code).ToList()
                          //let amsco = amscoList.Where(y => (y.End_FY == null || y.End_FY >= fy) && y.Start_FY <= fy).Select(x => new { AMSCO_Code = x.AMSCO.AMSCO_Code + " - " + x.AMSCO.AMSCO_Description }).ToList()
                          let amsco =
                              amscoList.Where(
                                  y => (y.AMSCO.End_FY == null || y.AMSCO.End_FY >= fy) && y.AMSCO.Start_FY <= fy)
                                       .Select(
                                           x =>
                                           new {AMSCO_Code = x.AMSCO.AMSCO_Code + " - " + x.AMSCO.AMSCO_Description})
                                       .ToList()
                          select new
                              {
                                  Catalog_Id = c.Id,
                                  c.Catalog_Number,
                                  c.Catalog_Name,
                                  c.Catalog_Narrative,
                                  Status = c.Status_Key,
                                  Class = c.Class_Key,
                                  Pillar = plm.Pillar_Key,
                                  LawReg = plm.LawReg_Key,
                                  ProgramArea = plm.ProgramArea_Key,
                                  PB28Title = pb28.Title_Key,
                                  PB28Category = pb28.Category_Key,
                                  PB28SubCategory = pb28.SubCategory_Key,
                                  QuestionsList = (from q in questionList.AsEnumerable()
                                                   //from a in projectList.AsEnumerable()
                                                   select new
                                                       {
                                                           q.Id,
                                                           q.Question,
                                                           q.IsRequired,
                                                           q.Catalog_Id,
                                                           ProjectId = q.Project_Answer.Select(x => x.Project_Id).FirstOrDefault(),
                                                           AnswerType_Description =
                                                       codeValueTable.Where(
                                                           x =>
                                                           x.Code_ID == AppConstants.CodeCategories.AnswerType &&
                                                           x.Code_Value_Key == q.Answer_Type_Key)
                                                                     .FirstOrDefault()
                                                                     .Code_Value_Description,
                                                           q.Answer_Type_Key,
                                                           q.Start_FY,
                                                           End_FY =
                                                       q.End_FY.HasValue ? q.End_FY.ToString() : string.Empty,
                                                           IsQuestionEditable =
                                                       (q.Project_Answer.Count() > 0 ? false : true),
                                                           UpdateYear = q.Project_Answer.Max(x => x.FY),
                                                           Answer =
                                                       q.Project_Answer.Where(
                                                           x => x.Catalog_Question_Id == q.Id && x.Answer != "")
                                                        .FirstOrDefault()
                                                        .Answer,
                                                           FiscalYear =
                                                       q.Project_Answer.Where(
                                                           x => x.Catalog_Question_Id == q.Id && x.Answer != "")
                                                        .FirstOrDefault()
                                                        .FY,
                                                       }),

                                  AMSCOList = (from x in amscoList.AsEnumerable()
                                               select new
                                                   {
                                                       x.Id,
                                                       x.AMSCO_Id,
                                                       x.Catalog_Id,
                                                       x.AMSCO.AMSCO_Code,
                                                       x.AMSCO.AMSCO_Description,
                                                       plm.Pillar_Key,
                                                       x.AMSCO.Start_FY,
                                                       End_FY =
                                                   x.AMSCO.End_FY.HasValue ? x.AMSCO.End_FY.ToString() : string.Empty,
                                                       MDEP_Code = ""
                                                   }),
                                  IsEditable = (projectList.Count() == 0),
                                  MDEPCode = mdep.FirstOrDefault(),
                                  AMSCOCode = amsco.FirstOrDefault().AMSCO_Code,

                              }).ToArray();



            return result;

        }

    }

}
