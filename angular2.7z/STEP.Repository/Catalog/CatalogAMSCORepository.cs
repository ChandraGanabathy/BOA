﻿using STEP.Models;

namespace STEP.Repository
{
    public class CatalogAMSCORepository : EntityBaseRepository<Catalog_AMSCO>, ICatalogAMSCORepository
    {
        public CatalogAMSCORepository(STEPContext context)
            : base(context)
        { }
    }
}
