﻿using STEP.Models;

namespace STEP.Repository
{
    public class PillarPB28MappingRepository : EntityBaseRepository<Pillar_PB28_Mapping>,IPillarPB28MappingRepository
    {
        public PillarPB28MappingRepository(STEPContext context)
            : base(context)
        {

        }
    }
}
