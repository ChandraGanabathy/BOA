﻿using STEP.Models;

namespace STEP.Repository
{
  public  class CatalogQuestionsRepository : EntityBaseRepository<Catalog_Questions>, ICatalogQuestionsRepository
    {
      public CatalogQuestionsRepository(STEPContext context) : base(context)
      {

      }
    }
}
