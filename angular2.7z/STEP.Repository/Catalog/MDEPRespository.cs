﻿using STEP.Models;

namespace STEP.Repository
{
    public class MDEPRepository : EntityBaseRepository<MDEP>, IMDEPRepository
    {
        public MDEPRepository(STEPContext context)
            : base(context)
        {

        }
    }
}
