﻿using System.Collections.Generic;
using System.Linq;
using STEP.Common;
using STEP.Models;
using STEP.Models.UIModel;

namespace STEP.Repository
{
    public class PillarLawRegMappingRepository : EntityBaseRepository<Pillar_LawReg_Mapping>,
                                                 IPillarLawRegMappingRepository
    {
        public readonly STEPContext Context;

        public PillarLawRegMappingRepository(STEPContext context)
            : base(context)
        {
            Context = context;
        }

        public List<Pillar> GetPillarsByUserRole(int pillarId, string pillarKey)
        {
            if (!string.IsNullOrEmpty(pillarKey) &&
                pillarKey.ToUpper() == STEP.Common.AppConstants.CodeCategories.ALL.ToUpper())
            {
                pillarKey = string.Empty;
            }
            var pillars = (from plm in Context.Pillar_LawReg_Mapping.AsNoTracking()
                           join cvPlr in Context.Code_Value.AsNoTracking() on plm.Pillar_Id equals cvPlr.Code_ID
                           where plm.Pillar_Key == cvPlr.Code_Value_Key
                                 && plm.Pillar_Id == pillarId &&
                                 (pillarKey == string.Empty || plm.Pillar_Key == pillarKey)
                           select new Pillar
                           {
                               PillarId = plm.Pillar_Id,
                               PillarKey = plm.Pillar_Key,
                               PillarDescription = cvPlr.Code_Value_Description
                           }).Distinct().ToList();
            return pillars;
        }

        //public List<LawReg> GetLawRegByUserRole(int lawRegId, string lawRegKey)
        //{
        //    if (!string.IsNullOrEmpty(lawRegKey) &&
        //        lawRegKey.ToUpper() == STEP.Common.AppConstants.CodeCategories.ALL.ToUpper())
        //    {
        //        lawRegKey = string.Empty;
        //    }
        //    var lawRegs = (from plm in Context.Pillar_LawReg_Mapping.AsNoTracking()
        //                   join cvPlr in Context.Code_Value.AsNoTracking() on plm.Pillar_Id equals cvPlr.Code_ID
        //                   join cvLawReg in Context.Code_Value.AsNoTracking() on plm.LawReg_Id equals cvLawReg.Code_ID
        //                   where plm.Pillar_Key == cvPlr.Code_Value_Key
        //                         && plm.LawReg_Key == cvLawReg.Code_Value_Key
        //                         && plm.LawReg_Id == lawRegId
        //                         && (lawRegKey == string.Empty || plm.LawReg_Key == lawRegKey)
        //                   select new LawReg
        //                       {
        //                           PillarId = plm.Pillar_Id,
        //                           PillarKey = plm.Pillar_Key,
        //                           PillarDescription = cvPlr.Code_Value_Description,
        //                           LawRegId = plm.LawReg_Id,
        //                           LawRegKey = plm.LawReg_Key,
        //                           LawRegDescription = cvLawReg.Code_Value_Description
        //                       }).Distinct().ToList();
        //    return lawRegs;
        //}

        public List<LawReg> GetLawRegByUserRole(string pillarKey, int lawRegId, string lawRegKey)
        {
            if (!string.IsNullOrEmpty(lawRegKey) &&
                lawRegKey.ToUpper() == STEP.Common.AppConstants.CodeCategories.ALL.ToUpper())
            {
                lawRegKey = string.Empty;
            }
            var lawRegs = (from plm in Context.Pillar_LawReg_Mapping.AsNoTracking()
                           join cvPlr in Context.Code_Value.AsNoTracking() on plm.Pillar_Id equals cvPlr.Code_ID
                           join cvLawReg in Context.Code_Value.AsNoTracking() on plm.LawReg_Id equals cvLawReg.Code_ID
                           where plm.Pillar_Key == cvPlr.Code_Value_Key
                                 && plm.LawReg_Key == cvLawReg.Code_Value_Key
                                 && plm.LawReg_Id == lawRegId
                                 && (lawRegKey == string.Empty || plm.LawReg_Key == lawRegKey)
                                 &&
                                 (string.IsNullOrEmpty(pillarKey) ||
                                  pillarKey.ToUpper().Equals(AppConstants.CodeCategories.ALL) ||
                                  plm.Pillar_Key == pillarKey)
                           select new LawReg
                           {
                               PillarId = plm.Pillar_Id,
                               PillarKey = plm.Pillar_Key,
                               PillarDescription = cvPlr.Code_Value_Description,
                               LawRegId = plm.LawReg_Id,
                               LawRegKey = plm.LawReg_Key,
                               LawRegDescription = cvLawReg.Code_Value_Description
                           }).Distinct().OrderBy(z => z.LawRegDescription).ToList();
            return lawRegs;
        }

        public List<ProgramArea> GetProgramAreaUserRole(string pillarKey, string lawRegKey, int programAreaId,
                                                      string programAreaKey)
        {
            if (!string.IsNullOrEmpty(programAreaKey) &&
                programAreaKey.ToUpper() == STEP.Common.AppConstants.CodeCategories.ALL.ToUpper())
            {
                programAreaKey = string.Empty;
            }
            var programAreas = (from plm in Context.Pillar_LawReg_Mapping.AsNoTracking()
                                join cvPlr in Context.Code_Value.AsNoTracking() on plm.Pillar_Id equals cvPlr.Code_ID
                                join cvLawReg in Context.Code_Value.AsNoTracking() on plm.LawReg_Id equals
                                    cvLawReg.Code_ID
                                join cvProgramArea in Context.Code_Value.AsNoTracking() on plm.ProgramArea_Id equals
                                    cvProgramArea.Code_ID
                                where plm.Pillar_Key == cvPlr.Code_Value_Key
                                      && plm.LawReg_Key == cvLawReg.Code_Value_Key
                                      && plm.ProgramArea_Key == cvProgramArea.Code_Value_Key
                                      && plm.ProgramArea_Id == programAreaId
                                      &&
                                      (string.IsNullOrEmpty(pillarKey) ||
                                       pillarKey.ToUpper().Equals(AppConstants.CodeCategories.ALL) ||
                                       plm.Pillar_Key == pillarKey)
                                      &&
                                      (string.IsNullOrEmpty(lawRegKey) ||
                                       lawRegKey.ToUpper().Equals(AppConstants.CodeCategories.ALL) ||
                                       plm.LawReg_Key == lawRegKey)
                                      && (programAreaKey == string.Empty || plm.ProgramArea_Key == programAreaKey)
                                select new ProgramArea()
                                {
                                    PillarId = plm.Pillar_Id,
                                    PillarKey = plm.Pillar_Key,
                                    PillarDescription = cvPlr.Code_Value_Description,
                                    LawRegId = plm.LawReg_Id,
                                    LawRegKey = plm.LawReg_Key,
                                    LawRegDescription = cvLawReg.Code_Value_Description,
                                    ProgramAreaId = plm.ProgramArea_Id,
                                    ProgramAreaKey = plm.ProgramArea_Key,
                                    ProgramAreaDescription = cvProgramArea.Code_Value_Description
                                }).Distinct()
                                      .OrderBy(
                                          z => new { z.ProgramAreaDescription, z.LawRegDescription, z.PillarDescription })
                                      .ToList();
            return programAreas;
        }

        public List<PB28Title> GetPB28Title(List<string> pillarKeys)
        {
            var pb28Titles = (from pb28M in Context.Pillar_PB28_Mapping.AsNoTracking()
                              join cvPlr in Context.Code_Value.AsNoTracking() on pb28M.Pillar_Id equals cvPlr.Code_ID
                              join cvTitle in Context.Code_Value.AsNoTracking() on pb28M.Title_Id equals cvTitle.Code_ID
                              where pb28M.Pillar_Key == cvPlr.Code_Value_Key
                                    && pb28M.Title_Key == cvTitle.Code_Value_Key
                              select new PB28Title
                              {
                                  PillarId = pb28M.Pillar_Id,
                                  PillarKey = pb28M.Pillar_Key,
                                  PillarDescription = cvPlr.Code_Value_Description,
                                  TitleId = pb28M.Title_Id,
                                  TitleKey = pb28M.Title_Key,
                                  TitleDescription = cvTitle.Code_Value_Description
                              }).Distinct().OrderBy(z => z.TitleDescription).ToList();

            pb28Titles = pb28Titles.Where(x => pillarKeys.Contains(x.PillarKey.ToUpper())).ToList();
            return pb28Titles;
        }

        public List<PB28Category> GetPB28Category(List<string> pillarKeys, List<string> pb28TitleKeys)
        {
            var pb28Category = (from pb28M in Context.Pillar_PB28_Mapping.AsNoTracking()
                                join cvPlr in Context.Code_Value.AsNoTracking() on pb28M.Pillar_Id equals cvPlr.Code_ID
                                join cvTitle in Context.Code_Value.AsNoTracking() on pb28M.Title_Id equals
                                    cvTitle.Code_ID
                                join cvCategory in Context.Code_Value.AsNoTracking() on pb28M.Category_Id equals
                                    cvCategory.Code_ID
                                where pb28M.Pillar_Key == cvPlr.Code_Value_Key
                                      && pb28M.Title_Key == cvTitle.Code_Value_Key
                                      && pb28M.Category_Key == cvCategory.Code_Value_Key
                                select new PB28Category
                                {
                                    PillarId = pb28M.Pillar_Id,
                                    PillarKey = pb28M.Pillar_Key,
                                    PillarDescription = cvPlr.Code_Value_Description,
                                    TitleId = pb28M.Title_Id,
                                    TitleKey = pb28M.Title_Key,
                                    TitleDescription = cvTitle.Code_Value_Description,
                                    PB28CategoryId = pb28M.Category_Id,
                                    PB28CategoryKey = pb28M.Category_Key,
                                    PB28CategoryDescription = cvCategory.Code_Value_Description
                                }).Distinct().OrderBy(z => z.PB28CategoryDescription).ToList();

            pb28Category =
                pb28Category.Where(
                    x => (pillarKeys.Contains(x.PillarKey.ToUpper()) && pb28TitleKeys.Contains(x.TitleKey.ToUpper())))
                            .ToList();
            return pb28Category;
        }

        //public List<ProgramArea> GetProgramAreaUserRole(int programAreaId, string programAreaKey)
        //{
        //    if (!string.IsNullOrEmpty(programAreaKey) &&
        //        programAreaKey.ToUpper() == STEP.Common.AppConstants.CodeCategories.ALL.ToUpper())
        //    {
        //        programAreaKey = string.Empty;
        //    }
        //    var programAreas = (from plm in Context.Pillar_LawReg_Mapping.AsNoTracking()
        //                        join cvPlr in Context.Code_Value.AsNoTracking() on plm.Pillar_Id equals cvPlr.Code_ID
        //                        join cvLawReg in Context.Code_Value.AsNoTracking() on plm.LawReg_Id equals
        //                            cvLawReg.Code_ID
        //                        join cvProgramArea in Context.Code_Value.AsNoTracking() on plm.ProgramArea_Id equals
        //                            cvProgramArea.Code_ID
        //                        where plm.Pillar_Key == cvPlr.Code_Value_Key
        //                              && plm.LawReg_Key == cvLawReg.Code_Value_Key
        //                              && plm.ProgramArea_Key == cvProgramArea.Code_Value_Key
        //                              && plm.ProgramArea_Id == programAreaId
        //                              && (programAreaKey == string.Empty || plm.ProgramArea_Key == programAreaKey)
        //                        select new ProgramArea()
        //                            {
        //                                PillarId = plm.Pillar_Id,
        //                                PillarKey = plm.Pillar_Key,
        //                                PillarDescription = cvPlr.Code_Value_Description,
        //                                LawRegId = plm.LawReg_Id,
        //                                LawRegKey = plm.LawReg_Key,
        //                                LawRegDescription = cvLawReg.Code_Value_Description,
        //                                ProgramAreaId = plm.ProgramArea_Id,
        //                                ProgramAreaKey = plm.ProgramArea_Key,
        //                                ProgramAreaDescription = cvProgramArea.Code_Value_Description
        //                            }).Distinct().ToList();
        //    return programAreas;
        //}

        //public List<PB28Title> GetPB28Title()
        //{
        //    var pb28Titles = (from pb28M in Context.Pillar_PB28_Mapping.AsNoTracking()
        //                      join cvPlr in Context.Code_Value.AsNoTracking() on pb28M.Pillar_Id equals cvPlr.Code_ID
        //                      join cvTitle in Context.Code_Value.AsNoTracking() on pb28M.Title_Id equals cvTitle.Code_ID
        //                      where pb28M.Pillar_Key == cvPlr.Code_Value_Key
        //                            && pb28M.Title_Key == cvTitle.Code_Value_Key
        //                      select new PB28Title
        //                          {
        //                              PillarId = pb28M.Pillar_Id,
        //                              PillarKey = pb28M.Pillar_Key,
        //                              PillarDescription = cvPlr.Code_Value_Description,
        //                              TitleId = pb28M.Title_Id,
        //                              TitleKey = pb28M.Title_Key,
        //                              TitleDescription = cvTitle.Code_Value_Description
        //                          }).Distinct().ToList();
        //    return pb28Titles;
        //}

        //public List<PB28Category> GetPB28Category()
        //{
        //    var pb28Category = (from pb28M in Context.Pillar_PB28_Mapping.AsNoTracking()
        //                        join cvPlr in Context.Code_Value.AsNoTracking() on pb28M.Pillar_Id equals cvPlr.Code_ID
        //                        join cvTitle in Context.Code_Value.AsNoTracking() on pb28M.Title_Id equals
        //                            cvTitle.Code_ID
        //                        join cvCategory in Context.Code_Value.AsNoTracking() on pb28M.Category_Id equals
        //                            cvCategory.Code_ID
        //                        where pb28M.Pillar_Key == cvPlr.Code_Value_Key
        //                              && pb28M.Title_Key == cvTitle.Code_Value_Key
        //                              && pb28M.Category_Key == cvCategory.Code_Value_Key
        //                        select new PB28Category
        //                            {
        //                                PillarId = pb28M.Pillar_Id,
        //                                PillarKey = pb28M.Pillar_Key,
        //                                PillarDescription = cvPlr.Code_Value_Description,
        //                                TitleId = pb28M.Title_Id,
        //                                TitleKey = pb28M.Title_Key,
        //                                TitleDescription = cvTitle.Code_Value_Description,
        //                                PB28CategoryId = pb28M.Category_Id,
        //                                PB28CategoryKey = pb28M.Category_Key,
        //                                PB28CategoryDescription = cvCategory.Code_Value_Description
        //                            }).Distinct().ToList();
        //    return pb28Category;
        //}
    }
}
