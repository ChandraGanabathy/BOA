﻿using System.Collections.Generic;
using STEP.Models;

namespace STEP.Repository.Interfaces
{
    public interface IEmailNotificationRepository
    {
        List<Role> GetAllRolesForClient();
        string UploadDocument(Document filedocument);
        List<string> GetUsersByRoleId(List<int> roleIds);
        string SendEmailNotification(List<int> roleIds, string subject, string content, string filepath, string fileName);
    }
}
