﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using STEP.Models;

namespace STEP.Repository.Interfaces
{
    public interface IFileManagerRepository
    {
        ICollection<FileManagerDetails> GetFolderFiles(FileManagerSearchFilter objFileManagerSearchFilter);
        ICollection<FileManagerDetails> GetSearchFiles(FileManagerSearchFilter objFileManagerSearchFilter);
        string uploadFileManagerDocument(Document filedocument);
    }
}
