﻿using System.Linq;
using STEP.Models;
using STEP.Models.UIModel;
using STEP.Repository.Interfaces;
using System.Collections.Generic;

namespace STEP.Repository
{
    #region User Management
    public interface IRoleRepository : IEntityBaseRepository<Role>
    {
        
    }

    //public interface IUserRepository : IEntityBaseRepository<User>
    //{
    //    User CreateUpdateUser(User user);
    //    IEnumerable<User> GetAllUsers(UserSearchFilter userSearchFilter, int userRoleId);
    //    IQueryable<Hierarchy_Data> GetHierarchyData(int userRoleId);

    //    IEnumerable<User> GetUsersForApprovalNotification(
    //        Approval_Process_Email_Config approvalProcessMailConfig, int hierarchyDataId, int projectOwnerId,
    //        string projectType);
    //    dynamic ExecuteAdminQuery(string Query);
    //    string GetAdminSecuritytext();
    //    User ValidateUserEmail(string userEmail);
    //}

    public interface IUserRepository : IEntityBaseRepository<User>
    {
        User CreateUpdateUser(User user);
        IEnumerable<User> GetAllUsers(UserSearchFilter userSearchFilter, int userRoleId);
        IQueryable<Hierarchy_Data> GetHierarchyData(int userRoleId);

        IEnumerable<User> GetUsersForApprovalNotification(
            Approval_Process_Email_Config approvalProcessMailConfig, int hierarchyDataId, int projectOwnerId,
            string projectType);
        dynamic ExecuteAdminQuery(string Query);
        string GetAdminSecuritytext();
        User ValidateUserEmail(string userEmail);
        void UserAuidtTracking(int? userRoleId, string actionType, int? currentUserRoleId);
    }

    public interface IUserRoleRepository : IEntityBaseRepository<User_Role>
    {

    }

    public interface ICodeValueRepository : IEntityBaseRepository<Code_Value>
    {
        string GetCodeDescription(int codeId, string codeKey);
        IList<Code_Value> GetCodeValues(int p);
        Code_Value GetCodeValue(int codeId, string codeKey);
        List<Code_Value> GetCodeValues(List<Code_Value> codeValueList, int codeId, bool isExcludeAll = false);
        Code_Value GetCodeValue(List<Code_Value> codeValueList, int codeId, string codeKey);
    }

    public interface IRoleMappingRepository : IEntityBaseRepository<Role_Invitation_Mapping>
    {
    }

    public interface IHierarchyDataRepository : IEntityBaseRepository<Hierarchy_Data>
    {
        IEnumerable<Hierarchy_Data> SetCurrentUserRoleHierarchyData(string hierarchyLevelKey, int userRoleId);
    }

    public interface IUserHierarchyAssociationRepository : IEntityBaseRepository<User_Role_Hierarchy_Assoication>
    {
    }

    public interface IUserRolePillarAssociationRepository : IEntityBaseRepository<User_Role_Pillar_Association>
    {
    }

    public interface IUserPreferenceRepository : IEntityBaseRepository<User_Preference>
    {
    }
    public interface IUserAuditRepository : IEntityBaseRepository<User_Audit>
    {
    }

    public interface IRoleActionRepository : IEntityBaseRepository<Role_Action>
    {
        List<Action> GetActions(int roleId);
        string GetRoleKey(int roleId);

    }

    #endregion

    #region Catalog Management
    public interface IAMSCORepository : IEntityBaseRepository<AMSCO>
    {
    }

    public interface ICatalogRepository : IEntityBaseRepository<Catalog>
    {
        Catalog CreateUpdateCatalog(Catalog catalog);
        object SearchCatalogs(string SharedPageKey, CatalogSearchFilter searchFilter);
        object GetCatalogMasterData();
        object GetCatalogById(int catalogId);
    }

    public interface ICatalogAMSCORepository : IEntityBaseRepository<Catalog_AMSCO>
    {
    }

    public interface ICatalogQuestionsRepository : IEntityBaseRepository<Catalog_Questions>
    {
    }

    public interface IFiscalYearRepository : IEntityBaseRepository<Fiscal_Year>
    {
        Fiscal_Year GetFiscalYearBasedOnCurrentDate();
        List<Fiscal_Year> GetFiscalYearAgainstCurrentDateAndFiscalYearForCurrentRequired(List<Fiscal_Year> fiscalYears, int fiscalYear);
        List<Fiscal_Year> GetFiscalYearAgainstCurrentDateAndFiscalYearForPlanning(List<Fiscal_Year> fiscalYears, int fiscalYear);
        List<Fiscal_Year> GetFiscalYearAgainstCurrentDateAndFiscalYearForFunding(List<Fiscal_Year> fiscalYears, int fiscalYear);

        List<Fiscal_Year> GetFiscalYearAgainstCurrentDateAndFiscalYearForObligated(List<Fiscal_Year> fiscalYears,
                                                                             int fiscalYear);

        List<Project_Funding> ProjectFundingManipulation(List<Project_Funding> lstProjectFunding, List<Fiscal_Year> fiscalYears);

        List<object> GetAllFiscal();
        Fiscal_Year CreateFiscalValue(Fiscal_Year fiscalValue);
        object GetFiscalDataAtPageLoading(int FiscalId);
    }

    public interface IPillarPB28MappingRepository : IEntityBaseRepository<Pillar_PB28_Mapping>
    {
    }

    public interface IPillarLawRegMappingRepository : IEntityBaseRepository<Pillar_LawReg_Mapping>
    {
        List<Pillar> GetPillarsByUserRole(int pillarId, string pillarKey);
        List<LawReg> GetLawRegByUserRole(string pillarKey, int lawRegId, string lawRegKey);
        List<ProgramArea> GetProgramAreaUserRole(string pillarKey, string lawRegKey, int programAreaId, string programAreaKey);
        List<PB28Title> GetPB28Title(List<string> pillarKeys);
        List<PB28Category> GetPB28Category(List<string> pillarKeys, List<string> pb28TitleKeys);
    }

    public interface IMDEPRepository : IEntityBaseRepository<MDEP>
    {

    }
    #endregion

    #region Fund Planning
    public interface IHierarchyDataPlanningRepository : IEntityBaseRepository<Hierarchy_Data_Planning>
    {
        #region PAFG

        List<Hierarchy_Data_Planning> SearchPAFGs(PAFGSearchFilter PAFGSearchFilter);
        List<Hierarchy_Data_Planning> SaveControlAmount(List<Hierarchy_Data_Planning> pafgList);
        List<Hierarchy_Data_Planning> AllocatePAFG(decimal controlAmount, int propertyId, int FY, string selectedProperty);

        #endregion

        #region Priority
        object GetProjectPrioritiesMasterData();
        object SearchProjectPriorities(PrioritizationSearchFilter searchFilter);
        void SaveProjectPriorities(List<Project_Funding> fundingData, string priorityStatus);

        #endregion
    }
    #endregion

    #region Project Management
    public interface IProjectRepository : IEntityBaseRepository<Project>
    {
        string GenerateProjectNumber(string format);
        //Project InsertProject(Project project);
        Project UpdateProject(Project project);
        List<Project> MyInboxProjects();
        List<ProjectDetails> MyProjects(int User_Id, Fiscal_Year FY);
        List<int> GetFiscalYears();
        object GetProjectListsData(ProjectSearchFilter projectSearchFilter);
        object ViewProjectHistoryByProjectId(int projectId);
        List<ChartData> PFChartData(IEnumerable<Hierarchy_Data> Heirarchy_Data, Fiscal_Year FY);
        List<ChartData> PercentFundChartData(IEnumerable<Hierarchy_Data> Heirarchy_Data);
        List<ChartData> PFChartDetailsData(KpiFilter searchFilter);
        List<DrilldownChartData> PercentFundedChartDetailsData(KpiFilter searchFilter);
        List<Code_Value> GetProjectStatuses();
        object GetMyApprovalInboxProjects();
        object GetProjectOwnerListData(ProjectOwnerSearchFilter projectOwnerSerachFilter);
        object GetAllusers();
        object GetAllImpactMission();
        bool UpdateOwnerList(List<ProjectOwnerDetails> projectOwnerDetails);
        bool ProjectFundingBulkUpdate(List<Project_Funding> projectFunding);

        object GetRoleListData();
        object GetActionListData();
        bool UpdateRoleActionList(List<Roles> role);
        object GetRoleActionData(int RoleId);
        
    }

    public interface IProjectAnswerRepository : IEntityBaseRepository<Project_Answer>
    {
    }

    public interface IProjectDocumentRepository : IEntityBaseRepository<Project_Document>
    {
    }

    public interface IProjectFundingRepository : IEntityBaseRepository<Project_Funding>
    {
    }

    public interface IProjectNoteRepository : IEntityBaseRepository<Project_Note>
    {
    }

    public interface IApprovalProcessRepository : IEntityBaseRepository<Approval_Process>
    {
    }

    public interface IApprovalProcessEmailConfigRepository : IEntityBaseRepository<Approval_Process_Email_Config> 
    {
    }
    public interface IAuditRepository : IEntityBaseRepository<Audit>
    {
    }
    public interface IAuditDetailsRepository : IEntityBaseRepository<Audit_Details>
    {
    }
    public interface IAuditDisplayRepository : IEntityBaseRepository<Audit_Display>
    {
    }
   

    #endregion

    #region Report Management"
    //public interface IReportsRepository : IEntityBaseRepository<Report>
    //{
    //    //object GetPillarLawMapping();
    //    //object GetReportsDescriptionforUserRole(int roleId);
    //}
    //public interface IReportsRoleMappingRepository : IEntityBaseRepository<Report_Role_Mapping>
    //{
    //}
    #endregion

    public interface IHelpDocumentsRepository : IEntityBaseRepository<Help_Documents> 
    {

    }

}
