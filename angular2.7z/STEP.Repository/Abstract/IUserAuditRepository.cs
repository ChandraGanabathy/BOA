﻿using STEP.Models;
using STEP.Repository.Interfaces;

namespace STEP.Repository
{
    //public interface IUserAuditRepository : IEntityBaseRepository<User_Audit>
    //{
    //}
}