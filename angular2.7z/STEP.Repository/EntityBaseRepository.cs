﻿using System.Data;
using System.Data.Entity;
using STEP.Common;
using STEP.Models;
using STEP.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using EntityState = System.Data.Entity.EntityState;

namespace STEP.Repository
{
    public class EntityBaseRepository<T> : IEntityBaseRepository<T>
            where T : class, IEntityBase, new()
    {
        public readonly STEPContext _context;

        #region Properties
        public bool AllowSerialization
        {
            get
            {
                return _context.Configuration.ProxyCreationEnabled;
            }
            set
            {
                _context.Configuration.ProxyCreationEnabled = !value;
            }
        }
        #endregion

        public EntityBaseRepository(STEPContext context)
        {
            _context = context;
            AllowSerialization = true;
        }

        public EntityBaseRepository()
        {
            // TODO: Complete member initialization
        }

        public virtual IEnumerable<T> GetAll()
        {
            return _context.Set<T>().AsEnumerable();
        }

        public virtual IEnumerable<T> AllIncluding(params Expression<Func<T, object>>[] includeProperties)
        {
            IQueryable<T> query = _context.Set<T>();
            foreach (var includeProperty in includeProperties)
            {
                query = query.Include(includeProperty);
            }
            return query.AsEnumerable();
        }

        public T GetSingle(int id)
        {
            return _context.Set<T>().FirstOrDefault(x => x.Id == id);
        }

        public T GetSingle(Expression<Func<T, bool>> predicate)
        {
            return _context.Set<T>().FirstOrDefault(predicate);
        }

        public T GetSingle(Expression<Func<T, bool>> predicate, params Expression<Func<T, object>>[] includeProperties)
        {
            IQueryable<T> query = _context.Set<T>();
            foreach (var includeProperty in includeProperties)
            {
                query = query.Include(includeProperty);
            }

            return query.Where(predicate).FirstOrDefault();
        }

        public virtual IEnumerable<T> FindBy(Expression<Func<T, bool>> predicate)
        {
            return _context.Set<T>().Where(predicate);
        }

        public virtual void Add(T entity)
        {
            _context.Set<T>().Add(entity);
            _context.Entry(entity).State = EntityState.Added;
        }

        public virtual void Edit(T entity)
        {
            _context.Set<T>().Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;
        }
        public virtual void Delete(T entity)
        {
            _context.Set<T>().Attach(entity);
            _context.Entry(entity).State = EntityState.Deleted;
        }

        public virtual void Commit()
        {
            _context.SaveChanges();
        }

        public string GetLoggedUserInfo()
        {
            if (AppContext.CurrentUser != null)
                return AppContext.CurrentUser.First_Name + ' ' + AppContext.CurrentUser.Last_Name;
            return string.Empty;
        }

        public DateTime CreatedUpdatedDateTime()
        {
            return DateTime.Now;
        }

        public bool SendEmailEnabled()
        {
            string keyEmailEnabled = AppConfig.SendEmail;
            if (string.IsNullOrEmpty(keyEmailEnabled)) return false;
            bool isEmailEnabled = Convert.ToBoolean(keyEmailEnabled);
            return isEmailEnabled;
        }

        public bool CACEnabled()
        {
            string keyCACEnabled = AppConfig.EnableCAC;
            if (string.IsNullOrEmpty(keyCACEnabled)) return false;
            bool isCACEnabled = Convert.ToBoolean(keyCACEnabled);
            return isCACEnabled;
        }

        public virtual IQueryable<T> TopNRecords<T>(IQueryable<T> queryable)
        {
            if (AppContext.TopNRecords.HasValue && AppContext.IsTopRecordsPermitted)
                return queryable.Take(AppContext.TopNRecords.Value);
            return queryable;
        }
    }
}