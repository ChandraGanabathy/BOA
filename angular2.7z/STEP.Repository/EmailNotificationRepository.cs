﻿using System;
using System.Collections.Generic;
using System.Linq;
using STEP.Common;
using STEP.Repository.Interfaces;
using STEP.Models;
using STEP.Interfaces;

namespace STEP.Repository
{
    public class EmailNotificationRepository : EntityBaseRepository<User>, IEmailNotificationRepository
    {
        public EmailNotificationRepository(STEPContext context)
            : base(context)
        {

        }

        public List<Role> GetAllRolesForClient()
        {
            var roles = this._context.Roles.AsNoTracking().ToList<Role>();

            foreach (var item in roles)
            {
                item.Name = item.Name.Replace("Level", "All Level Users");
            }

            return roles;
        }

        public string UploadDocument(Document filedocument)
        {
            var document = new Document
                {
                    FileContent = filedocument.FileContent,
                    FileType = filedocument.FileType,
                    Name = filedocument.Name
                };
            var objFolder = new AppFolderConnect();
            if (!string.IsNullOrEmpty(document.FileContent))
            {
                var newdocument = new Document
                    {
                        FileContent = document.FileContent,
                        FilePath = AppConfig.FileURL,
                        FileType = document.FileType,
                        Name = document.Name
                    };
                document.FileContent = objFolder.UploadDocument(newdocument);
            }
            return string.Empty;
        }

        public List<string> GetUsersByRoleId(List<int> roleIds)
        {
            var roles = (from u in this._context.Users.AsNoTracking()
                         join ur in this._context.User_Role.AsNoTracking() on u.Id equals ur.User_Id
                         join r in this._context.Roles.AsNoTracking() on ur.Role_Id equals r.Id
                         where
                             roleIds.Contains(r.Id)
                             && u.User_Status_Id == AppConstants.CodeCategories.UserStatus
                             && u.User_Status_Key == AppConstants.CodeCategories.UserStatusActive
                         select u.Email_Id
                        ).ToList<string>();
            return roles;
        }

        public string SendEmailNotification(List<int> roleIds, string subject, string content, string filepath, string fileName)
        {
            var toEmail = GetUsersByRoleId(roleIds);
            var strEmailFromUsers = AppContext.CurrentUser.Email_Id;
            var strEmailtoUsers = toEmail.Aggregate(string.Empty, (current, item) => current + (item + ";"));
            try
            {
                if (SendEmailEnabled())
                {
                    var sendMail = new MailMessages();
                    bool isHtmlContent = false; // This email notification send from bulk email. Not any HTML template.
                    var strMessage = sendMail.SendEmailNotification(strEmailtoUsers, strEmailFromUsers, subject, content, filepath, fileName, isHtmlContent);
                    return strMessage;
                }
                return "The email is not sent.Email Features is turned off.";
            }
            catch (Exception ex)
            {
                return "The email is not sent";
            }
        }
    }
}