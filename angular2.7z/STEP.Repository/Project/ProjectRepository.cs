﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using STEP.Common;
using STEP.Interfaces;
using STEP.Models;
using STEP.Models.UIModel;
using System.Reflection;

namespace STEP.Repository
{
	public class ProjectRepository : EntityBaseRepository<Project>, IProjectRepository
	{
		public readonly STEPContext Context;

		public ProjectRepository(STEPContext context)
			: base(context)
		{
			Context = context;
		}

		public string GenerateProjectNumber(string format)
		{
			var project =
				Context.Project.Where(x => x.Project_Number.StartsWith(format))
					   .OrderByDescending(x => x.Id)
					   .Take(1)
					   .FirstOrDefault();

			if (project == null)
			{
				return "00001";
			}

			var projectNumber = project.Project_Number.Substring(project.Project_Number.Length - 5, 5);

			int addProjectNumberByOne;

			Int32.TryParse(projectNumber, out addProjectNumberByOne);

			addProjectNumberByOne = addProjectNumberByOne + 1;

			string appendZeroString = string.Empty;

			switch (Convert.ToString(addProjectNumberByOne).Length)
			{
				case 1:
					appendZeroString = "0000";
					break;
				case 2:
					appendZeroString = "000";
					break;
				case 3:
					appendZeroString = "00";
					break;
				case 4:
					appendZeroString = "00";
					break;
			}
			return string.Format("{0}{1}", appendZeroString,
								 addProjectNumberByOne.ToString(CultureInfo.InvariantCulture));

		}

		public Project UpdateProject(Project project)
		{
			// Get existed Project Info from database
			var dbProject = GetSingle(x => x.Id == project.Id
									  , x => x.Project_Answer
									  , x => x.Project_Document
									  , x => x.Project_Funding
									  , x => x.Project_Note
									  , x => x.Project_Note.Select(z => z.User_Role.User)
									  , x => x.Project_Note.Select(z => z.User_Role.Role)
				);

			project.Created_By = dbProject.Created_By;
			project.Created_Date = dbProject.Created_Date;
			project.Modified_By = GetLoggedUserInfo();
			project.Modified_Date = CreatedUpdatedDateTime();

			dbProject.Project_Owner = project.Project_Owner;

			// Project Audit Details Population
			var auditDetails = ProjectAuditDetails(project, dbProject);

			if (project.Project_Funding != null)
			{
				project.Project_Funding.ToList().ForEach(pf =>
					{
						pf.Modified_By = GetLoggedUserInfo();
						pf.Modified_Date = CreatedUpdatedDateTime();
					});
			}

			if (project.Project_Answer != null)
			{
				project.Project_Answer.ToList().ForEach(pa =>
					{
						pa.Modified_By = GetLoggedUserInfo();
						pa.Modified_Date = CreatedUpdatedDateTime();
					});
			}

			// Update parent [Project]
			Context.Entry(dbProject).CurrentValues.SetValues(project);

			// Update Children-1 [Project_Funding] 
			if (project != null && (project.Project_Funding != null && project.Project_Funding.Any()))
			{
				foreach (var childProjectFunding in project.Project_Funding)
				{
					var existingChildProjectFunding =
						dbProject.Project_Funding.SingleOrDefault(c => c.Id == childProjectFunding.Id &&
																	   childProjectFunding.Id != 0);

					if (existingChildProjectFunding != null)
					{
						childProjectFunding.Created_By = existingChildProjectFunding.Created_By;
						childProjectFunding.Created_Date = existingChildProjectFunding.Created_Date;
						Context.Entry(existingChildProjectFunding).CurrentValues.SetValues(childProjectFunding);
					}
				}
			}

			// Update Children-2 [Project_Answer] 
			if (project != null && (project.Project_Answer != null && project.Project_Answer.Any()))
			{
				foreach (var childProjectAnswer in project.Project_Answer)
				{
					var existingChildProjectAnswer =
						dbProject.Project_Answer.SingleOrDefault(c => c.Id == childProjectAnswer.Id &&
																	  childProjectAnswer.Id != 0);

					if (existingChildProjectAnswer != null)
					{
						childProjectAnswer.Created_By = existingChildProjectAnswer.Created_By;
						childProjectAnswer.Created_Date = existingChildProjectAnswer.Created_Date;
						Context.Entry(existingChildProjectAnswer).CurrentValues.SetValues(childProjectAnswer);
					}
				}
			}

			// Update Children-3 [Project_Document] 
			if (project != null && (project.Project_Document != null && project.Project_Document.Any()))
			{
				foreach (var childProjectDocument in project.Project_Document)
				{
					var existingChildProjectDocument =
						dbProject.Project_Document.SingleOrDefault(c => c.Id == childProjectDocument.Id &&
																		childProjectDocument.Id != 0);

					if (existingChildProjectDocument != null)
					{

						if (childProjectDocument.OverWrite)
						{
							childProjectDocument.Created_By = existingChildProjectDocument.Created_By;
							childProjectDocument.Created_Date = childProjectDocument.Created_Date;
							childProjectDocument.Modified_By = existingChildProjectDocument.Modified_By;
							childProjectDocument.Modified_Date = existingChildProjectDocument.Modified_Date;
							Context.Entry(existingChildProjectDocument).CurrentValues.SetValues(childProjectDocument);
							// Upload Document 
							var document = new Document
								{
									Name = childProjectDocument.Document_Name,
									FileContent = childProjectDocument.FileContent,
									FilePath = childProjectDocument.FilePath,
									FileType = childProjectDocument.FileType,
									OverWrite = true
								};

							var objFolder = new AppFolderConnect();
							if (!string.IsNullOrEmpty(document.FileContent))
							{
								var file = objFolder.OverWriteFile(document);
							}
						}
					}
					else
					{
						// Insert child 
						var newProjecDocument = new Project_Document()
							{
								Project_Id = project.Id,
								Document_Original_Name = childProjectDocument.Document_Original_Name,
								Document_Name = childProjectDocument.Document_Name,
								Created_By = GetLoggedUserInfo(),
								Created_Date = childProjectDocument.Created_Date,
								Modified_By = GetLoggedUserInfo(),
								Modified_Date = CreatedUpdatedDateTime(),
							};
						dbProject.Project_Document.Add(newProjecDocument);

						// Upload Document 
						var document = new Document
							{
								Name = childProjectDocument.Document_Name,
								FileContent = childProjectDocument.FileContent,
								FilePath = childProjectDocument.FilePath,
								FileType = childProjectDocument.FileType
							};

						var objFolder = new AppFolderConnect();
						if (!string.IsNullOrEmpty(document.FileContent))
						{
							var file = objFolder.UploadDocument(document);
						}
					}
				}
			}

			// Update Children-4 [Project_Note] 
			if (project != null && (project.Project_Note != null && project.Project_Note.Any()))
			{
				foreach (var childProjectNote in project.Project_Note)
				{
					var existingChildProjectNote =
						dbProject.Project_Note.SingleOrDefault(c => c.Id == childProjectNote.Id &&
																	childProjectNote.Id != 0);

					if (existingChildProjectNote != null)
					{
						childProjectNote.Created_By = existingChildProjectNote.Created_By;
						childProjectNote.Created_Date = existingChildProjectNote.Created_Date;
						childProjectNote.Modified_By = GetLoggedUserInfo();
						childProjectNote.Modified_Date = CreatedUpdatedDateTime();
						Context.Entry(existingChildProjectNote).CurrentValues.SetValues(childProjectNote);
					}

					else
					{
						// Insert child 
						var newProjecDocument = new Project_Note()
							{
								Project_Id = project.Id,
								Type_Id = AppConstants.CodeCategories.Type,
								Type_Key = AppConstants.Types.Manual,
								User_Role_Id = childProjectNote.User_Role_Id,
								Notes = childProjectNote.Notes,
								SubSystem_Ref_Id = (int?)null,
								Approval_Status_Id = AppConstants.CodeCategories.ApprovalStatuss,
								Approval_Status_Key = AppConstants.CodeCategories.ProjectCreated,
								Created_By = childProjectNote.Created_By,
								Created_Date = childProjectNote.Created_Date,
								Modified_By = childProjectNote.Created_By,
								Modified_Date = childProjectNote.Created_Date,
							};
						dbProject.Project_Note.Add(newProjecDocument);
					}
				}
			}

			Context.Entry<Project>(dbProject).State = EntityState.Modified;
			Context.SaveChanges();
			Context.Entry<Project>(dbProject).Reload();

			InsertUpdateAuditDetails(auditDetails);

			return dbProject;
		}

		public bool ProjectFundingBulkUpdate(List<Project_Funding> projectFunding)
		{
			var uniqueTransactionId = System.Guid.NewGuid();
			var lstAudit = new List<Audit>();
			// Project Funding Log
			//==============================================
			foreach (var itemFunding in projectFunding)
			{
				var dbItemFunding = Context.Project_Funding.FirstOrDefault(x => x.Id == itemFunding.Id);

				var lstAuditLogFunding = AppExtensions.CompareEntityForAudit(itemFunding, dbItemFunding);
				if (lstAuditLogFunding != null && lstAuditLogFunding.Any())
				{
					if (dbItemFunding != null)
					{
						dbItemFunding.Funded = itemFunding.Funded;
						dbItemFunding.Funding_Status_Code_Key = itemFunding.Funding_Status_Code_Key;
						dbItemFunding.Modified_By = GetLoggedUserInfo();
						dbItemFunding.Modified_Date = CreatedUpdatedDateTime();

						Context.Entry(dbItemFunding).State = EntityState.Modified;
						Context.SaveChanges();

						var auditFunding = PopulateAuditDetails(AppConstants.AuditTableName.ProjectFunding,
																itemFunding.Id, itemFunding.Project_Id,
																uniqueTransactionId,
																lstAuditLogFunding, dbItemFunding.FY);
						lstAudit.Add(auditFunding);

					}
				}
			}

			InsertUpdateAuditDetails(lstAudit);

			return true;
		}

		private IEnumerable<Audit> ProjectAuditDetails(Project project, Project dbProject)
		{
			List<string> propertyExclude = new List<string> { "Resource_Sponsor_Id", "Resource_Sponsor_Key" };

			var lstAudit = new List<Audit>();
			var uniqueTransactionId = System.Guid.NewGuid();
			// 1. Project Log
			var lstAuditLogProject = AppExtensions.CompareEntityForAudit(project, dbProject, propertyExclude);
			if (lstAuditLogProject != null && lstAuditLogProject.Any())
			{
				var auditProject = PopulateAuditDetails(AppConstants.AuditTableName.Project, project.Id, project.Id, uniqueTransactionId,
														lstAuditLogProject, null);
				lstAudit.Add(auditProject);
			}

			// 2. Project Funding Log
			//==============================================

			foreach (var itemFunding in project.Project_Funding.ToList())
			{
				var dbItemFunding = dbProject.Project_Funding.FirstOrDefault(x => x.Id == itemFunding.Id);
				var lstAuditLogFunding = AppExtensions.CompareEntityForAudit(itemFunding, dbItemFunding);
				if (lstAuditLogFunding != null && lstAuditLogFunding.Any())
				{
					if (dbItemFunding != null)
					{
						var auditFunding = PopulateAuditDetails(AppConstants.AuditTableName.ProjectFunding,
																dbItemFunding.Id, project.Id, uniqueTransactionId,
																lstAuditLogFunding, dbItemFunding.FY);
						lstAudit.Add(auditFunding);
					}
				}
			}

			// 3. Project Answer Log
			//==============================================

			foreach (var itemProjectAnswer in project.Project_Answer.ToList())
			{
				var dbProjectAnswer = dbProject.Project_Answer.FirstOrDefault(x => x.Id == itemProjectAnswer.Id);

				var lstAuditLogProjectAnswer = AppExtensions.CompareEntityForAudit(itemProjectAnswer, dbProjectAnswer);
				if (lstAuditLogProjectAnswer != null && lstAuditLogProjectAnswer.Any())
				{
					if (dbProjectAnswer != null)
					{
						var auditProjectAnswer = PopulateAuditDetails(AppConstants.AuditTableName.ProjectAnswer,
																	  dbProjectAnswer.Id, project.Id, uniqueTransactionId,
																	  lstAuditLogProjectAnswer, null);
						lstAudit.Add(auditProjectAnswer);
					}
				}
			}

			// 4. Project Document Log
			//==============================================

			foreach (var itemProjectDocument in project.Project_Document.ToList())
			{
				var dbProjectDocument = dbProject.Project_Document.FirstOrDefault(x => x.Id == itemProjectDocument.Id);

				var lstAuditLogProjectDocument = AppExtensions.CompareEntityForAudit(itemProjectDocument,
																					 dbProjectDocument);
				if (lstAuditLogProjectDocument != null && lstAuditLogProjectDocument.Any())
				{
					if (dbProjectDocument != null)
					{
						var auditProjectDocument = PopulateAuditDetails(AppConstants.AuditTableName.ProjectDocument,
																		dbProjectDocument.Id, project.Id, uniqueTransactionId,
																		lstAuditLogProjectDocument, null);
						lstAudit.Add(auditProjectDocument);
					}
				}
			}

			// 4. Project Note Log
			//==============================================

			foreach (var itemProjectNote in project.Project_Note.ToList())
			{
				var dbProjectNote = dbProject.Project_Note.FirstOrDefault(x => x.Id == itemProjectNote.Id);

				var lstAuditLogProjectNote = AppExtensions.CompareEntityForAudit(itemProjectNote, dbProjectNote);
				if (lstAuditLogProjectNote != null && lstAuditLogProjectNote.Any())
				{
					if (dbProjectNote != null)
					{
						var auditProjectNote = PopulateAuditDetails(AppConstants.AuditTableName.ProjectNote,
																	dbProjectNote.Id, project.Id, uniqueTransactionId,
																	lstAuditLogProjectNote, null);
						lstAudit.Add(auditProjectNote);
					}
				}
			}

			return lstAudit;
		}

		private Audit PopulateAuditDetails(string tableName, int primaryKey, int projectId, Guid uniqueTransactionId,
										   IEnumerable<AuditLog> lstAuditLog, int? fiscalYear)
		{
			var audit = new Audit
				{
					Table_Name = tableName,
					Project_Id = projectId,
					Primary_Key = primaryKey,
					User_Role_Id = AppContext.CurrentUserRole.Id,
					Change_Type_Value = AppConstants.ChangeTypes.Update,
					Change_Type_Id = AppConstants.CodeCategories.ChangeType,
					Transaction_Unique_Id = uniqueTransactionId,
					Created_By = GetLoggedUserInfo(),
					Created_Date = CreatedUpdatedDateTime(),
					Modified_By = GetLoggedUserInfo(),
					Modified_Date = CreatedUpdatedDateTime()
				};

			var lstAuditDetails = lstAuditLog.Select(item => new Audit_Details
				{
					Column_Name = string.Format("{0}.{1}", tableName, item.ColumnName),
					Old_Value = item.OldValue,
					New_Value = item.NewValue,
					FY = fiscalYear,
					Created_By = GetLoggedUserInfo(),
					Created_Date = CreatedUpdatedDateTime(),
					Modified_By = GetLoggedUserInfo(),
					Modified_Date = CreatedUpdatedDateTime(),
				}).ToList();

			audit.Audit_Details = lstAuditDetails;
			return audit;
		}

		private void InsertUpdateAuditDetails(IEnumerable<Audit> audits)
		{
			foreach (var itemAudit in audits)
			{
				Context.Set<Audit>().Add(itemAudit);
				Context.Entry(itemAudit).State = EntityState.Added;
				Context.SaveChanges();
			}
		}

		public object GetProjectListsData(ProjectSearchFilter projectSearchFilter)
		{
			var hierarchyDataIds = default(List<int>);
			int impactmissionId = Convert.ToInt16(projectSearchFilter.ImpactMission);
			projectSearchFilter.ProjectName = AppExtensions.DataTrim(projectSearchFilter.ProjectName);
			projectSearchFilter.ProjectNumber = AppExtensions.DataTrim(projectSearchFilter.ProjectNumber);

			if (projectSearchFilter.HierarchyDataId.HasValue == false)
			{
				hierarchyDataIds = STEP.Common.AppContext.CurrentUserRoleHierarchyData.Select(x => x.Id).ToList();
			}
			else
			{
				hierarchyDataIds =
					STEP.Common.AppContext.CurrentUserRoleHierarchyData.Where(
						x => x.Id == projectSearchFilter.HierarchyDataId.Value).Select(y => y.Id).ToList();
			}

			var projectListData = (from p in Context.Project.AsNoTracking()
								   join pf in Context.Project_Funding.AsNoTracking() on p.Id equals pf.Project_Id
								   join c in Context.Catalogs.AsNoTracking() on p.Catalog_Id equals c.Id
								   join plm in Context.Pillar_LawReg_Mapping.AsNoTracking() on
									   c.Pillar_Lawreg_Mapping_Id equals plm.Id
								   join pb2M in Context.Pillar_PB28_Mapping.AsNoTracking() on c.Pillar_PB28_Mapping_Id
									   equals pb2M.Id
								   join hd in Context.Hierarchy_Data.AsNoTracking() on p.Hierarchy_Data_Id equals hd.Id

								   join cvPlr in Context.Code_Value.AsNoTracking()
									   on plm.Pillar_Id equals cvPlr.Code_ID
									   into cvPlrs
								   from cvPillar in
									   cvPlrs.Where(x => x.Code_Value_Key == plm.Pillar_Key)
											 .DefaultIfEmpty()

								   join cvlg in Context.Code_Value.AsNoTracking()
									   on plm.LawReg_Id equals cvlg.Code_ID
									   into cvlgs
								   from cvlawReg in
									   cvlgs.Where(x => x.Code_Value_Key == plm.LawReg_Key)
											.DefaultIfEmpty()

								   join cvPa in Context.Code_Value.AsNoTracking()
									   on plm.ProgramArea_Id equals cvPa.Code_ID
									   into cvPas
								   from cvProgramArea in
									   cvPas.Where(x => x.Code_Value_Key == plm.ProgramArea_Key)
											.DefaultIfEmpty()

								   join cvPb28T in Context.Code_Value.AsNoTracking()
									   on pb2M.Title_Id equals cvPb28T.Code_ID
									   into cvPb28Ts
								   from cvPb28Title in
									   cvPb28Ts.Where(x => x.Code_Value_Key == pb2M.Title_Key)
											   .DefaultIfEmpty()

								   join cvPb28C in Context.Code_Value.AsNoTracking()
									   on pb2M.Category_Id equals cvPb28C.Code_ID
									   into cvPb28Cs
								   from cvPb28Category in
									   cvPb28Cs.Where(x => x.Code_Value_Key == pb2M.Category_Key)
											   .DefaultIfEmpty()

								   join cvApprovalStatus in Context.Code_Value.AsNoTracking()
									   on pf.Approval_Status_Id equals cvApprovalStatus.Code_ID
									   into cvFundApprovalStatus
								   from cvFundingApprovalStatus in
									   cvFundApprovalStatus.Where(x => x.Code_Value_Key == pf.Approval_Status_Key)
														   .DefaultIfEmpty()

								   join cvStatus in Context.Code_Value.AsNoTracking()
									   on pf.Funding_Status_Code_Id equals cvStatus.Code_ID
									   into cvFundStatus
								   from cvFundingStatus in
									   cvFundStatus.Where(x => x.Code_Value_Key == pf.Funding_Status_Code_Key)
												   .DefaultIfEmpty()

								   join cvIMPMiss in Context.Code_Value.AsNoTracking()
									   on p.Impact_to_Mission_Id equals cvIMPMiss.Code_ID
									   into cvImpacts
								   from cvmisImp in
									   cvImpacts.Where(x => x.Code_Value_Key == p.Impact_to_Mission_Key)
												.DefaultIfEmpty()

								   join cvCls in Context.Code_Value.AsNoTracking()
									   on p.Class_Id equals cvCls.Code_ID
									   into cvClss
								   from cvClass in
									   cvClss.Where(x => x.Code_Value_Key == p.Class_Key)
											 .DefaultIfEmpty()
								   where
									   (string.IsNullOrEmpty(
										   projectSearchFilter.ProjectNumber) ||
										p.Project_Number.ToLower()
										 .Contains(
											 projectSearchFilter
												 .ProjectNumber.ToLower()))
									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.ProjectName) ||
										p.Project_Name.Trim().ToLower()
										 .Contains(
											 projectSearchFilter.ProjectName.Trim().ToLower()))
									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.PillarKey) ||
										projectSearchFilter.PillarKey.ToUpper()
														   .Equals(AppConstants.CodeCategories.ALL)
										||
										plm.Pillar_Key.ToLower()
										   .Equals(projectSearchFilter.PillarKey.ToLower()))

									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.LawRegKey) ||
										projectSearchFilter.LawRegKey.ToUpper()
														   .Equals(AppConstants.CodeCategories.ALL)
										||
										plm.LawReg_Key.ToLower()
										   .Equals(projectSearchFilter.LawRegKey.ToLower()))

									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.ProgramAreaKey) ||
										projectSearchFilter.ProgramAreaKey.ToUpper()
														   .Equals(AppConstants.CodeCategories.ALL)
										||
										plm.ProgramArea_Key.ToLower()
										   .Equals(projectSearchFilter.ProgramAreaKey.ToLower()))

									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.PB28TitleKey) ||
										projectSearchFilter.PB28TitleKey.ToUpper()
														   .Equals(AppConstants.CodeCategories.ALL)
										||
										pb2M.Title_Key.ToLower()
											.Equals(projectSearchFilter.PB28TitleKey.ToLower()))

									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.PB28CategoryKey) ||
										projectSearchFilter.PB28CategoryKey.ToUpper()
														   .Equals(AppConstants.CodeCategories.ALL)
										||
										pb2M.Category_Key.ToLower()
											.Equals(projectSearchFilter.PB28CategoryKey.ToLower()))
									   &&
									   (pf.FY == projectSearchFilter.FiscalYear)
									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.FundingApprovalStatusKey) ||
										pf.Approval_Status_Key == projectSearchFilter.FundingApprovalStatusKey)
									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.FundingStatusKey) ||
										pf.Funding_Status_Code_Key == projectSearchFilter.FundingStatusKey)
									   &&
									   (
										   hierarchyDataIds.Contains(p.Hierarchy_Data_Id.Value)
									   )
									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.ImpactMission) ||
										projectSearchFilter.ImpactMission.ToUpper()
														   .Equals(AppConstants.CodeCategories.ALL) ||
										cvmisImp.Id.Equals(impactmissionId))

									   &&
									   (string.IsNullOrEmpty(
										   projectSearchFilter.Class) ||
										projectSearchFilter.Class.ToUpper()
														   .Equals(AppConstants.CodeCategories.ALL) ||
										p.Class_Key.Equals(projectSearchFilter.Class))

								   select new
									   {
										   p.Id,
										   p.Project_Number,
										   p.Project_Name,
										   Property = hd.Name,
										   Pillar = cvPillar.Code_Value_Description,
										   LawReg = cvlawReg.Code_Value_Description,
										   ProgramArea = cvProgramArea.Code_Value_Description,
										   PB28Title = cvPb28Title.Code_Value_Description,
										   PB28Category = cvPb28Category.Code_Value_Description,
										   pf.FY,
										   FundingApprovalStatus = cvFundingApprovalStatus.Code_Value_Description,
										   FundingStatus = cvFundingStatus.Code_Value_Description,
										   FundingId = pf.Id,
										   pf.Programmed,
										   pf.Validated,
										   pf.Planned,
										   pf.Funded,
										   pf.Obligated,
										   pf.HQ_Priority,
										   pf.MSC_Priority,
										   pf.Priority,
										   pf.Is_UFR,
										   pf.Approval_Status_Id,
										   pf.Approval_Status_Key,
										   pf.Funding_Status_Code_Id,
										   pf.Funding_Status_Code_Key,
										   pf.MDEP_Id,
										   pf.MDEP_Key,
										   Class = cvClass.Code_Value_Description,
										   ImpactMission =
										   cvmisImp.Code_Value_Description ?? "",
									   }
								  );

			var result = TopNRecords(projectListData).ToList();

			return result;
		}

		public object GetMyApprovalInboxProjects()
		{
			var currentUserRole = STEP.Common.AppContext.CurrentUserRole.Role;
			if (!AppContext.SessionActions.Any(
				x =>
				x.Action_Name.Equals(AppConstants.ActionProperty.MyApproval) &&
				x.Controller_Name.Equals(AppConstants.ControllerProperty.DashBoard) &&
				x.Type_Key.Equals(AppConstants.ActionTypeKey.UITypeKey)))
			{
				return null;
			}
			// pass current user Login role id and
			// Get All Current Status from approval process table

			var currentStatusAll =
				Context.Approval_Process.Where(
					x =>
					x.Role_Id == currentUserRole.Id &&
					(x.Action_Key == STEP.Common.AppConstants.ApprovalActions.Approve ||
					 x.Action_Key == STEP.Common.AppConstants.ApprovalActions.Disapprove))
					   .Select(
						   x =>
						   new
							   {
								   current_Status = x.CurrentStatus_Approval_Status_Key,
								   Project_Type_Key = x.Project_Type_Key
							   })
					   .Distinct().AsEnumerable();

			var hierarchyDataIds =
				STEP.Common.AppContext.CurrentUserRoleHierarchyData.Select(x => x.Id).Distinct().ToList();

			var myapprovalProjects = (from p in Context.Project.AsNoTracking()
									  join pf in Context.Project_Funding.AsNoTracking() on p.Id equals pf.Project_Id
									  join c in Context.Catalogs.AsNoTracking() on p.Catalog_Id equals c.Id
									  join plm in Context.Pillar_LawReg_Mapping.AsNoTracking() on
										  c.Pillar_Lawreg_Mapping_Id equals plm.Id
									  join pb2M in Context.Pillar_PB28_Mapping.AsNoTracking() on
										  c.Pillar_PB28_Mapping_Id
										  equals pb2M.Id
									  join hd in Context.Hierarchy_Data.AsNoTracking() on p.Hierarchy_Data_Id equals
										  hd.Id

									  join cvPlr in Context.Code_Value.AsNoTracking()
										  on plm.Pillar_Id equals cvPlr.Code_ID
										  into cvPlrs
									  from cvPillar in
										  cvPlrs.Where(x => x.Code_Value_Key == plm.Pillar_Key)
												.DefaultIfEmpty()

									  join cvlg in Context.Code_Value.AsNoTracking()
										  on plm.LawReg_Id equals cvlg.Code_ID
										  into cvlgs
									  from cvlawReg in
										  cvlgs.Where(x => x.Code_Value_Key == plm.LawReg_Key)
											   .DefaultIfEmpty()

									  join cvPa in Context.Code_Value.AsNoTracking()
										  on plm.ProgramArea_Id equals cvPa.Code_ID
										  into cvPas
									  from cvProgramArea in
										  cvPas.Where(x => x.Code_Value_Key == plm.ProgramArea_Key)
											   .DefaultIfEmpty()

									  join cvStatus in Context.Code_Value.AsNoTracking()
										  on pf.Approval_Status_Id equals cvStatus.Code_ID
										  into cvFundStatus
									  from cvFundingStatus in
										  cvFundStatus.Where(x => x.Code_Value_Key == pf.Approval_Status_Key)
													  .DefaultIfEmpty()

									  where
										  hierarchyDataIds.Contains(p.Hierarchy_Data_Id.Value)
										  && pf.FY == STEP.Common.AppContext.CurrentFiscalYear.FY

									  select new
										  {
											  p.Id,
											  p.Project_Number,
											  p.Project_Name,
											  Property = hd.Name,
											  Pillar = cvPillar.Code_Value_Description,
											  MLR = cvlawReg.Code_Value_Description,
											  Program_Area = cvProgramArea.Code_Value_Description,
											  FisalYear = pf.FY,
											  Status = cvFundingStatus.Code_Value_Description,
											  Project_Type_Key = p.Hierarchy_Data.Hierarchy_Level_Key,
											  Current_Status = pf.Approval_Status_Key
										  }
									 ).ToList();

			var approvalInboxlist = (from i in currentStatusAll
									 join m in myapprovalProjects
										 on i.Project_Type_Key equals m.Project_Type_Key
									 where i.current_Status == m.Current_Status
									 select m).ToList();

			return approvalInboxlist;
		}

		public object ViewProjectHistoryByProjectId(int projectId)
		{
			var codeIdsFromAuditDisplayTable =
				Context.Audit_Display.Where(x => x.Code_Id.HasValue).Select(x => x.Code_Id).Distinct().ToList();

			var codeValues = Context.Code_Value.Where(x => codeIdsFromAuditDisplayTable.Contains(x.Code_ID));

			var getProjectOwnersData = (from a in Context.Audits.AsNoTracking()
										join ad in Context.Audit_Details.AsNoTracking() on a.Id equals ad.Audit_Id
										where a.Project_Id == projectId && ad.Column_Name == "Project.Owner_ID"
										select new
											{
												ad.Old_Value,
												ad.New_Value
											}).ToList();
			var usersId =
				getProjectOwnersData.Select(x => x.Old_Value)
						.ToList()
						.Union(getProjectOwnersData.Select(y => y.New_Value))
						.Select(int.Parse)
						.ToList();

			var users = Context.Users.Where(x => usersId.Contains(x.Id)).ToList();

			//var enumerable = users as User[] ?? users.ToArray();
			var projectHistory = (from a in Context.Audits.AsNoTracking()
								  join ad in Context.Audit_Details.AsNoTracking() on a.Id equals ad.Audit_Id
								  join ur in Context.User_Role.AsNoTracking() on a.User_Role_Id equals ur.Id
								  join r in Context.Roles.AsNoTracking() on ur.Role_Id equals r.Id
								  join u in Context.Users.AsNoTracking() on ur.User_Id equals u.Id

								  join ad1 in Context.Audit_Display.AsNoTracking()
									  on a.Table_Name equals ad1.Entity_Name
									  into ads
								  from auditDisplay in ads

								  join ad1 in Context.Audit_Display.AsNoTracking()
									  on ad.Column_Name equals ad1.Entity_Name
									  into ad1S
								  from auditDisplay1 in ad1S
								  where a.Project_Id == projectId

								  select new
									  {
										  a.Transaction_Unique_Id,
										  a.Id,
										  UserName =
									  u.First_Name + " " + u.Middle_Name + " " + u.Last_Name,
										  RoleName = r.Name,
										  a.Modified_Date,
										  a.Created_Date,

										  auditDisplay1.Display_Name,

										  Old_Value = auditDisplay1.Code_Id.HasValue == false
														  ? ad.Old_Value
														  : codeValues.FirstOrDefault(
															  x =>
															  x.Code_ID == auditDisplay1.Code_Id.Value &&
															  x.Code_Value_Key == ad.Old_Value)
																	  .Code_Value_Description,

										  New_Value = auditDisplay1.Code_Id.HasValue == false
														  ? ad.New_Value
														  : codeValues.FirstOrDefault(
															  x =>
															  x.Code_ID == auditDisplay1.Code_Id.Value &&
															  x.Code_Value_Key == ad.New_Value)
																	  .Code_Value_Description,
										  FiscalYear = ad.FY,
										  ad.Column_Name

									  }).ToList();

			var getDistinctTransactionIds = projectHistory.Select(x => x.Transaction_Unique_Id).Distinct();

			var lstAudit = new List<Audit>();
			foreach (var distinctTransactionId in getDistinctTransactionIds)
			{
				var audit = new Audit();
				var item1 = projectHistory.Where(x => x.Transaction_Unique_Id == distinctTransactionId).ToList();
				if (item1.Any())
				{
					var firstOrDefault = item1.FirstOrDefault();
					if (firstOrDefault != null)
					{
						audit.Id = firstOrDefault.Id;
						audit.Role = firstOrDefault.RoleName;
						audit.UserName = firstOrDefault.UserName;
						audit.Modified_Date = firstOrDefault.Modified_Date;
						audit.Created_Date = firstOrDefault.Created_Date;
					}
				}

				var lstAuditDetails = item1.Select(obj => new Audit_Details
					{
						Column_Name = obj.Display_Name,
						Old_Value =
							obj.Old_Value == null
								? string.Empty
								: obj.Column_Name == "Project.Owner_ID"
									  ? users.Where(x => x.Id == Convert.ToInt32(obj.Old_Value))
											 .Select(x => x.First_Name + " " + x.Last_Name)
											 .FirstOrDefault()
									  : obj.Old_Value,

						New_Value = obj.New_Value == null
										? string.Empty
										: obj.Column_Name == "Project.Owner_ID"
											  ? users.Where(x => x.Id == Convert.ToInt32(obj.New_Value))
													 .Select(x => x.First_Name + " " + x.Last_Name)
													 .FirstOrDefault()
											  : obj.New_Value,

						FY = obj.FiscalYear
					}).ToList();

				audit.Audit_Details = lstAuditDetails;

				lstAudit.Add(audit);
			}

			return lstAudit.OrderByDescending(x => x.Modified_Date);
		}

		public List<Project> MyInboxProjects()
		{
			List<Project> Projects = (from p in Context.Project
									  join pf in Context.Project_Funding on p.Id equals pf.Project_Id
									  where pf.FY == DateTime.Now.Year && pf.Approval_Status_Id == 2010 && pf.Approval_Status_Key == "SUBT"
									  select p).ToList();

			return Projects;
		}

		public List<ProjectDetails> MyProjects(int User_Id, Fiscal_Year FY)
		{
			List<ProjectDetails> Projects = (from p in Context.Project
											 join Fund in Context.Project_Funding on p.Id equals Fund.Project_Id
											 join CVF in Context.Code_Value on new { CVF_Id = Fund.Approval_Status_Id, CVF_Key = Fund.Approval_Status_Key } equals new { CVF_Id = CVF.Code_ID, CVF_Key = CVF.Code_Value_Key }
											 join Cat in Context.Catalogs on p.Catalog_Id equals Cat.Id
											 join PLR in Context.Pillar_LawReg_Mapping on Cat.Pillar_Lawreg_Mapping_Id equals PLR.Id
											 join CVP in Context.Code_Value on new { CVP_Id = PLR.Pillar_Id, CVP_Key = PLR.Pillar_Key } equals new { CVP_Id = CVP.Code_ID, CVP_Key = CVP.Code_Value_Key }
											 join CVLR in Context.Code_Value on new { CV_Id = PLR.LawReg_Id, CV_Key = PLR.LawReg_Key } equals new { CV_Id = CVLR.Code_ID, CV_Key = CVLR.Code_Value_Key }
											 join CVPA in Context.Code_Value on new { CVPA_Id = PLR.ProgramArea_Id, CVPA_Key = PLR.ProgramArea_Key } equals new { CVPA_Id = CVPA.Code_ID, CVPA_Key = CVPA.Code_Value_Key }
											 where p.Owner_ID == User_Id && Fund.FY == FY.FY
											 //&& p.Created_User_Role_Id==STEP.Common.AppContext.CurrentUserRole.Id
											 orderby p.Created_Date descending
											 select new ProjectDetails
											 {
												 Id = p.Id,
												 Project_Name = p.Project_Name,
												 Project_Number = p.Project_Number,
												 Pillar = CVP.Code_Value_Description,
												 MLR = CVLR.Code_Value_Description,
												 Program_Area = CVPA.Code_Value_Description,
												 Status = CVF.Code_Value_Description
											 }).ToList();

			return Projects;
		}

		public List<ChartData> PFChartData(IEnumerable<Hierarchy_Data> Heirarchy_Data, Fiscal_Year FY)
		{
			List<int> lstH_ID = (from H in Heirarchy_Data.ToList()
								 select H.Id).ToList();

			var objChartData = (from p in Context.Project
								join Fund in Context.Project_Funding on p.Id equals Fund.Project_Id
								where lstH_ID.Contains(p.Hierarchy_Data_Id.Value) && Fund.FY == FY.FY && Fund.Approval_Status_Id == 2010 && Fund.Approval_Status_Key == "FELI"
								group Fund by 1 into c
								select new
								{
									Validated = c.Sum(item => item.Validated),
									Programmed = c.Sum(item => item.Programmed),
									Planned = c.Sum(item => item.Planned),
									Funded = c.Sum(item => item.Funded),
									Obligated = c.Sum(item => item.Obligated),

								}).ToList();

			List<ChartData> ChartData = new List<ChartData>();
			if (objChartData.Count > 0)
			{
				ChartData.Add(new ChartData { Key = "Validated", Value = ((objChartData[0].Validated != null) ? objChartData[0].Validated : 0) });
				ChartData.Add(new ChartData { Key = "Programmed", Value = ((objChartData[0].Programmed != null) ? objChartData[0].Programmed : 0) });
				ChartData.Add(new ChartData { Key = "Funded", Value = ((objChartData[0].Funded != null) ? objChartData[0].Funded : 0) });
				ChartData.Add(new ChartData { Key = "Obligated", Value = ((objChartData[0].Obligated != null) ? objChartData[0].Obligated : 0) });
			}
			return ChartData;
		}

		public List<ChartData> PercentFundChartData(IEnumerable<Hierarchy_Data> Heirarchy_Data)
		{
			var lstHId = (from h in Heirarchy_Data.ToList()
						  select h.Id).ToList();

			var chartData = (from p in Context.Project
							 join fund in Context.Project_Funding on p.Id equals fund.Project_Id
							 join cat in Context.Catalogs on p.Catalog_Id equals cat.Id
							 join pla in Context.Pillar_LawReg_Mapping on cat.Pillar_Lawreg_Mapping_Id
								 equals pla.Id
							 join cv in Context.Code_Value on
								 new { CV_Id = pla.Pillar_Id, CV_Key = pla.Pillar_Key } equals
								 new { CV_Id = cv.Code_ID, CV_Key = cv.Code_Value_Key }
							 where
								 lstHId.Contains(p.Hierarchy_Data_Id.Value) &&
								 fund.Approval_Status_Id == 2010 && fund.Approval_Status_Key == "FELI"
							 group new { Fund = fund, CV = cv } by new { cv.Code_Value_Description }
								 into c
								 select new ChartData
									 {
										 Key = c.Key.Code_Value_Description,
										 Value = c.Sum(item => item.Fund.Funded),
									 }).ToList();

			return chartData;
		}

		public List<int> GetFiscalYears()
		{
			List<int> FY = (from fy in Context.Fiscal_Year
							select fy.FY).ToList();
			return FY;
		}

		public List<ChartData> PFChartDetailsData(KpiFilter searchFilter)
		{
			var objChartData = (from p in Context.Project
								join Fund in Context.Project_Funding on p.Id equals Fund.Project_Id
								join cat in Context.Catalogs on p.Catalog_Id equals cat.Id
								join pla in Context.Pillar_LawReg_Mapping on cat.Pillar_Lawreg_Mapping_Id equals pla.Id
								where (Fund.FY == searchFilter.FY || searchFilter.FY == 0) && searchFilter.RoleHierarchyData.Contains(p.Hierarchy_Data_Id.Value) && ((pla.Pillar_Id == 2000 && pla.Pillar_Key == searchFilter.PillarKey) || String.IsNullOrEmpty(searchFilter.PillarKey)) && ((pla.LawReg_Id == 2004 && pla.LawReg_Key == searchFilter.LawRegKey) || String.IsNullOrEmpty(searchFilter.LawRegKey)) && ((pla.ProgramArea_Id == 2005 && pla.ProgramArea_Key == searchFilter.ProgramAreaKey) || String.IsNullOrEmpty(searchFilter.ProgramAreaKey)) && searchFilter.ProjectStatusesData.Contains(Fund.Approval_Status_Key)
								group Fund by 1 into c
								select new
								{
									Validated = c.Sum(item => item.Validated),
									Programmed = c.Sum(item => item.Programmed),
									Planned = c.Sum(item => item.Planned),
									Funded = c.Sum(item => item.Funded),
									Obligated = c.Sum(item => item.Obligated)
								}).ToList();

			List<ChartData> ChartData = new List<ChartData>();
			if (objChartData.Count > 0)
			{
				ChartData.Add(new ChartData { Key = "Validated", Value = objChartData[0].Validated });
				ChartData.Add(new ChartData { Key = "Programmed", Value = objChartData[0].Programmed });
				ChartData.Add(new ChartData { Key = "Funded", Value = objChartData[0].Funded });
				ChartData.Add(new ChartData { Key = "Obligated", Value = objChartData[0].Obligated });
			}

			return ChartData;
		}

		public List<DrilldownChartData> PercentFundedChartDetailsData(KpiFilter searchFilter)
		{
			List<DrilldownChartData> ChartData = (from p in Context.Project
												  join Fund in Context.Project_Funding on p.Id equals Fund.Project_Id
												  join cat in Context.Catalogs on p.Catalog_Id equals cat.Id
												  join pla in Context.Pillar_LawReg_Mapping on
													  cat.Pillar_Lawreg_Mapping_Id equals pla.Id
												  join CV in Context.Code_Value on
													  new {CV_Id = pla.Pillar_Id, CV_Key = pla.Pillar_Key} equals
													  new {CV_Id = CV.Code_ID, CV_Key = CV.Code_Value_Key}
												  where
													  (Fund.FY == searchFilter.FY || searchFilter.FY == 0) &&
													  searchFilter.RoleHierarchyData.Contains(p.Hierarchy_Data_Id.Value) &&
													  searchFilter.ProjectStatusesData.Contains(Fund.Approval_Status_Key)
												  group new {Fund, CV} by
													  new {CV.Code_Value_Key, CV.Code_Value_Description}
												  into c
												  select new DrilldownChartData
													  {
														  ParentId = c.Key.Code_Value_Key,
														  ParentKey = c.Key.Code_Value_Description,
														  //ParentKey = "Pillar",
														  ParentValue =
															  searchFilter.AmountType == "Validated"
																  ? c.Sum(item => item.Fund.Validated)
																  : searchFilter.AmountType == "Programmed"
																		? c.Sum(item => item.Fund.Programmed)
																		: searchFilter.AmountType == "Planned"
																			  ? c.Sum(item => item.Fund.Planned)
																			  : searchFilter.AmountType == "Funded"
																					? c.Sum(item => item.Fund.Funded)
																					: c.Sum(item => item.Fund.Obligated)
													  }).ToList();

			foreach (DrilldownChartData chartDataItem in ChartData)
			{
				List<ChildLevel1> ChildLevel1Data = (from p in Context.Project
													 join Fund in Context.Project_Funding on p.Id equals Fund.Project_Id
													 join cat in Context.Catalogs on p.Catalog_Id equals cat.Id
													 join pla in Context.Pillar_LawReg_Mapping on
														 cat.Pillar_Lawreg_Mapping_Id equals pla.Id
													 join CV in Context.Code_Value on
														 new {CV_Id = pla.LawReg_Id, CV_Key = pla.LawReg_Key} equals
														 new {CV_Id = CV.Code_ID, CV_Key = CV.Code_Value_Key}
													 where
														 (Fund.FY == searchFilter.FY || searchFilter.FY == 0) &&
														 searchFilter.RoleHierarchyData.Contains(
															 p.Hierarchy_Data_Id.Value) &&
														 (pla.Pillar_Id == 2000 &&
														  pla.Pillar_Key == chartDataItem.ParentId) &&
														 searchFilter.ProjectStatusesData.Contains(
															 Fund.Approval_Status_Key)
													 group new {Fund, CV} by
														 new {CV.Code_Value_Key, CV.Code_Value_Description}
													 into c
													 select new ChildLevel1
														 {
															 ChildLevel1Id = c.Key.Code_Value_Key,
															 ChildLevel1Key = c.Key.Code_Value_Description,

															 ChildLevel1Value =
																 searchFilter.AmountType == "Validated"
																	 ? c.Sum(item => item.Fund.Validated)
																	 : searchFilter.AmountType == "Programmed"
																		   ? c.Sum(item => item.Fund.Programmed)
																		   : searchFilter.AmountType == "Planned"
																				 ? c.Sum(item => item.Fund.Planned)
																				 : searchFilter.AmountType == "Funded"
																					   ? c.Sum(item => item.Fund.Funded)
																					   : c.Sum(
																						   item => item.Fund.Obligated)
														 }).ToList();

				foreach (ChildLevel1 childLevel1DataItem in ChildLevel1Data)
				{
					List<ChildLevel2> ChildLevel2Data = (from p in Context.Project
														 join Fund in Context.Project_Funding on p.Id equals
															 Fund.Project_Id
														 join cat in Context.Catalogs on p.Catalog_Id equals cat.Id
														 join pla in Context.Pillar_LawReg_Mapping on
															 cat.Pillar_Lawreg_Mapping_Id equals pla.Id
														 join CV in Context.Code_Value on
															 new
																 {
																	 CV_Id = pla.ProgramArea_Id,
																	 CV_Key = pla.ProgramArea_Key
																 } equals
															 new {CV_Id = CV.Code_ID, CV_Key = CV.Code_Value_Key}
														 where
															 (Fund.FY == searchFilter.FY || searchFilter.FY == 0) &&
															 searchFilter.RoleHierarchyData.Contains(
																 p.Hierarchy_Data_Id.Value) &&
															 (pla.Pillar_Id == 2000 &&
															  pla.Pillar_Key == chartDataItem.ParentId) &&
															 (pla.LawReg_Id == 2004 &&
															  pla.LawReg_Key == childLevel1DataItem.ChildLevel1Id) &&
															 searchFilter.ProjectStatusesData.Contains(
																 Fund.Approval_Status_Key)
														 group new {Fund, CV} by
															 new {CV.Code_Value_Key, CV.Code_Value_Description}
														 into c
														 select new ChildLevel2
															 {
																 ChildLevel2Id = c.Key.Code_Value_Key,
																 ChildLevel2Key = c.Key.Code_Value_Description,
																 //ChildLevel2Key = "Law Reg",
																 ChildLevel2Value =
																	 searchFilter.AmountType == "Validated"
																		 ? c.Sum(item => item.Fund.Validated)
																		 : searchFilter.AmountType == "Programmed"
																			   ? c.Sum(item => item.Fund.Programmed)
																			   : searchFilter.AmountType == "Planned"
																					 ? c.Sum(item => item.Fund.Planned)
																					 : searchFilter.AmountType ==
																					   "Funded"
																						   ? c.Sum(
																							   item => item.Fund.Funded)
																						   : c.Sum(
																							   item =>
																							   item.Fund.Obligated)
															 }).ToList();

					if (ChildLevel2Data.Count() > 0)
					{
						childLevel1DataItem.ChildLevel2 = new List<ChildLevel2>();
						//childLevel1DataItem.ChildLevel2.AddRange(ChildLevel2Data.Where(x => x.ChildLevel2Value > 0));
						childLevel1DataItem.ChildLevel2.AddRange(ChildLevel2Data);
					}
				}

				if (ChildLevel1Data.Count() > 0)
				{
					chartDataItem.ChildLevel1 = new List<ChildLevel1>();
					//chartDataItem.ChildLevel1.AddRange(ChildLevel1Data.Where(x => x.ChildLevel1Value > 0));
					chartDataItem.ChildLevel1.AddRange(ChildLevel1Data);
				}
			}
			if (ChartData.Any())
			{
				var result = ChartData.Where(x => x.ParentValue > 0).ToList();
				return result;
			}
			return ChartData;
		}

		public List<Code_Value> GetProjectStatuses()
		{
			List<Code_Value> lstProjectStatuses = (from cv in Context.Code_Value
												   where (cv.Code_ID == 2010)
												   select cv).ToList();

			return lstProjectStatuses;
		}

		#region Changing project Owner"

		public object GetAllusers()
		{
			var UserListData = (from usr in Context.Users.AsNoTracking()
								select new
								{
									usr.Id,
									Email_Id = usr.First_Name + " " + usr.Last_Name
								}).ToList();

			return UserListData.OrderBy(x => x.Email_Id);
		}

		public object GetProjectOwnerListData(ProjectOwnerSearchFilter projectOwnerSearchFilter)
		{
			int ownerId = Convert.ToInt16(projectOwnerSearchFilter.ProjectOwner);
			int impactmissionId = Convert.ToInt16(projectOwnerSearchFilter.ImpactMission);

			var hierarchyDataIds = default(List<int>);
			IQueryable<ProjectOwnerDetails> queryProjectDetails = null;

			projectOwnerSearchFilter.ProjectName = AppExtensions.DataTrim(projectOwnerSearchFilter.ProjectName);
			projectOwnerSearchFilter.ProjectNumber = AppExtensions.DataTrim(projectOwnerSearchFilter.ProjectNumber);

			if (projectOwnerSearchFilter.HierarchyDataId.HasValue == false)
			{
				hierarchyDataIds = AppContext.CurrentUserRoleHierarchyData.Select(x => x.Id).ToList();
			}
			else
			{
				hierarchyDataIds =
					AppContext.CurrentUserRoleHierarchyData.Where(
						x => x.Id == projectOwnerSearchFilter.HierarchyDataId.Value).Select(y => y.Id).ToList();
			}

			queryProjectDetails = (from p in Context.Project.AsNoTracking()
								   join c in Context.Catalogs.AsNoTracking() on p.Catalog_Id equals c.Id
								   join plm in Context.Pillar_LawReg_Mapping.AsNoTracking() on
									   c.Pillar_Lawreg_Mapping_Id equals plm.Id
								   join hd in Context.Hierarchy_Data.AsNoTracking() on p.Hierarchy_Data_Id equals hd.Id

								   join cvPlr in Context.Code_Value.AsNoTracking()
									   on plm.Pillar_Id equals cvPlr.Code_ID
									   into cvPlrs
								   from cvPillar in
									   cvPlrs.Where(x => x.Code_Value_Key == plm.Pillar_Key)
											 .DefaultIfEmpty()

								   join cvlg in Context.Code_Value.AsNoTracking()
									   on plm.LawReg_Id equals cvlg.Code_ID
									   into cvlgs
								   from cvlawReg in
									   cvlgs.Where(x => x.Code_Value_Key == plm.LawReg_Key)
											.DefaultIfEmpty()

								   join cvPa in Context.Code_Value.AsNoTracking()
									   on plm.ProgramArea_Id equals cvPa.Code_ID
									   into cvPas
								   from cvProgramArea in
									   cvPas.Where(x => x.Code_Value_Key == plm.ProgramArea_Key)
											.DefaultIfEmpty()
								   join usr in Context.Users.AsNoTracking()
									   on p.Owner_ID equals usr.Id
								   join cvIMPMiss in Context.Code_Value.AsNoTracking()
									   on p.Impact_to_Mission_Id equals cvIMPMiss.Code_ID
									   into cvImpacts
								   from cvmisImp in
									   cvImpacts.Where(x => x.Code_Value_Key == p.Impact_to_Mission_Key)
												.DefaultIfEmpty()

								   where
									   (string.IsNullOrEmpty(
										   projectOwnerSearchFilter.ProjectNumber) ||
										p.Project_Number.ToLower()
										 .Contains(
											 projectOwnerSearchFilter
												 .ProjectNumber.ToLower()))
									   &&
									   (string.IsNullOrEmpty(
										   projectOwnerSearchFilter.ProjectName) ||
										p.Project_Name.Trim().ToLower()
										 .Contains(
											 projectOwnerSearchFilter.ProjectName.Trim().ToLower()))
									   &&
									   (string.IsNullOrEmpty(
										   projectOwnerSearchFilter.PillarKey) ||
										projectOwnerSearchFilter.PillarKey.ToUpper()
																.Equals(AppConstants.CodeCategories.ALL)
										||
										plm.Pillar_Key.ToLower()
										   .Equals(projectOwnerSearchFilter.PillarKey.ToLower()))

									   &&
									   (string.IsNullOrEmpty(
										   projectOwnerSearchFilter.LawRegKey) ||
										projectOwnerSearchFilter.LawRegKey.ToUpper()
																.Equals(AppConstants.CodeCategories.ALL)
										||
										plm.LawReg_Key.ToLower()
										   .Equals(projectOwnerSearchFilter.LawRegKey.ToLower()))

									   &&
									   (string.IsNullOrEmpty(
										   projectOwnerSearchFilter.ProgramAreaKey) ||
										projectOwnerSearchFilter.ProgramAreaKey.ToUpper()
																.Equals(AppConstants.CodeCategories.ALL)
										||
										plm.ProgramArea_Key.ToLower()
										   .Equals(projectOwnerSearchFilter.ProgramAreaKey.ToLower()))

									   &&
									   (
										   hierarchyDataIds.Contains(p.Hierarchy_Data_Id.Value)
									   )
									   &&
									   (
										   (string.IsNullOrEmpty(projectOwnerSearchFilter.ProjectOwner) ||
											projectOwnerSearchFilter.ProjectOwner.ToUpper()
																	.Equals(AppConstants.CodeCategories.ALL) ||
											usr.Id.Equals(ownerId))
									   )
									   &&
									   (string.IsNullOrEmpty(
										   projectOwnerSearchFilter.ImpactMission) ||
										projectOwnerSearchFilter.ImpactMission.ToUpper()
																.Equals(AppConstants.CodeCategories.ALL) ||
										cvmisImp.Id.Equals(impactmissionId))
								   select new ProjectOwnerDetails
									   {
										   Id = p.Id,
										   Project_Number = p.Project_Number,
										   Project_Name = p.Project_Name,
										   Property = hd.Name,
										   Pillar = cvPillar.Code_Value_Description,
										   LawReg = cvlawReg.Code_Value_Description,
										   ProgramArea = cvProgramArea.Code_Value_Description,
										   HierarchyDataId = p.Hierarchy_Data_Id.Value,
										   ExistingOwner = usr.First_Name + " " + usr.Last_Name,
										   ExistingOwnerId = usr.Id,
										   ImpactMission =
											   cvmisImp.Code_Value_Description == null
												   ? ""
												   : cvmisImp.Code_Value_Description,
									   }

								  );
			var projectOwnerListData = TopNRecords(queryProjectDetails).ToList();
			projectOwnerListData.ForEach(x =>
		   {
			   x.Users = GetUsersForProjectOwner(x.HierarchyDataId, x.ExistingOwnerId);
		   });

			return projectOwnerListData;
		}

		public object GetAllImpactMission()
		{
			var impactMissionListData = (from cv in Context.Code_Value
										 where (cv.Code_ID.Equals(AppConstants.CodeCategories.ImpacttoMission))
										 orderby cv.SequenceNumber ascending
										 select new
											 {
												 cv.Id,
												 Name = cv.Code_Value_Description
											 }).ToList();

			return impactMissionListData;
		}

		private IEnumerable<OwnerList> GetUsersForProjectOwner(int hierarchyDataId, int existingOwnerId)
		{
			/*
			 SELECT	CH.ID, 
									PA.Id AS "PARENT_ID",
									PA1.Id AS "PARENT_ID_1"
							FROM Hierarchy_Data CH
								LEFT OUTER JOIN Hierarchy_Data PA
									ON CH.Parent_Id = PA.ID
								LEFT OUTER JOIN Hierarchy_Data PA1
									ON PA.Parent_Id = PA1.ID		
							Where CH.Id=24
			 */
			var data = (from ch in Context.Hierarchy_Data

						join pa in Context.Hierarchy_Data on ch.Parent_Id equals pa.Id
							into paJoin
						from pa in paJoin.DefaultIfEmpty()

						join pa1 in Context.Hierarchy_Data on pa.Parent_Id equals pa1.Id
							into pa1Join
						from pa1 in pa1Join.DefaultIfEmpty()

						where
							ch.Id == hierarchyDataId
						select new
							{
								ch.Id,
								PARENT_ID = (int?) pa.Id,
								PARENT_ID_1 = (int?) pa1.Id
							}).ToList();

			var hierarchyIds =
				data.Select(x => x.Id)
					.ToList()
					.Union(data.Where(y => y.PARENT_ID.HasValue).Select(y => y.PARENT_ID.Value))
					.Union(data.Where(y => y.PARENT_ID_1.HasValue).Select(y => y.PARENT_ID_1.Value))
					.ToList().Distinct().ToList();

			var oList = (from ura in Context.User_Role_Hierarchy_Assoication
						 where hierarchyIds.Contains(ura.Hierarchy_Data.Id)
							   && ura.User_Role.User.User_Status_Id.Equals(AppConstants.CodeCategories.UserStatus) &&
							   ura.User_Role.User.User_Status_Key.Equals(AppConstants.CodeCategories.UserStatusActive)
							   &&
							   ura.User_Role.User_Role_Status_Key.Equals(AppConstants.CodeCategories.UserStatusActive)
							   && !AppConstants.Readonly.ReadOnly.Contains(ura.User_Role.Role.Role_Key.ToUpper())
							   && ura.User_Role.User.Id != existingOwnerId
						 select new OwnerList
							 {
								 Id = ura.User_Role.User.Id,
								 Name = ura.User_Role.User.First_Name + " " + ura.User_Role.User.Last_Name
							 }).Distinct().OrderBy(x => x.Name).ToList();
			
			var listObj = new OwnerList
				{
					Id = 0,
					Name = "--Select--",
				};
			oList.Add(listObj);
			var finalList = oList;
			return finalList;
		}

		public bool UpdateOwnerList(List<ProjectOwnerDetails> projectOwnerDetails)
		{
			ProjectOwnerDetails objOwner = new ProjectOwnerDetails();
			try
			{
				var NewOwnerId = "";
				var lstAudit = new List<Audit>();
				var uniqueTransactionId = System.Guid.NewGuid();
				if (projectOwnerDetails != null)
				{
					foreach (var VProjectOwner in projectOwnerDetails)
					{
						NewOwnerId = VProjectOwner.SelectedUser;
						var getDbUserRole = Context.Project.FirstOrDefault(c => c.Id == VProjectOwner.Id);
						var oldOwnerId = Convert.ToInt32(getDbUserRole.Owner_ID);
						if (getDbUserRole.Owner_ID != Convert.ToInt32(VProjectOwner.SelectedUser))
						{
							if (getDbUserRole != null && VProjectOwner.Id != 0)
							{

								getDbUserRole.Id = getDbUserRole.Id;
								getDbUserRole.Owner_ID = Convert.ToInt32(VProjectOwner.SelectedUser);
								getDbUserRole.Modified_By = GetLoggedUserInfo();
								getDbUserRole.Modified_Date = DateTime.UtcNow;
								Context.Entry<Project>(getDbUserRole).State = EntityState.Modified;
								Context.SaveChanges();
								Context.Entry<Project>(getDbUserRole).Reload();
								List<AuditLog> auditlog = new List<AuditLog>();
								var auditlogs = new AuditLog
								{
									ColumnName = string.Format("{0}", "Owner_ID"),
									OldValue = oldOwnerId.ToString(),
									NewValue = NewOwnerId,
								};
								auditlog.Add(auditlogs);

								IEnumerable<AuditLog> myEnumerable = auditlog;

								var auditFunding = PopulateAuditDetails(AppConstants.AuditTableName.Project,
															VProjectOwner.Id, VProjectOwner.Id, uniqueTransactionId,
																   myEnumerable, null);
								lstAudit.Add(auditFunding);
							}

						}
					}

					InsertUpdateAuditDetails(lstAudit);
					return true;
				}
			}
			catch (Exception ex)
			{
				return false;
			}
			return true;
		}

		#endregion

		#region Roles and Actions"

		public object GetRoleActionData(int RoleId)
		{
			var Roleactions = (from rol in Context.Role_Action.ToList()
							   where (rol.Role_Id == RoleId)
							   select new
							   {
								   rol.Action_Id,
							   }).ToList();

			return Roleactions;
		}

		public bool UpdateRoleActionList(List<Roles> role)
		{
			int[] rolearr = new int[role.Count];
			int[] actionarr = new int[role.Count];
			for (int i = 0; i < role.Count; i++)
			{
				if (role[i].Role_Id != 0)
				{
					rolearr[i] = role[i].Role_Id;
				}

				if (role[i].Action_Id != 0)
				{
					actionarr[i] = role[i].Action_Id;
				}
			}

			var rolelist = new List<int>((int[])rolearr);
			var actionlist = new List<int>((int[])actionarr);
			rolelist.RemoveAll(x => x == 0);
			actionlist.RemoveAll(x => x == 0);

			foreach (int rol in rolelist)
			{
				var dbItemrole1 = Context.Role_Action.Where(x => x.Role_Id == rol);
				foreach (var item in dbItemrole1)
				{
					Context.Role_Action.Remove(item);
				}
				Context.SaveChanges();

				foreach (int action in actionlist)
				{
					var dbItemrole = Context.Role_Action.FirstOrDefault(x => x.Role_Id == rol && x.Action_Id == action);
					if (dbItemrole == null)
					{
						Role_Action actionobj = new Role_Action
						{
							Role_Id = rol,
							Action_Id = action,
							Modified_By = GetLoggedUserInfo(),
							Modified_Date = DateTime.UtcNow,
							Created_By = GetLoggedUserInfo(),
							Created_Date = DateTime.UtcNow,
						};
						Context.Entry<Role_Action>(actionobj).State = EntityState.Added;
						Context.SaveChanges();
						Context.Entry<Role_Action>(actionobj).Reload();
					}
				}
			}
			return true;
		}

		public object GetRoleListData()
		{
			var rolesList = (from rol in Context.Roles.AsNoTracking()
							 select new Roles
							 {
								 Role_Id = rol.Id,
								 Role_Key = rol.Role_Key,
								 Role_Name = rol.Name,
							 }
				);
			return rolesList;
		}

		public object GetActionListData()
		{
			var actionList = (from act in Context.Actions.AsNoTracking()
							  join cvtyp in Context.Code_Value.AsNoTracking()
									 on act.Type_Id equals cvtyp.Code_ID
									 into cvtyps
							  from cvType in
								  cvtyps.Where(x => x.Code_Value_Key == act.Type_Key)
										.DefaultIfEmpty()

							  select new Actions
							  {
								  Action_Id = act.Id,
								  Action_Name = act.Action_Name,
								  Action_Description = act.Action_Description,
								  Controller_Name = act.Controller_Name,
								  Type_Description = cvType.Code_Value_Description == null ? "" : cvType.Code_Value_Description,

							  }
			   );
			return actionList;
		}

		#endregion
	}
}
