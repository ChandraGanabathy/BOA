﻿using STEP.Models;

namespace STEP.Repository
{
    public class ProjectDocumentRepository : EntityBaseRepository<Project_Document>, IProjectDocumentRepository
    {
        public ProjectDocumentRepository(STEPContext context)
            : base(context)
        {

        }
    }
}
