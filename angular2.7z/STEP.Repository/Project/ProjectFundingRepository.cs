﻿using STEP.Models;

namespace STEP.Repository
{

    public class ProjectFundingRepository : EntityBaseRepository<Project_Funding>, IProjectFundingRepository
    {
        public ProjectFundingRepository(STEPContext context)
            : base(context)
        {

        }
    }

    public class ApprovalProcessRepository : EntityBaseRepository<Approval_Process>, IApprovalProcessRepository
    {
        public ApprovalProcessRepository(STEPContext context)
            : base(context)
        {

        }
    }

    public class ApprovalProcessEmailConfigRepository : EntityBaseRepository<Approval_Process_Email_Config>, IApprovalProcessEmailConfigRepository
    {
        public ApprovalProcessEmailConfigRepository(STEPContext context)
            : base(context)
        {

        }
    }

    public class AuditRepository : EntityBaseRepository<Audit>, IAuditRepository
    {
        public AuditRepository(STEPContext context)
            : base(context)
        {

        }
    }

    public class AuditDetailsRepository : EntityBaseRepository<Audit_Details>, IAuditDetailsRepository
    {
        public AuditDetailsRepository(STEPContext context)
            : base(context)
        {

        }
    }

    public class AuditDisplayRepository : EntityBaseRepository<Audit_Display>, IAuditDisplayRepository  
    {
        public AuditDisplayRepository(STEPContext context)
            : base(context)
        {

        }
    }
}
