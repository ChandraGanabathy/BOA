﻿using STEP.Models;

namespace STEP.Repository
{
    public class ProjectAnswerRepository : EntityBaseRepository<Project_Answer>, IProjectAnswerRepository
    {
        public ProjectAnswerRepository(STEPContext context)
            : base(context)
        {

        }
    }
}
