﻿using STEP.Models;

namespace STEP.Repository
{
    public class ProjectNoteRepository : EntityBaseRepository<Project_Note>, IProjectNoteRepository
    {
        public ProjectNoteRepository(STEPContext context)
            : base(context)
        {

        }
    }
}
