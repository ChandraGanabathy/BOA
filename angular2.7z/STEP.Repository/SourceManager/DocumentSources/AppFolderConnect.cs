﻿using System;
using System.Web;
using STEP.Common;
using STEP.Models;
using System.IO;
namespace STEP.Interfaces
{
    public class AppFolderConnect : IDocumentSourceMethod, IDisposable
    {
        public string UploadDocument(Document document)
        {
            string result;
            try
            {
                string filePath = HttpContext.Current.Server.MapPath(document.FilePath + document.Name);
                if (
                    !Directory.Exists(
                        HttpContext.Current.Server.MapPath(document.FilePath.Substring(0, document.FilePath.Length - 1))))
                {
                    Directory.CreateDirectory(
                        HttpContext.Current.Server.MapPath(document.FilePath.Substring(0, document.FilePath.Length - 1)));
                }
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
                File.WriteAllBytes(filePath, Convert.FromBase64String(document.FileContent));
                result = string.Format("{0} Uploaded successfully", document.Name);
            }
            catch (FileNotFoundException)
            {
                result = "File not found";
            }
            catch (IOException)
            {
                result = "Access is denied";
            }
            catch (Exception ex)
            {
                result = "";
            }
            return result;
        }

        public string OverWriteFile(Document document)
        {
            string result;
            try
            {
                string fileToStore = AppConfig.ProjectDocumentsUploadUrl;
                string filePath = HttpContext.Current.Server.MapPath(fileToStore + document.Name);
                if (document.OverWrite)
                {
                    if (File.Exists(filePath))
                    {
                        File.Delete(filePath);
                    }
                }
                File.WriteAllBytes(filePath, Convert.FromBase64String(document.FileContent));
                result = string.Format("{0} Uploaded successfully", document.Name);
            }
            catch (FileNotFoundException)
            {
                result = "File not found";
            }
            catch (IOException)
            {
                result = "Access is denied";
            }
            catch (Exception ex)
            {
                result = "";
            }
            return result;
        }

        void IDisposable.Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}
