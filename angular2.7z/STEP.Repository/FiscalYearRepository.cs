﻿using System;
using System.Collections.Generic;
using STEP.Models;
using System.Linq;

namespace STEP.Repository
{
    public class FiscalYearRepository : EntityBaseRepository<Fiscal_Year>, IFiscalYearRepository
    {
        private readonly DateTime _currentDate;
        public readonly STEPContext Context;

        public FiscalYearRepository(STEPContext context)
            : base(context)
        {
            _currentDate = DateTime.Now.Date;
            Context = context;
        }

        public Fiscal_Year GetFiscalYearBasedOnCurrentDate()
        {

            var fiscalYear = this.GetSingle(p =>
                                            _currentDate >= p.CurrentYear_Start_Date
                                            && _currentDate <= p.CurrentYear_End_Date);
            return fiscalYear;
        }

        public List<Fiscal_Year> GetFiscalYearAgainstCurrentDateAndFiscalYearForCurrentRequired(
            List<Fiscal_Year> fiscalYears, int fiscalYear)
        {

            var entityFiscalYear = fiscalYears.Where(p =>
                                                     _currentDate >= p.Programmed_Start_Date
                                                     && _currentDate <= p.Programmed_End_Date
                                                     && p.FY == fiscalYear).ToList();
            return entityFiscalYear;
        }

        public List<Fiscal_Year> GetFiscalYearAgainstCurrentDateAndFiscalYearForPlanning(List<Fiscal_Year> fiscalYears,
                                                                                         int fiscalYear)
        {

            var entityFiscalYear = fiscalYears.Where(p =>
                                                     _currentDate >= p.Planning_Start_Date
                                                     && _currentDate <= p.Planning_End_Date
                                                     && p.FY == fiscalYear).ToList();
            ;
            return entityFiscalYear;
        }

        public List<Fiscal_Year> GetFiscalYearAgainstCurrentDateAndFiscalYearForFunding(List<Fiscal_Year> fiscalYears,
                                                                                        int fiscalYear)
        {

            var entityFiscalYear = fiscalYears.Where(p =>
                                                     _currentDate >= p.Funding_Start_Date
                                                     && _currentDate <= p.Funding_End_Date
                                                     && p.FY == fiscalYear).ToList();
            return entityFiscalYear;
        }

        public List<Fiscal_Year> GetFiscalYearAgainstCurrentDateAndFiscalYearForObligated(List<Fiscal_Year> fiscalYears,
                                                                                          int fiscalYear)
        {

            var entityFiscalYear = fiscalYears.Where(p =>
                                                     _currentDate >= p.Obligation_Start_Date
                                                     && _currentDate <= p.Obligation_End_Date
                                                     && p.FY == fiscalYear).ToList();
            ;
            return entityFiscalYear;
        }

        public List<Project_Funding> ProjectFundingManipulation(List<Project_Funding> lstProjectFunding,
                                                                List<Fiscal_Year> fiscalYears)
        {
            for (var i = 0; i < lstProjectFunding.Count(); i++)
            {
                var fy = lstProjectFunding[i].FY;
                if (fy != null)
                {
                    lstProjectFunding[i].IsCurrentRequiredEditable =
                        this.GetFiscalYearAgainstCurrentDateAndFiscalYearForCurrentRequired(
                            fiscalYears, fy.Value).Any();

                    lstProjectFunding[i].IsPlannedEditable =
                        this.GetFiscalYearAgainstCurrentDateAndFiscalYearForPlanning(
                            fiscalYears, fy.Value).Any();

                    lstProjectFunding[i].IsFundedEditable =
                        this.GetFiscalYearAgainstCurrentDateAndFiscalYearForFunding(
                            fiscalYears, fy.Value).Any();

                    lstProjectFunding[i].IsObligatedEditable =
                        this.GetFiscalYearAgainstCurrentDateAndFiscalYearForObligated(
                            fiscalYears, fy.Value).Any();
                }
            }
            return lstProjectFunding;
        }

        #region Fiscal

        public List<object> GetAllFiscal()
        {
            var fiscalYeardata = (from ut in Context.Fiscal_Year
                                  select new
                                      {
                                          ut.Id,
                                          ut.FY,
                                          ut.FY_Start_Date,
                                          ut.FY_End_Date,
                                          ut.CurrentYear_Start_Date,
                                          ut.CurrentYear_End_Date,
                                          ut.Programmed_Start_Date,
                                          ut.Programmed_End_Date,
                                          ut.Funding_Start_Date,
                                          ut.Funding_End_Date,
                                          ut.Planning_Start_Date,
                                          ut.Planning_End_Date,
                                          ut.Obligation_Start_Date,
                                          ut.Obligation_End_Date,
                                      }).AsQueryable();
            return fiscalYeardata.ToList<object>();
        }

        public Fiscal_Year GetFiscal(int FiscalId)
        {
            var dbFiscal = GetSingle(x => x.Id == FiscalId);
            return dbFiscal;
        }

        public object GetFiscalDataAtPageLoading(int FiscalId)
        {
            var fiscalDataAtPageLoading = new[]
                {
                    new
                        {
                            GetFiscal = GetFiscal(FiscalId),
                        }
                };
            return fiscalDataAtPageLoading;
        }

        public Fiscal_Year CreateFiscalValue(Fiscal_Year fiscalValue)
        {
            var opStatus = new OperationStatus {Status = true};
            var dbFiscal = GetSingle(x => x.FY == fiscalValue.FY);
            if (fiscalValue != null && fiscalValue.Id != 0)
            {
                var fisYear = GetSingle(x => x.Id == fiscalValue.Id);

                fisYear.FY = fiscalValue.FY;
                fisYear.FY_Start_Date = fiscalValue.FY_Start_Date;
                fisYear.FY_End_Date = fiscalValue.FY_End_Date;
                fisYear.CurrentYear_Start_Date = fiscalValue.CurrentYear_Start_Date;
                fisYear.CurrentYear_End_Date = fiscalValue.CurrentYear_End_Date;
                fisYear.Programmed_Start_Date = fiscalValue.Programmed_Start_Date;
                fisYear.Programmed_End_Date = fiscalValue.Programmed_End_Date;
                fisYear.Funding_Start_Date = fiscalValue.Funding_Start_Date;
                fisYear.Funding_End_Date = fiscalValue.Funding_End_Date;
                fisYear.Planning_Start_Date = fiscalValue.Planning_Start_Date;
                fisYear.Planning_End_Date = fiscalValue.Planning_End_Date;
                fisYear.Obligation_Start_Date = fiscalValue.Obligation_Start_Date;
                fisYear.Obligation_End_Date = fiscalValue.Obligation_End_Date;
                fisYear.Modified_By = GetLoggedUserInfo();
                fisYear.Modified_Date = DateTime.Now;
                // Context.Entry<Fiscal_Year>(fisYear).State = EntityState.Modified;
                Context.SaveChanges();
                Context.Entry<Fiscal_Year>(fisYear).Reload();
                return fisYear;
            }
            if (dbFiscal != null && fiscalValue.Id == 0)
            {
                fiscalValue.Message = "Duplicate";
            }
            else
            {
                // Insert
                if (fiscalValue != null && fiscalValue.Id == 0)
                {
                    fiscalValue.Created_By = GetLoggedUserInfo();
                    fiscalValue.Created_Date = DateTime.UtcNow;
                    fiscalValue.Modified_By = GetLoggedUserInfo();
                    fiscalValue.Modified_Date = DateTime.UtcNow;
                    this.Add(fiscalValue);
                    this.Commit();
                }
            }
            return fiscalValue;
        }
        #endregion Fiscal
    }
}
