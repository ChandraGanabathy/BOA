using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Approval_Process_Email_ConfigMap : EntityTypeConfiguration<Approval_Process_Email_Config>
    {
        public Approval_Process_Email_ConfigMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Hierarchy_Parent_Selection_Key)
                .HasMaxLength(4);

            // Table & Column Mappings
            this.ToTable("Approval_Process_Email_Config");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Approval_Process_Id).HasColumnName("Approval_Process_Id");
            this.Property(t => t.To_Project_Owner).HasColumnName("To_Project_Owner");
            this.Property(t => t.Roled_Id_To_Send).HasColumnName("Roled_Id_To_Send");
            this.Property(t => t.Is_Enabled).HasColumnName("Is_Enabled");
            this.Property(t => t.Subject).HasColumnName("Subject");
            this.Property(t => t.Message).HasColumnName("Message");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");
            this.Property(t => t.Hierarchy_Parent_Selection_Id).HasColumnName("Hierarchy_Parent_Selection_Id");
            this.Property(t => t.Hierarchy_Parent_Selection_Key).HasColumnName("Hierarchy_Parent_Selection_Key");

            // Relationships
            this.HasOptional(t => t.Role)
                .WithMany(t => t.Approval_Process_Email_Config)
                .HasForeignKey(d => d.Roled_Id_To_Send);

        }
    }
}
