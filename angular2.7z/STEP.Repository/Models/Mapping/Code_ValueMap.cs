using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Code_ValueMap : EntityTypeConfiguration<Code_Value>
    {
        public Code_ValueMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Code_Value_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Code_Value_Description)
                .HasMaxLength(250);

            this.Property(t => t.Data1)
                .HasMaxLength(250);

            this.Property(t => t.Data2)
                .HasMaxLength(250);

            this.Property(t => t.Data3)
                .HasMaxLength(250);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Code_Value");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Code_ID).HasColumnName("Code_ID");
            this.Property(t => t.Code_Value_Key).HasColumnName("Code_Value_Key");
            this.Property(t => t.Code_Value_Description).HasColumnName("Code_Value_Description");
            this.Property(t => t.Data1).HasColumnName("Data1");
            this.Property(t => t.Data2).HasColumnName("Data2");
            this.Property(t => t.Data3).HasColumnName("Data3");
            this.Property(t => t.SequenceNumber).HasColumnName("SequenceNumber");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Code)
                .WithMany(t => t.Code_Value)
                .HasForeignKey(d => d.Code_ID);

        }
    }
}
