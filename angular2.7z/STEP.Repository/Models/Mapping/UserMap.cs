using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class UserMap : EntityTypeConfiguration<User>
    {
        public UserMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Email_Id)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Title)
                .HasMaxLength(50);

            this.Property(t => t.First_Name)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Middle_Name)
                .HasMaxLength(50);

            this.Property(t => t.Last_Name)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Password)
                .IsRequired()
                .HasMaxLength(250);

            this.Property(t => t.Address_Line1)
                .HasMaxLength(50);

            this.Property(t => t.Address_Line2)
                .HasMaxLength(50);

            this.Property(t => t.City)
                .HasMaxLength(50);

            this.Property(t => t.State_Key)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.Zip)
                .HasMaxLength(10);

            this.Property(t => t.Phone)
                .HasMaxLength(50);

            this.Property(t => t.Organization)
                .HasMaxLength(50);

            this.Property(t => t.User_Status_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Users");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Email_Id).HasColumnName("Email_Id");
            this.Property(t => t.Title).HasColumnName("Title");
            this.Property(t => t.First_Name).HasColumnName("First_Name");
            this.Property(t => t.Middle_Name).HasColumnName("Middle_Name");
            this.Property(t => t.Last_Name).HasColumnName("Last_Name");
            this.Property(t => t.Password).HasColumnName("Password");
            this.Property(t => t.Address_Line1).HasColumnName("Address_Line1");
            this.Property(t => t.Address_Line2).HasColumnName("Address_Line2");
            this.Property(t => t.City).HasColumnName("City");
            this.Property(t => t.State_Id).HasColumnName("State_Id");
            this.Property(t => t.State_Key).HasColumnName("State_Key");
            this.Property(t => t.Zip).HasColumnName("Zip");
            this.Property(t => t.Phone).HasColumnName("Phone");
            this.Property(t => t.Organization).HasColumnName("Organization");
            this.Property(t => t.User_Status_Id).HasColumnName("User_Status_Id");
            this.Property(t => t.User_Status_Key).HasColumnName("User_Status_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");
        }
    }
}
