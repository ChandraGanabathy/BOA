using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Approval_ProcessMap : EntityTypeConfiguration<Approval_Process>
    {
        public Approval_ProcessMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Project_Type_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Action_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.NewStatus_Approval_Status_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.CurrentStatus_Approval_Status_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Notes)
                .HasMaxLength(250);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Approval_Process");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Project_Type_Id).HasColumnName("Project_Type_Id");
            this.Property(t => t.Project_Type_Key).HasColumnName("Project_Type_Key");
            this.Property(t => t.Role_Id).HasColumnName("Role_Id");
            this.Property(t => t.Action_Id).HasColumnName("Action_Id");
            this.Property(t => t.Action_Key).HasColumnName("Action_Key");
            this.Property(t => t.NewStatus_Approval_Status_Id).HasColumnName("NewStatus_Approval_Status_Id");
            this.Property(t => t.NewStatus_Approval_Status_Key).HasColumnName("NewStatus_Approval_Status_Key");
            this.Property(t => t.CurrentStatus_Approval_Status_Id).HasColumnName("CurrentStatus_Approval_Status_Id");
            this.Property(t => t.CurrentStatus_Approval_Status_Key).HasColumnName("CurrentStatus_Approval_Status_Key");
            this.Property(t => t.Notes).HasColumnName("Notes");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Role)
                .WithMany(t => t.Approval_Process)
                .HasForeignKey(d => d.Role_Id);

        }
    }
}
