using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class AuditMap : EntityTypeConfiguration<Audit>
    {
        public AuditMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Table_Name)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Change_Type_Value)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Audit");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Table_Name).HasColumnName("Table_Name");
            this.Property(t => t.Primary_Key).HasColumnName("Primary_Key");
            this.Property(t => t.Project_Id).HasColumnName("Project_Id");
            this.Property(t => t.User_Role_Id).HasColumnName("User_Role_Id");
            this.Property(t => t.Change_Type_Id).HasColumnName("Change_Type_Id");
            this.Property(t => t.Change_Type_Value).HasColumnName("Change_Type_Value");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");
            this.Property(t => t.Transaction_Unique_Id).HasColumnName("Transaction_Unique_Id");

            // Relationships
             
            this.HasRequired(t => t.User_Role)
                .WithMany(t => t.Audits)
                .HasForeignKey(d => d.User_Role_Id);
            this.HasRequired(t => t.Project)
                .WithMany(t => t.Audits)
                .HasForeignKey(d => d.Project_Id);

        }
    }
}
