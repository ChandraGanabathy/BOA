using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class User_Role_Pillar_AssociationMap : EntityTypeConfiguration<User_Role_Pillar_Association>
    {
        public User_Role_Pillar_AssociationMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Pillar_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.LawReg_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.ProgramArea_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("User_Role_Pillar_Association");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.User_Role_Id).HasColumnName("User_Role_Id");
            this.Property(t => t.Pillar_Id).HasColumnName("Pillar_Id");
            this.Property(t => t.Pillar_Key).HasColumnName("Pillar_Key");
            this.Property(t => t.LawReg_Id).HasColumnName("LawReg_Id");
            this.Property(t => t.LawReg_Key).HasColumnName("LawReg_Key");
            this.Property(t => t.ProgramArea_Id).HasColumnName("ProgramArea_Id");
            this.Property(t => t.ProgramArea_Key).HasColumnName("ProgramArea_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.User_Role)
                .WithMany(t => t.User_Role_Pillar_Association)
                .HasForeignKey(d => d.User_Role_Id);
        }
    }
}
