using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class User_PreferenceMap : EntityTypeConfiguration<User_Preference>
    {
        public User_PreferenceMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Theme_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Page_Size_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("User_Preference");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.User_Id).HasColumnName("User_Id");
            this.Property(t => t.Theme_Id).HasColumnName("Theme_Id");
            this.Property(t => t.Theme_Key).HasColumnName("Theme_Key");
            this.Property(t => t.Page_Size_Id).HasColumnName("Page_Size_Id");
            this.Property(t => t.Page_Size_Key).HasColumnName("Page_Size_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.User)
                .WithMany(t => t.User_Preference)
                .HasForeignKey(d => d.User_Id);

        }
    }
}
