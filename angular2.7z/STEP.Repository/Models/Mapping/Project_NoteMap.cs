using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Project_NoteMap : EntityTypeConfiguration<Project_Note>
    {
        public Project_NoteMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Type_Key)
                .HasMaxLength(4);

            this.Property(t => t.Notes)
                .HasMaxLength(2000);

            this.Property(t => t.Approval_Status_Key)
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Project_Note");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Project_Id).HasColumnName("Project_Id");
            this.Property(t => t.Type_Id).HasColumnName("Type_Id");
            this.Property(t => t.Type_Key).HasColumnName("Type_Key");
            this.Property(t => t.User_Role_Id).HasColumnName("User_Role_Id");
            this.Property(t => t.Notes).HasColumnName("Notes");
            this.Property(t => t.SubSystem_Ref_Id).HasColumnName("SubSystem_Ref_Id");
            this.Property(t => t.Approval_Status_Id).HasColumnName("Approval_Status_Id");
            this.Property(t => t.Approval_Status_Key).HasColumnName("Approval_Status_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Project)
                .WithMany(t => t.Project_Note)
                .HasForeignKey(d => d.Project_Id);
            this.HasOptional(t => t.User_Role)
                .WithMany(t => t.Project_Note)
                .HasForeignKey(d => d.User_Role_Id);

        }
    }
}
