using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class AMSCOMap : EntityTypeConfiguration<AMSCO>
    {
        public AMSCOMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.AMSCO_Description)
                .IsRequired()
                .HasMaxLength(250);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("AMSCO");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.AMSCO_Code).HasColumnName("AMSCO_Code");
            this.Property(t => t.AMSCO_Description).HasColumnName("AMSCO_Description");
            this.Property(t => t.Start_FY).HasColumnName("Start_FY");
            this.Property(t => t.End_FY).HasColumnName("End_FY");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");
        }
    }
}
