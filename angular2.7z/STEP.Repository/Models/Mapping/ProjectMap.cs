using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class ProjectMap : EntityTypeConfiguration<Project>
    {
        public ProjectMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Project_Name)
                .HasMaxLength(200);

            this.Property(t => t.Project_Number)
                .HasMaxLength(50);

            this.Property(t => t.Class_Key)
                .HasMaxLength(4);

            this.Property(t => t.Project_Description)
                .HasMaxLength(2000);

            this.Property(t => t.ROI)
                .HasMaxLength(50);

            this.Property(t => t.Created_By)
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .HasMaxLength(100);

            this.Property(t => t.Impact_to_Mission_Key)
                .HasMaxLength(4);

            this.Property(t => t.Environmental_Impact_Code_Key)
                .HasMaxLength(4);

            // Table & Column Mappings
            this.ToTable("Project");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Project_Name).HasColumnName("Project_Name");
            this.Property(t => t.Project_Number).HasColumnName("Project_Number");
            this.Property(t => t.Hierarchy_Data_Id).HasColumnName("Hierarchy_Data_Id");
            this.Property(t => t.Catalog_Id).HasColumnName("Catalog_Id");
            this.Property(t => t.Class_Id).HasColumnName("Class_Id");
            this.Property(t => t.Class_Key).HasColumnName("Class_Key");
            this.Property(t => t.Owner_ID).HasColumnName("Owner_ID");
            this.Property(t => t.Created_User_Role_Id).HasColumnName("Created_User_Role_Id");
            this.Property(t => t.Project_Description).HasColumnName("Project_Description");
            this.Property(t => t.ROI).HasColumnName("ROI");
            this.Property(t => t.Is_Recurring).HasColumnName("Is_Recurring");
            this.Property(t => t.Impact_to_Mission_Id).HasColumnName("Impact_to_Mission_Id");
            this.Property(t => t.Impact_to_Mission_Key).HasColumnName("Impact_to_Mission_key");
            this.Property(t => t.Environmental_Impact_Code_Id).HasColumnName("Environmental_Impact_Code_Id");
            this.Property(t => t.Environmental_Impact_Code_Key).HasColumnName("Environmental_Impact_Code_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");
            // Relationships
            this.HasOptional(t => t.Catalog)
                .WithMany(t => t.Projects)
                .HasForeignKey(d => d.Catalog_Id);
            this.HasOptional(t => t.Hierarchy_Data)
                .WithMany(t => t.Projects)
                .HasForeignKey(d => d.Hierarchy_Data_Id);
            this.HasOptional(t => t.User_Role)
                .WithMany(t => t.Projects)
                .HasForeignKey(d => d.Created_User_Role_Id);
            this.HasOptional(t => t.User)
                .WithMany(t => t.Projects)
                .HasForeignKey(d => d.Owner_ID);
        }
    }
}
