using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class User_RoleMap : EntityTypeConfiguration<User_Role>
    {
        public User_RoleMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("User_Role");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.User_Id).HasColumnName("User_Id");
            this.Property(t => t.Role_Id).HasColumnName("Role_Id");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Role)
                .WithMany(t => t.User_Role)
                .HasForeignKey(d => d.Role_Id);
            this.HasRequired(t => t.User)
                .WithMany(t => t.User_Role)
                .HasForeignKey(d => d.User_Id).WillCascadeOnDelete(true);

        }
    }
}
