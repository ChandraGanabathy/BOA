using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Audit_DetailsMap : EntityTypeConfiguration<Audit_Details>
    {
        public Audit_DetailsMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Column_Name)
                .IsRequired()
                .HasMaxLength(150);

            this.Property(t => t.Old_Value)
                .IsRequired();

            this.Property(t => t.New_Value)
                .IsRequired();

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Audit_Details");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Audit_Id).HasColumnName("Audit_Id");
            this.Property(t => t.Column_Name).HasColumnName("Column_Name");
            this.Property(t => t.Old_Value).HasColumnName("Old_Value");
            this.Property(t => t.New_Value).HasColumnName("New_Value");
            this.Property(t => t.FY).HasColumnName("FY");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Audit)
                .WithMany(t => t.Audit_Details)
                .HasForeignKey(d => d.Audit_Id);

        }
    }
}
