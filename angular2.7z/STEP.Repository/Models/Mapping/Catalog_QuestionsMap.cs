using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Catalog_QuestionsMap : EntityTypeConfiguration<Catalog_Questions>
    {
        public Catalog_QuestionsMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Question)
                .IsRequired()
                .HasMaxLength(500);

            this.Property(t => t.Answer_Type_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Catalog_Questions");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Catalog_Id).HasColumnName("Catalog_Id");
            this.Property(t => t.Question).HasColumnName("Question");
            this.Property(t => t.Answer_Type_Id).HasColumnName("Answer_Type_Id");
            this.Property(t => t.Answer_Type_Key).HasColumnName("Answer_Type_Key");
            this.Property(t => t.IsRequired).HasColumnName("IsRequired");
            this.Property(t => t.Start_FY).HasColumnName("Start_FY");
            this.Property(t => t.End_FY).HasColumnName("End_FY");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Catalog)
                .WithMany(t => t.Catalog_Questions)
                .HasForeignKey(d => d.Catalog_Id);
             

        }
    }
}
