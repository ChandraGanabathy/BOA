using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Fiscal_YearMap : EntityTypeConfiguration<Fiscal_Year>
    {
        public Fiscal_YearMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Fiscal_Year");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.FY).HasColumnName("FY");
            this.Property(t => t.FY_Start_Date).HasColumnName("FY_Start_Date");
            this.Property(t => t.FY_End_Date).HasColumnName("FY_End_Date");
            this.Property(t => t.CurrentYear_Start_Date).HasColumnName("CurrentYear_Start_Date");
            this.Property(t => t.CurrentYear_End_Date).HasColumnName("CurrentYear_End_Date");
            this.Property(t => t.Programmed_Start_Date).HasColumnName("Programmed_Start_Date");
            this.Property(t => t.Programmed_End_Date).HasColumnName("Programmed_End_Date");
            this.Property(t => t.Planning_Start_Date).HasColumnName("Planning_Start_Date");
            this.Property(t => t.Planning_End_Date).HasColumnName("Planning_End_Date");
            this.Property(t => t.Funding_Start_Date).HasColumnName("Funding_Start_Date");
            this.Property(t => t.Funding_End_Date).HasColumnName("Funding_End_Date");
            this.Property(t => t.Obligation_Start_Date).HasColumnName("Obligation_Start_Date");
            this.Property(t => t.Obligation_End_Date).HasColumnName("Obligation_End_Date");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");
        }
    }
}
