using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Role_ActionMap : EntityTypeConfiguration<Role_Action>
    {
        public Role_ActionMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Role_Action");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Role_Id).HasColumnName("Role_Id");
            this.Property(t => t.Action_Id).HasColumnName("Action_Id");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Action)
                .WithMany(t => t.Role_Action)
                .HasForeignKey(d => d.Action_Id);
            this.HasRequired(t => t.Role)
                .WithMany(t => t.Role_Action)
                .HasForeignKey(d => d.Role_Id);

        }
    }
}
