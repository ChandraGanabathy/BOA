using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Catalog_AMSCOMap : EntityTypeConfiguration<Catalog_AMSCO>
    {
        public Catalog_AMSCOMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Catalog_AMSCO");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Catalog_Id).HasColumnName("Catalog_Id");
            this.Property(t => t.AMSCO_Id).HasColumnName("AMSCO_Id");
            //this.Property(t => t.Start_FY).HasColumnName("Start_FY");
            //this.Property(t => t.End_FY).HasColumnName("End_FY");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.AMSCO)
                .WithMany(t => t.Catalog_AMSCO)
                .HasForeignKey(d => d.AMSCO_Id);
            this.HasRequired(t => t.Catalog)
                .WithMany(t => t.Catalog_AMSCO)
                .HasForeignKey(d => d.Catalog_Id);

        }
    }
}
