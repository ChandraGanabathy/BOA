using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class User_AuditMap : EntityTypeConfiguration<User_Audit>
    {
        public User_AuditMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties

            this.Property(t => t.Action_Key)
               .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("User_Audit");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.User_Role_Id).HasColumnName("User_Role_Id");
            this.Property(t => t.Date_Time).HasColumnName("Date_Time");
            this.Property(t => t.Action_Id).HasColumnName("Action_Id");
            this.Property(t => t.Action_Key).HasColumnName("Action_Key");
            this.Property(t => t.Current_User_Role_Id).HasColumnName("Current_User_Role_Id");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.User_Role)
                .WithMany(t => t.User_Audit)
                .HasForeignKey(d => d.User_Role_Id);
        }
    }
}
