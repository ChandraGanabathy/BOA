using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Project_FundingMap : EntityTypeConfiguration<Project_Funding>
    {
        public Project_FundingMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Validated)
                .HasPrecision(20, 2);

            this.Property(t => t.Programmed)
                .HasPrecision(20, 2);

            this.Property(t => t.Planned)
                .HasPrecision(20, 2);

            this.Property(t => t.Funded)
                .HasPrecision(20, 2);

            this.Property(t => t.Obligated)
                .HasPrecision(20, 2);

            this.Property(t => t.Approval_Status_Key)
                .HasMaxLength(4);

            this.Property(t => t.MDEP_Key)
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .HasMaxLength(100);

            this.Property(t => t.Funding_Status_Code_Key)
                .HasMaxLength(4);

            // Table & Column Mappings
            this.ToTable("Project_Funding");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Project_Id).HasColumnName("Project_Id");
            this.Property(t => t.FY).HasColumnName("FY");
            this.Property(t => t.Priority).HasColumnName("Priority");
            this.Property(t => t.Validated).HasColumnName("Validated");
            this.Property(t => t.Planned).HasColumnName("Planned");
            this.Property(t => t.Programmed).HasColumnName("Programmed");
            this.Property(t => t.Funded).HasColumnName("Funded");
            this.Property(t => t.Obligated).HasColumnName("Obligated");
            this.Property(t => t.Approval_Status_Id).HasColumnName("Approval_Status_Id");
            this.Property(t => t.Approval_Status_Key).HasColumnName("Approval_Status_Key");
            this.Property(t => t.Is_UFR).HasColumnName("Is_UFR");
            this.Property(t => t.MDEP_Id).HasColumnName("MDEP_Id");
            this.Property(t => t.MDEP_Key).HasColumnName("MDEP_Key");
            this.Property(t => t.MSC_Priority).HasColumnName("MSC_Priority");
            this.Property(t => t.HQ_Priority).HasColumnName("HQ_Priority");
            this.Property(t => t.Funding_Status_Code_Id).HasColumnName("Funding_Status_Code_Id");
            this.Property(t => t.Funding_Status_Code_Key).HasColumnName("Funding_Status_Code_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Project)
                .WithMany(t => t.Project_Funding)
                .HasForeignKey(d => d.Project_Id);

        }
    }
}
