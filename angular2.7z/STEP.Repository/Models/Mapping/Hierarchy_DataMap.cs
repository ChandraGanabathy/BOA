using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Hierarchy_DataMap : EntityTypeConfiguration<Hierarchy_Data>
    {
        public Hierarchy_DataMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Code)
                .HasMaxLength(25);

            this.Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Hierarchy_Level_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.State_Key)
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Hierarchy_Data");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Parent_Id).HasColumnName("Parent_Id");
            this.Property(t => t.Code).HasColumnName("Code");
            this.Property(t => t.Name).HasColumnName("Name");
            this.Property(t => t.Hierarchy_Level_Id).HasColumnName("Hierarchy_Level_Id");
            this.Property(t => t.Hierarchy_Level_Key).HasColumnName("Hierarchy_Level_Key");
            this.Property(t => t.State_Id).HasColumnName("State_Id");
            this.Property(t => t.State_Key).HasColumnName("State_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            
            this.HasOptional(t => t.Parent_Hierarchy_Data)
                .WithMany(t => t.Child_Hierarchy_Data)
                .HasForeignKey(d => d.Parent_Id);

            

        }
    }
}
