using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class ActionMap : EntityTypeConfiguration<Action>
    {
        public ActionMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Action_Name)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Action_Description)
                .HasMaxLength(200);

            this.Property(t => t.Controller_Name)
               .HasMaxLength(100);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Action");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Action_Name).HasColumnName("Action_Name");
            this.Property(t => t.Action_Description).HasColumnName("Action_Description");
            this.Property(t => t.Controller_Name).HasColumnName("Controller_Name");
            this.Property(t => t.Type_Id).HasColumnName("Type_Id");
            this.Property(t => t.Type_Key).HasColumnName("Type_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships


        }
    }
}
