using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Audit_DisplayMap : EntityTypeConfiguration<Audit_Display>
    {
        public Audit_DisplayMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Entity_Name)
                .HasMaxLength(200);

            this.Property(t => t.Display_Name)
                .HasMaxLength(200);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Audit_Display");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Entity_Name).HasColumnName("Entity_Name");
            this.Property(t => t.Display_Name).HasColumnName("Display_Name");
            this.Property(t => t.Code_Id).HasColumnName("Code_Id");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");
        }
    }
}
