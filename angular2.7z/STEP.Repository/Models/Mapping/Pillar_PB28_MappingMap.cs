using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Pillar_PB28_MappingMap : EntityTypeConfiguration<Pillar_PB28_Mapping>
    {
        public Pillar_PB28_MappingMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Pillar_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Title_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Category_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.SubCategory_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Pillar_PB28_Mapping");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Pillar_Id).HasColumnName("Pillar_Id");
            this.Property(t => t.Pillar_Key).HasColumnName("Pillar_Key");
            this.Property(t => t.Title_Id).HasColumnName("Title_Id");
            this.Property(t => t.Title_Key).HasColumnName("Title_Key");
            this.Property(t => t.Category_Id).HasColumnName("Category_Id");
            this.Property(t => t.Category_Key).HasColumnName("Category_Key");
            this.Property(t => t.SubCategory_Id).HasColumnName("SubCategory_Id");
            this.Property(t => t.SubCategory_Key).HasColumnName("SubCategory_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

        }
    }
}
