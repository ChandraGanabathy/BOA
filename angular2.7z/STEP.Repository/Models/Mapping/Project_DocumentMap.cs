using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Project_DocumentMap : EntityTypeConfiguration<Project_Document>
    {
        public Project_DocumentMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Document_Original_Name)
                .HasMaxLength(500);

            this.Property(t => t.Document_Name)
                .HasMaxLength(500);

            this.Property(t => t.Created_By)
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Project_Document");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Project_Id).HasColumnName("Project_Id");
            this.Property(t => t.Document_Original_Name).HasColumnName("Document_Original_Name");
            this.Property(t => t.Document_Name).HasColumnName("Document_Name");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Project)
                .WithMany(t => t.Project_Document)
                .HasForeignKey(d => d.Project_Id);

        }
    }
}
