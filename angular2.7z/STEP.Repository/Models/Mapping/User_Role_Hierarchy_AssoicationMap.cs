using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class User_Role_Hierarchy_AssoicationMap : EntityTypeConfiguration<User_Role_Hierarchy_Assoication>
    {
        public User_Role_Hierarchy_AssoicationMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("User_Role_Hierarchy_Assoication");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Hierarchy_Data_Id).HasColumnName("Hierarchy_Data_Id");
            this.Property(t => t.User_Role_Id).HasColumnName("User_Role_Id");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasOptional(t => t.Hierarchy_Data)
                .WithMany(t => t.User_Role_Hierarchy_Assoication)
                .HasForeignKey(d => d.Hierarchy_Data_Id);
            this.HasOptional(t => t.User_Role)
                .WithMany(t => t.User_Role_Hierarchy_Assoication)
                .HasForeignKey(d => d.User_Role_Id);

        }
    }
}
