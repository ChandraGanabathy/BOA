using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Pillar_LawReg_MappingMap : EntityTypeConfiguration<Pillar_LawReg_Mapping>
    {
        public Pillar_LawReg_MappingMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Pillar_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.LawReg_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.ProgramArea_Key)
                .IsRequired()
                .HasMaxLength(4);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Pillar_LawReg_Mapping");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Pillar_Id).HasColumnName("Pillar_Id");
            this.Property(t => t.Pillar_Key).HasColumnName("Pillar_Key");
            this.Property(t => t.LawReg_Id).HasColumnName("LawReg_Id");
            this.Property(t => t.LawReg_Key).HasColumnName("LawReg_Key");
            this.Property(t => t.ProgramArea_Id).HasColumnName("ProgramArea_Id");
            this.Property(t => t.ProgramArea_Key).HasColumnName("ProgramArea_Key");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");
        }
    }
}
