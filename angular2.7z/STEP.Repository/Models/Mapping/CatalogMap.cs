using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class CatalogMap : EntityTypeConfiguration<Catalog>
    {
        public CatalogMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Catalog_Number)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Catalog_Name)
                .IsRequired()
                .HasMaxLength(500);

            this.Property(t => t.Catalog_Narrative)
                .IsRequired();

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Catalog");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Catalog_Number).HasColumnName("Catalog_Number");
            this.Property(t => t.Catalog_Name).HasColumnName("Catalog_Name");
            this.Property(t => t.Class_Id).HasColumnName("Class_Id");
            this.Property(t => t.Class_Key).HasColumnName("Class_Key");
            this.Property(t => t.Status_Id).HasColumnName("Status_Id");
            this.Property(t => t.Status_Key).HasColumnName("Status_Key");
            this.Property(t => t.Pillar_Lawreg_Mapping_Id).HasColumnName("Pillar_Lawreg_Mapping_Id");
            this.Property(t => t.Pillar_PB28_Mapping_Id).HasColumnName("Pillar_PB28_Mapping_Id");
            this.Property(t => t.Catalog_Narrative).HasColumnName("Catalog_Narrative");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasOptional(t => t.Pillar_LawReg_Mapping)
                .WithMany(t => t.Catalogs)
                .HasForeignKey(d => d.Pillar_Lawreg_Mapping_Id);
            this.HasOptional(t => t.Pillar_PB28_Mapping)
                .WithMany(t => t.Catalogs)
                .HasForeignKey(d => d.Pillar_PB28_Mapping_Id);
            
        }
    }
}
