﻿using STEP.Models;
using System.Data.Entity.ModelConfiguration;

namespace STEP.Repository
{
    public class Hierarchy_Data_PlanningMap : EntityTypeConfiguration<Hierarchy_Data_Planning>
    {
        public Hierarchy_Data_PlanningMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);
            
            // Properties
            this.Property(t => t.Control_Amount)
             .HasPrecision(20, 2);

            this.Property(t => t.Hierarchy_Data_Id)
                .IsRequired();

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Hierarchy_Data_Planning");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Hierarchy_Data_Id).HasColumnName("Hierarchy_Data_Id");
            this.Property(t => t.Control_Amount).HasColumnName("Control_Amount");
            this.Property(t => t.Priority_Status_Id).HasColumnName("Priority_Status_Id");
            this.Property(t => t.Priority_Status_Key).HasColumnName("Priority_Status_Key");
            this.Property(t => t.Priority_Completion_Date).HasColumnName("Priority_Completion_date");
            this.Property(t => t.Allocation_Status_Id).HasColumnName("Allocation_Status_Id");
            this.Property(t => t.Allocation_Status_Key).HasColumnName("Allocation_Status_Key");
            this.Property(t => t.Allocation_Completion_Date).HasColumnName("Allocation_Completion_date");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasRequired(t => t.Hierarchy_Data)
                .WithMany(t => t.Hierarchy_Data_Planning)
                .HasForeignKey(d => d.Hierarchy_Data_Id);
             
        }
    }
}