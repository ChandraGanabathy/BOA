using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Project_AnswerMap : EntityTypeConfiguration<Project_Answer>
    {
        public Project_AnswerMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Answer)
                .HasMaxLength(500);

            this.Property(t => t.Created_By)
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Project_Answer");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Project_Id).HasColumnName("Project_Id");
            this.Property(t => t.Catalog_Question_Id).HasColumnName("Catalog_Question_Id");
            this.Property(t => t.FY).HasColumnName("FY");
            this.Property(t => t.Answer).HasColumnName("Answer");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasOptional(t => t.Catalog_Questions)
                .WithMany(t => t.Project_Answer)
                .HasForeignKey(d => d.Catalog_Question_Id);
            this.HasRequired(t => t.Project)
                .WithMany(t => t.Project_Answer)
                .HasForeignKey(d => d.Project_Id);

        }
    }
}
