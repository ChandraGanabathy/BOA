using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using STEP.Models;

namespace STEP.Repository
{
    public class Role_Invitation_MappingMap : EntityTypeConfiguration<Role_Invitation_Mapping>
    {
        public Role_Invitation_MappingMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Id)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.Created_By)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Modified_By)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Role_Invitation_Mapping");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Parent_Role_Id).HasColumnName("Parent_Role_Id");
            this.Property(t => t.Child_Role_Id).HasColumnName("Child_Role_Id");
            this.Property(t => t.Created_By).HasColumnName("Created_By");
            this.Property(t => t.Created_Date).HasColumnName("Created_Date");
            this.Property(t => t.Modified_By).HasColumnName("Modified_By");
            this.Property(t => t.Modified_Date).HasColumnName("Modified_Date");

            // Relationships
            this.HasOptional(t => t.Parent_Role)
                .WithMany(t => t.Role_Invitation_Mapping)
                .HasForeignKey(d => d.Parent_Role_Id);
            this.HasOptional(t => t.Child_Role)
                .WithMany(t => t.Role_Invitation_Mapping1)
                .HasForeignKey(d => d.Child_Role_Id);

        }
    }
}
