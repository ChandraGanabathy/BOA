﻿using STEP.Common;
using STEP.Models;
using STEP.Models.UIModel;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Reflection;

namespace STEP.Repository
{
    public class HierarchyDataPlanningRepository : EntityBaseRepository<Hierarchy_Data_Planning>, IHierarchyDataPlanningRepository
    {
        public readonly STEPContext Context;
        public HierarchyDataPlanningRepository(STEPContext context)
            : base(context)
        {
            Context = context;
        }

        #region PAFG

        public List<Hierarchy_Data_Planning> SearchPAFGs(PAFGSearchFilter controlsearchFilter)
        {
            List<int> userProprties = AppContext.CurrentUserRoleHierarchyData.Select(x => x.Id).ToList();
            Fiscal_Year selectedFY = AppContext.FiscalYears.SingleOrDefault(x => x.FY == controlsearchFilter.FiscalYear);
            //PAFGSearchResult = default(IQueryable<Hierarchy_Data_Planning>);
            var PAFGSearchResult = (from hd in Context.Hierarchy_Data.AsNoTracking()
                                    join hdp in Context.Hierarchy_Data_Planning.AsNoTracking() on new { HID = hd.Id, FY = controlsearchFilter.FiscalYear } equals new { HID = hdp.Hierarchy_Data_Id, FY = hdp.FY } into mappedSet
                                    from pr in mappedSet.DefaultIfEmpty()
                                    where ((string.IsNullOrEmpty(controlsearchFilter.Property) && userProprties.Contains(hd.Id)) || hd.Id.ToString() == controlsearchFilter.Property)
                                    let isAllocated = ((pr != null && pr.Allocation_Status_Key == AppConstants.CodeCategories.PlanningCompleted))
                                    let canAllocate = (pr != null &&
                                                        pr.Control_Amount > 0 &&
                                                        pr.Allocation_Status_Key == AppConstants.CodeCategories.NotPlanned &&
                                                        pr.Priority_Status_Key == AppConstants.CodeCategories.PrioritizationCompleted &&
                                                        selectedFY.Planning_Start_Date < DateTime.Now &&
                                                        selectedFY.Planning_End_Date > DateTime.Now)
                                    select new
                                            {
                                                Id = (pr == null ? 0 : pr.Id),
                                                Hierarchy_Data_Id = hd.Id,
                                                Hierarchy_Data_Name = hd.Name,
                                                Control_Amount = (pr == null ? 0 : pr.Control_Amount),
                                                Allocation_Status_Key = (pr == null ? AppConstants.CodeCategories.NotPlanned : (pr.Allocation_Status_Key)),
                                                Allocation_Completion_Date = (pr == null ? null : (pr.Allocation_Completion_Date)),
                                                Priority_Status_Key = (pr == null ? AppConstants.CodeCategories.NotPrioritized : (pr.Priority_Status_Key)),
                                                Priority_Completion_Date = (pr == null ? null : (pr.Priority_Completion_Date)),
                                                IsAllocated = isAllocated,
                                                CanAllocate = canAllocate,
                                                FY = controlsearchFilter.FiscalYear
                                            }).ToList().Select(x => new Hierarchy_Data_Planning
                                            {
                                                Id = x.Id,
                                                Hierarchy_Data_Id = x.Hierarchy_Data_Id,
                                                Hierarchy_Data_Name = x.Hierarchy_Data_Name,
                                                Control_Amount = x.Control_Amount,
                                                Allocation_Status_Key = x.Allocation_Status_Key,
                                                Allocation_Completion_Date = x.Allocation_Completion_Date,
                                                Priority_Status_Key = x.Priority_Status_Key,
                                                Priority_Completion_Date = x.Priority_Completion_Date,
                                                IsAllocated = x.IsAllocated,
                                                CanAllocate = x.CanAllocate,
                                                FY = x.FY
                                            }).ToList();
            return PAFGSearchResult;
        }
        public List<Hierarchy_Data_Planning> SaveControlAmount(List<Hierarchy_Data_Planning> pafgList)
        {
            if (pafgList.Count > 0)
            {
                var hidList = pafgList.Select(x => x.Hierarchy_Data_Id).ToList();
                var FY = pafgList.FirstOrDefault().FY;
                var dbhdPanningList = (from hdp in Context.Hierarchy_Data_Planning.AsNoTracking()
                                       where hidList.Contains(hdp.Hierarchy_Data_Id) && hdp.FY == FY
                                       select hdp).ToList();


                foreach (Hierarchy_Data_Planning hdp in pafgList)
                {
                    var dbhdPanning = dbhdPanningList.SingleOrDefault(x => x.Hierarchy_Data_Id == hdp.Hierarchy_Data_Id && x.FY == hdp.FY);
                    if (dbhdPanning.IsNull())
                    {
                        if (hdp.Control_Amount > 0)
                        {
                            Hierarchy_Data_Planning hdPlanning = new Hierarchy_Data_Planning
                            {
                                Hierarchy_Data_Id = hdp.Hierarchy_Data_Id,
                                Control_Amount = hdp.Control_Amount,
                                Priority_Status_Id = AppConstants.CodeCategories.PrioritizationStatus,
                                Priority_Status_Key = AppConstants.CodeCategories.NotPrioritized,
                                Priority_Completion_Date = null,
                                Allocation_Status_Id = AppConstants.CodeCategories.PAFGStatus,
                                Allocation_Status_Key = AppConstants.CodeCategories.NotPlanned,
                                Allocation_Completion_Date = null,
                                FY = hdp.FY,
                                Created_By = GetLoggedUserInfo(),
                                Created_Date = CreatedUpdatedDateTime(),
                                Modified_By = GetLoggedUserInfo(),
                                Modified_Date = CreatedUpdatedDateTime()
                            };
                            dbhdPanningList.Add(hdPlanning);
                            Context.Entry<Hierarchy_Data_Planning>(hdPlanning).State = EntityState.Added;
                        }
                    }
                    else
                    {
                        dbhdPanning.Modified_By = GetLoggedUserInfo();
                        dbhdPanning.Modified_Date = CreatedUpdatedDateTime();
                        dbhdPanning.Control_Amount = hdp.Control_Amount;
                        Context.Entry<Hierarchy_Data_Planning>(dbhdPanning).State = EntityState.Modified;
                    }
                }

                Context.SaveChanges();

                pafgList = SearchPAFGs(new PAFGSearchFilter { FiscalYear = FY, Property = (hidList.Count() == 1) ? hidList[0].ToString() : string.Empty });
            }
            return pafgList;

        }
        public List<Hierarchy_Data_Planning> AllocatePAFG(decimal controlAmount, int propertyId, int FY, string selectedProperty)
        {
            // get all the projects from funding and allocate planned amount untill it gets 0 for the given fy and hd based on priority
            //var hd = Context.Hierarchy_Data.Where(x => x.Hierarchy_Data_Id == propertyId);

            var projectIDList = Context.Project.Where(x => x.Hierarchy_Data_Id == propertyId).Select(x => x.Id).ToList();
            Context.Project_Funding.Where(x => x.FY == FY && projectIDList.Contains(x.Project_Id) && x.Approval_Status_Key == AppConstants.ApprovalStatus.FundingEligible).OrderBy(y => y.Priority).ToList()
                                    .ForEach(x =>
                                    {
                                        if (controlAmount - x.Validated >= 0)
                                        {
                                            x.Planned = x.Validated;
                                            controlAmount = controlAmount - x.Validated.Value;
                                        }
                                        else
                                        {
                                            x.Planned = 0;
                                        }

                                        x.Modified_By = GetLoggedUserInfo();
                                        x.Modified_Date = CreatedUpdatedDateTime();

                                    });

            var hdPlanning = Context.Hierarchy_Data_Planning.Single(x => x.FY == FY && x.Hierarchy_Data_Id == propertyId);
            hdPlanning.Allocation_Status_Key = AppConstants.CodeCategories.PlanningCompleted;
            hdPlanning.Allocation_Completion_Date = CreatedUpdatedDateTime();

            Context.SaveChanges();
            if (selectedProperty == "undefined")
                selectedProperty = "";
            List<Hierarchy_Data_Planning> pafgList = SearchPAFGs(new PAFGSearchFilter { FiscalYear = FY, Property = selectedProperty });
            return pafgList;
        }

        #endregion

        #region Priority
        public object GetProjectPrioritiesMasterData()
        {
            int currentFY = AppContext.CurrentFiscalYear.FY;
            var yearlist = AppContext.FiscalYears.Select(x => new { Year = x.FY }).ToList();
            var propertyList = AppContext.CurrentUserRoleHierarchyData.Select(x => new { Property_Text = x.Name, Property_Value = x.Id }).ToList();
            var projectList = SearchProjectPriorities(new PrioritizationSearchFilter() { Property = null, FiscalYear = currentFY, PillarKey = string.Empty, Approval_Status = AppConstants.ApprovalStatus.FundingEligible });
            var codeValue = Context.Code_Value.AsNoTracking().Select(x =>
                                                         new
                                                         {
                                                             ID = x.Code_ID,
                                                             Key = x.Code_Value_Key,
                                                             Description = x.Code_Value_Description
                                                         }).ToList();

            var ProjectPriorityLoadList = new
            {
                FYList = yearlist,
                PropertyList = propertyList,
                PriorityList = projectList,
                CurrentFY = currentFY,
                ApprovalStatus = AppConstants.ApprovalStatus.FundingEligible,
                //PillarList = codeValue.Where(x => x.ID == AppConstants.CodeCategories.Pillar && !x.Description.ToUpper().Equals(AppConstants.CodeCategories.ALL)),
                //LawRegList = codeValue.Where(x => x.ID == AppConstants.CodeCategories.LawReg && !x.Description.ToUpper().Equals(AppConstants.CodeCategories.ALL)),
                //ProgramAreaList = codeValue.Where(x => x.ID == AppConstants.CodeCategories.ProgramArea && !x.Description.ToUpper().Equals(AppConstants.CodeCategories.ALL)),
                PillarList = AppContext.CurrentUserRolePillars,
                LawRegList = AppContext.CurrentUserRoleLawRegs,
                ProgramAreaList = AppContext.CurrentUserRoleProgramAreas, 
                ApprovalStatusList = codeValue.Where(x => x.ID == AppConstants.CodeCategories.ApprovalStatuss)
            };
            return ProjectPriorityLoadList;

        }
        public object SearchProjectPriorities(PrioritizationSearchFilter searchFilter)
        {
            bool isPriorityEnabled = false;
            decimal control_Amount = decimal.Zero;
            bool isPlanned = false;
            var propertyList = AppContext.CurrentUserRoleHierarchyData.Select(x => new { Property_Text = x.Name, Property_Value = x.Id }).AsQueryable();

            var projectPrioritySearchResult = (from pf in Context.Project_Funding
                                               join p in Context.Project on pf.Project_Id equals p.Id
                                               join c in Context.Catalogs on p.Catalog_Id equals c.Id
                                               join plm in Context.Pillar_LawReg_Mapping on c.Pillar_Lawreg_Mapping_Id equals plm.Id
                                               join cv in Context.Code_Value on new { ID = plm.Pillar_Id, Key = plm.Pillar_Key } equals new { ID = cv.Code_ID, Key = cv.Code_Value_Key }
                                               where (
                                                        (pf.FY.Value == searchFilter.FiscalYear) &&
                                                        ((searchFilter.Property.HasValue == false) || (p.Hierarchy_Data_Id == searchFilter.Property)) &&
                                                        ((string.IsNullOrEmpty(searchFilter.PillarKey) || searchFilter.PillarKey == AppConstants.CodeCategories.ALL || plm.Pillar_Key == searchFilter.PillarKey)) &&
                                                         ((string.IsNullOrEmpty(searchFilter.LawReg) || searchFilter.LawReg == AppConstants.CodeCategories.ALL || plm.LawReg_Key == searchFilter.LawReg)) &&
                                                          ((string.IsNullOrEmpty(searchFilter.ProgramArea) || searchFilter.ProgramArea == AppConstants.CodeCategories.ALL || plm.ProgramArea_Key == searchFilter.ProgramArea)) &&
                                                         (string.IsNullOrEmpty(searchFilter.Approval_Status) || (pf.Approval_Status_Key == searchFilter.Approval_Status))
                                                       )
                                               select (new
                                                       {
                                                           p.Hierarchy_Data_Id,
                                                           Project_Number = p.Project_Number,
                                                           Project_Name = p.Project_Name,
                                                           Priority = pf.Priority,
                                                           HQ_Priority = pf.HQ_Priority,
                                                           MSC_Priority = pf.MSC_Priority,
                                                           pf.Validated,
                                                           pf.Programmed,
                                                           Pillar = cv.Code_Value_Description,
                                                           FY = searchFilter.FiscalYear,
                                                           Project_Id = p.Id,
                                                           Project_Funding_Id = pf.Id
                                                       })).AsEnumerable();

            var projectPriorityiesOfProperties = (from p in projectPrioritySearchResult
                                                join x in propertyList on p.Hierarchy_Data_Id equals x.Property_Value
                                                select p).ToList();
            var searchResult = new
            {
                HDPResult = new { IsPriorityEnabled = isPriorityEnabled, Control_Amount = control_Amount, IsPlanned = isPlanned, NoPAFG = true },
                ProjectPrioritiySearchResult = projectPriorityiesOfProperties
            };

            return searchResult;
        }
        public void SaveProjectPriorities(List<Project_Funding> projectPriorities, string priorityStatus)
        {
            var hid = projectPriorities[0].Project.Hierarchy_Data_Id;
            var FY = projectPriorities[0].FY;
            var hdp = Context.Hierarchy_Data_Planning.Where(x => x.Hierarchy_Data_Id == hid && x.FY == FY).SingleOrDefault();
            if (priorityStatus == AppConstants.CodeCategories.PrioritizationCompleted)
            {
                if (!hdp.IsNull())
                {
                    hdp.Priority_Status_Id = AppConstants.CodeCategories.PrioritizationStatus;
                    hdp.Priority_Status_Key = priorityStatus;
                    hdp.Priority_Completion_Date = CreatedUpdatedDateTime();
                }
                else if (hdp.IsNull())
                {

                    Hierarchy_Data_Planning hdPlanning = new Hierarchy_Data_Planning
                    {
                        Hierarchy_Data_Id = hid.IsNull() ? 0 : hid.Value,
                        Control_Amount = 0,
                        Priority_Status_Id = AppConstants.CodeCategories.PrioritizationStatus,
                        Priority_Status_Key = AppConstants.CodeCategories.PrioritizationCompleted,
                        Priority_Completion_Date = CreatedUpdatedDateTime(),
                        Allocation_Status_Id = AppConstants.CodeCategories.PAFGStatus,
                        Allocation_Status_Key = AppConstants.CodeCategories.NotPlanned,
                        Allocation_Completion_Date = null,
                        FY = FY.Value,
                        Created_By = GetLoggedUserInfo(),
                        Created_Date = CreatedUpdatedDateTime(),
                        Modified_By = GetLoggedUserInfo(),
                        Modified_Date = CreatedUpdatedDateTime()
                    };
                    Context.Hierarchy_Data_Planning.Add(hdPlanning);
                    Context.Entry<Hierarchy_Data_Planning>(hdPlanning).State = EntityState.Added;

                }
            }
            List<string> propertyExclude = new List<string>();
            foreach (PropertyInfo property in typeof(Project_Funding).GetProperties())
            {
                string[] compareList =  {"Priority","HQ_Priority","MSC_Priority"};
                if(!compareList.Contains(property.Name))
                {
                    propertyExclude.Add(property.Name);
                } 
            }
            foreach (var loopPriorities in projectPriorities)
            {
                // Edit Priority
                if (loopPriorities.Id > 0)
                {
                    var existingPF = Context.Project_Funding
                      .Find((loopPriorities.Id));

                    if (existingPF != null)
                    {
                        // Project Audit Details Population
                        var auditFunding = ProjectFundingAuditDetails(loopPriorities, existingPF, propertyExclude);
                        if (auditFunding != null)
                        {
                            Context.Set<Audit>().Add(auditFunding);
                            Context.Entry(auditFunding).State = EntityState.Added;
                        }

                        existingPF.Priority = loopPriorities.Priority;
                        existingPF.HQ_Priority = loopPriorities.HQ_Priority;
                        existingPF.MSC_Priority = loopPriorities.MSC_Priority;                        
                    }
                }
                else
                {
                    loopPriorities.Created_By = GetLoggedUserInfo();
                    loopPriorities.Created_Date = CreatedUpdatedDateTime();
                    Context.Project_Funding.Add(loopPriorities);
                }
            }

            Context.SaveChanges();

        }

        #endregion

        private Audit ProjectFundingAuditDetails(Project_Funding projectFunding, Project_Funding dbProjectFunding,List<string> excludeProperties)
        {
            var uniqueTransactionId = System.Guid.NewGuid();
            Audit auditFunding = null;
            var lstAuditLogFunding = AppExtensions.CompareEntityForAudit(projectFunding, dbProjectFunding, excludeProperties);
           
            if (lstAuditLogFunding != null && lstAuditLogFunding.Any())
            {
                if (projectFunding != null)
                {
                    auditFunding = PopulateAuditDetails(AppConstants.AuditTableName.ProjectFunding,
                                                        projectFunding.Id, projectFunding.Project_Id,
                                                        uniqueTransactionId,
                                                        lstAuditLogFunding, projectFunding.FY);
                }
            }
            return auditFunding;
        }

        private Audit PopulateAuditDetails(string tableName, int primaryKey, int projectId, Guid uniqueTransactionId,
                                           IEnumerable<AuditLog> lstAuditLog, int? fiscalYear)
        {
            var audit = new Audit
            {
                Table_Name = tableName,
                Project_Id = projectId,
                Primary_Key = primaryKey,
                User_Role_Id = AppContext.CurrentUserRole.Id,
                Change_Type_Value = AppConstants.ChangeTypes.Update,
                Change_Type_Id = AppConstants.CodeCategories.ChangeType,
                Transaction_Unique_Id = uniqueTransactionId,
                Created_By = GetLoggedUserInfo(),
                Created_Date = CreatedUpdatedDateTime(),
                Modified_By = GetLoggedUserInfo(),
                Modified_Date = CreatedUpdatedDateTime()
            };

            var lstAuditDetails = lstAuditLog.Select(item => new Audit_Details
            {
                Column_Name = string.Format("{0}.{1}", tableName, item.ColumnName),
                Old_Value = item.OldValue,
                New_Value = item.NewValue,
                FY = fiscalYear,
                Created_By = GetLoggedUserInfo(),
                Created_Date = CreatedUpdatedDateTime(),
                Modified_By = GetLoggedUserInfo(),
                Modified_Date = CreatedUpdatedDateTime(),
            }).ToList();

            audit.Audit_Details = lstAuditDetails;
            return audit;
        }

        private void InsertUpdateAuditDetails(IEnumerable<Audit> audits)
        {
            foreach (var itemAudit in audits)
            {
                Context.Set<Audit>().Add(itemAudit);
                Context.Entry(itemAudit).State = EntityState.Added;
                Context.SaveChanges();
            }
        }

    }
}
