﻿using System.Collections.Generic;
using System.Linq;
using STEP.Common;
using STEP.Models;

namespace STEP.Repository
{
    public class HierarchyDataRepository : EntityBaseRepository<Hierarchy_Data>, IHierarchyDataRepository
    {
        public readonly STEPContext Context;

        public HierarchyDataRepository(STEPContext context)
            : base(context)
        {
            Context = context;

        }

        public IEnumerable<Hierarchy_Data> SetCurrentUserRoleHierarchyData(string hierarchyLevelKey, int userRoleId)
        {
            var hierarchyData = default(IEnumerable<Hierarchy_Data>);

            if (hierarchyLevelKey ==
                AppConstants.HierarchyLevel.HeadQuarters)
            {
                hierarchyData = this.GetAll();
            }
            else if (hierarchyLevelKey ==
                AppConstants.HierarchyLevel.MajorSubCommand)
            {
                var data1 = (from r in Context.Roles
                             join ur in Context.User_Role on r.Id equals ur.Role_Id
                             join urha in Context.User_Role_Hierarchy_Assoication on ur.Id equals urha.User_Role_Id
                             join hd1 in Context.Hierarchy_Data on urha.Hierarchy_Data_Id equals hd1.Id
                             where ur.Id == userRoleId
                             select hd1).AsEnumerable();

                var data2 = (from r in Context.Roles
                             join ur in Context.User_Role on r.Id equals ur.Role_Id
                             join urha in Context.User_Role_Hierarchy_Assoication on ur.Id equals urha.User_Role_Id

                             join hd1 in Context.Hierarchy_Data on urha.Hierarchy_Data_Id equals hd1.Id into hd1Sub
                             from hd1Final in hd1Sub.DefaultIfEmpty()

                             join hd2 in Context.Hierarchy_Data on hd1Final.Id equals hd2.Parent_Id into hd2Sub
                             from hd2Final in hd2Sub.DefaultIfEmpty()

                             where ur.Id == userRoleId
                             select hd2Final).AsEnumerable();

                hierarchyData = data1.Union(data2).AsEnumerable();
            }
            else if (hierarchyLevelKey ==
                AppConstants.HierarchyLevel.Installation)
            {
                hierarchyData = (from r in Context.Roles
                                 join ur in Context.User_Role on r.Id equals ur.Role_Id
                                 join urha in Context.User_Role_Hierarchy_Assoication on ur.Id equals urha.User_Role_Id
                                 join hd1 in Context.Hierarchy_Data on urha.Hierarchy_Data_Id equals hd1.Id
                                 where ur.Id == userRoleId
                                 select hd1).AsEnumerable();
            }
            return hierarchyData;
        }

      
    }

    public class HelpDocumentsRepository : EntityBaseRepository<Help_Documents>, IHelpDocumentsRepository
    {
        public HelpDocumentsRepository(STEPContext context)
            : base(context)
        {

        }
    }
}
