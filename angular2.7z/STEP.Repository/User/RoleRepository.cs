﻿using STEP.Models;

namespace STEP.Repository
{
    public class RoleRepository : EntityBaseRepository<Role>, IRoleRepository
    {
        public RoleRepository(STEPContext context)
            : base(context)
        { }
    }
}
