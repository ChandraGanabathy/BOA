﻿using System.Collections.Generic;
using STEP.Models;
using System.Linq;

namespace STEP.Repository
{
    public class UserRoleRepository : EntityBaseRepository<User_Role>, IUserRoleRepository
    {
        public UserRoleRepository(STEPContext context)
            : base(context)
        { }
    }

    public class UserHierarchyAssociationRepository : EntityBaseRepository<User_Role_Hierarchy_Assoication>, IUserHierarchyAssociationRepository
    {
        public UserHierarchyAssociationRepository(STEPContext context)
            : base(context)
        { }
    }

    public class UserRolePillarAssociationRepository : EntityBaseRepository<User_Role_Pillar_Association>, IUserRolePillarAssociationRepository
    {
        public UserRolePillarAssociationRepository(STEPContext context)
            : base(context)
        { }
    }

    public class UserPreferenceRepository : EntityBaseRepository<User_Preference>, IUserPreferenceRepository
    {
        public UserPreferenceRepository(STEPContext context)
            : base(context)
        {
        }
    }

    public class UserAuditRepository : EntityBaseRepository<User_Audit>, IUserAuditRepository
    {
        public UserAuditRepository(STEPContext context)
            : base(context)
        {
        }
    }

    public class RoleActionRepository : EntityBaseRepository<Role_Action>, IRoleActionRepository
    {
        public readonly STEPContext Context;
        public RoleActionRepository(STEPContext context)
            : base(context)
        {
            Context = context;
        }
       
        public List<Action> GetActions(int roleId)
        {
            var actions = (from a in Context.Actions.AsNoTracking()
                           join ra in Context.Role_Action.AsNoTracking() on a.Id equals ra.Action_Id
                           where ra.Role_Id == roleId 
                           select a).ToList();
            return actions;
        }

         public string GetRoleKey(int roleId)
        {
            var firstOrDefault =
                Context.Role_Action.Where(x => x.Role_Id == roleId)
                       .Select(y => y.Action)
                       .FirstOrDefault(
                           z =>
                           z.Type_Id == Common.AppConstants.CodeCategories.RoleGroups &&
                           z.Type_Key == Common.AppConstants.CodeCategories.RoleGroupKey);
            if (firstOrDefault != null)
                return
                    firstOrDefault.Action_Name;
            return null;
        }

    }


}
