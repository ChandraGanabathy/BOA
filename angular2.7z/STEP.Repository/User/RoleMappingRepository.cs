﻿using STEP.Models;

namespace STEP.Repository
{
    public class RoleMappingRepository : EntityBaseRepository<Role_Invitation_Mapping>, IRoleMappingRepository
    {
        public RoleMappingRepository(STEPContext context)
            : base(context)
        {
        }
    }
}
