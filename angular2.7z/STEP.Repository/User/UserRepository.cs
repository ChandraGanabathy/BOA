﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using STEP.Common;
using STEP.Models;
using STEP.Models.UIModel;
using System.Reflection.Emit;
using System.Reflection;

namespace STEP.Repository
{
    public class UserRepository : EntityBaseRepository<User>, IUserRepository
    {
        public readonly STEPContext Context;

        public UserRepository(STEPContext context)
            : base(context)
        {
            Context = context;
        }

        #region Variables

        private const string cSelect = "select ",
                             cInsert = "insert ",
                             cUpdate = "update ",
                             cDelete = "delete ",
                             cWarning = "Warning",
                             cError = "Error",
                             cInfo = "Information";

        private const string cErrorMsg = "Only SELECT / INSERT / UPDATE / DELETE can be used.",
                             cNoQuery = "Please provide a query to execute";

        private const string snQueryResult = "AdminQueryResult",
                             cDrop = "drop",
                             cInvalid = "Please provide a valid Query.";

        private const char cColon = ';';

        #endregion

        public void UserAuidtTracking(int? userRoleId, string actionType, int? currentUserRoleId)
        {
            var userAudit = new User_Audit
            {
                User_Role_Id = userRoleId,
                Date_Time = DateTime.Now,
                Action_Id = AppConstants.CodeCategories.UserAuditAction,
                Current_User_Role_Id = currentUserRoleId,
                Created_By = AppContext.CurrentUser.First_Name + ' ' + AppContext.CurrentUser.Last_Name,
                Created_Date = DateTime.Now,
                Modified_By = AppContext.CurrentUser.First_Name + ' ' + AppContext.CurrentUser.Last_Name,
                Modified_Date = DateTime.Now
            };
            if (actionType == AppConstants.UserAuditActions.Login)
            {
                userAudit.Action_Key = AppConstants.UserAuditActions.Login;
            }
            else if (actionType == AppConstants.UserAuditActions.ChangeRole)
            {
                userAudit.Action_Key = AppConstants.UserAuditActions.ChangeRole;
            }
            else if (actionType == AppConstants.UserAuditActions.Impersonation)
            {
                userAudit.Action_Key = AppConstants.UserAuditActions.Impersonation;
            }
            else if (actionType == AppConstants.UserAuditActions.GobacktoOriginalUser)
            {
                userAudit.Action_Key = AppConstants.UserAuditActions.GobacktoOriginalUser;
            }
            else if (actionType == AppConstants.UserAuditActions.Logout)
            {
                userAudit.Action_Key = AppConstants.UserAuditActions.Logout;
            }
            Context.User_Audit.Add(userAudit);
            Context.SaveChanges();
        }

        public User CreateUpdateUser(User user)
        {
            // Insert User Info
            if (user != null && user.Id == 0)
            {
                var password = EncryptDecrypt.CreateRandomPassword().EncryptData();
                user.Created_By = GetLoggedUserInfo();
                user.Created_Date = DateTime.UtcNow;
                user.Modified_By = GetLoggedUserInfo();
                user.Modified_Date = DateTime.UtcNow;

                user.Password = password;

                if (user.User_Role != null)
                {
                    user.User_Role.ToList().ForEach(ur =>
                    {
                        ur.Created_By = GetLoggedUserInfo();
                        ur.Created_Date = DateTime.UtcNow;
                        ur.Modified_By = GetLoggedUserInfo();
                        ur.Modified_Date = DateTime.UtcNow;

                        if (ur.User_Role_Hierarchy_Assoication != null)
                        {
                            ur.User_Role_Hierarchy_Assoication.ToList().ForEach(uha =>
                            {
                                uha.Created_By = GetLoggedUserInfo();
                                uha.Created_Date = DateTime.UtcNow;
                                uha.Modified_By = GetLoggedUserInfo();
                                uha.Modified_Date = DateTime.UtcNow;

                            });
                        }
                        if (ur.User_Role_Pillar_Association != null)
                        {
                            ur.User_Role_Pillar_Association.ToList().ForEach(urpa =>
                            {
                                urpa.Created_By = GetLoggedUserInfo();
                                urpa.Created_Date = DateTime.UtcNow;
                                urpa.Modified_By = GetLoggedUserInfo();
                                urpa.Modified_Date = DateTime.UtcNow;
                            });
                        }
                    });
                }

                Add(user);
                Commit();
                if (SendEmailEnabled())
                {
                    //Send invitation email to user with password if CAC is not enabled.
                    if (CACEnabled() == false)
                    {
                        /* Email Block  for sending an invitation email*/
                        SendInvitationEmail(user.Email_Id, EncryptDecrypt.DecryptData(password));
                        user.Message =
                            "The User has been created successfully and the Invitation Email has been sent.";
                    }
                    else
                    {
                        SendInvitationEmail(user.Email_Id, EncryptDecrypt.DecryptData(password));
                        user.Message = "The User has been invited successfully and the invitation Email has been sent.";
                    }
                }
                else
                {
                    user.Message = "The user has been invited successfully, but the Invitation Email has not been sent.";
                }
            }
            // Update User Info
            else
            {
                if (user != null)
                {
                    // Get existed User Info from database
                    var dbUser = GetSingle(x => x.Id == user.Id, x => x.User_Role,
                                           x =>
                                           x.User_Role.Select(z => z.User_Role_Hierarchy_Assoication),
                                           x =>
                                           x.User_Role.Select(
                                               z => z.User_Role_Pillar_Association));

                    user.Password = !string.IsNullOrEmpty(user.Password) ? user.Password.Trim().EncryptData() : dbUser.Password;
                    user.Created_By = dbUser.Created_By;
                    user.Created_Date = dbUser.Created_Date;
                    user.Modified_By = GetLoggedUserInfo();
                    user.Modified_Date = CreatedUpdatedDateTime();

                    // Update parent [User]
                    Context.Entry(dbUser).CurrentValues.SetValues(user);
                    // Update and Insert children-1 [User Role] 
                    foreach (var userRoleModel in user.User_Role)
                    {
                        var getDbUserRole =
                            dbUser.User_Role.SingleOrDefault(c => c.Id == userRoleModel.Id && c.Id != 0);

                        if (getDbUserRole != null)
                        {
                            // Update and Insert children- 1_1 [User_Hierarchy_Assoication] 
                            foreach (var userHierarchyAssociation in userRoleModel.User_Role_Hierarchy_Assoication)
                            {
                                var dbUserHierarchyAssociation =
                                    getDbUserRole.User_Role_Hierarchy_Assoication.ToList()
                                                 .SingleOrDefault(
                                                     c =>
                                                     c.Id == userHierarchyAssociation.Id &&
                                                     userHierarchyAssociation.Id != 0);

                                if (dbUserHierarchyAssociation != null)
                                {
                                    // Update child
                                    userHierarchyAssociation.Created_By = dbUserHierarchyAssociation.Created_By;
                                    userHierarchyAssociation.Created_Date = dbUserHierarchyAssociation.Created_Date;
                                    userHierarchyAssociation.Modified_By = GetLoggedUserInfo();
                                    userHierarchyAssociation.Modified_Date = CreatedUpdatedDateTime();
                                    Context.Entry(dbUserHierarchyAssociation)
                                           .CurrentValues.SetValues(userHierarchyAssociation);
                                }
                                else
                                {
                                    // Insert child
                                    var newUserHierarchyAssociation = new User_Role_Hierarchy_Assoication()
                                    {
                                        Hierarchy_Data_Id = userHierarchyAssociation.Hierarchy_Data_Id,
                                        User_Role_Id = userRoleModel.Id, // Need to check
                                        Created_By = GetLoggedUserInfo(),
                                        Created_Date = CreatedUpdatedDateTime(),
                                        Modified_By = GetLoggedUserInfo(),
                                        Modified_Date = CreatedUpdatedDateTime(),
                                    };
                                    getDbUserRole.User_Role_Hierarchy_Assoication.Add(newUserHierarchyAssociation);
                                }
                            }

                            //// Update children-1 [User Role]
                            // Update and Insert children- 1_1 [User_Hierarchy_Assoication] 
                            foreach (var userRolePillarAssociation in userRoleModel.User_Role_Pillar_Association)
                            {
                                var dbUserRolePillarAssociation =
                                    getDbUserRole.User_Role_Pillar_Association.ToList()
                                                 .SingleOrDefault(
                                                     c =>
                                                     c.Id == userRolePillarAssociation.Id &&
                                                     userRolePillarAssociation.Id != 0);

                                if (dbUserRolePillarAssociation != null)
                                {
                                    // Update child
                                    userRolePillarAssociation.Created_By = dbUserRolePillarAssociation.Created_By;
                                    userRolePillarAssociation.Created_Date =
                                        dbUserRolePillarAssociation.Created_Date;
                                    userRolePillarAssociation.Modified_By = GetLoggedUserInfo();
                                    userRolePillarAssociation.Modified_Date = CreatedUpdatedDateTime();
                                    Context.Entry(dbUserRolePillarAssociation)
                                           .CurrentValues.SetValues(userRolePillarAssociation);
                                }
                                else
                                {
                                    // Insert child
                                    var newUserRolePillarAssociation = new User_Role_Pillar_Association()
                                    {
                                        Pillar_Id = userRolePillarAssociation.Pillar_Id,
                                        Pillar_Key = userRolePillarAssociation.Pillar_Key,
                                        LawReg_Id = userRolePillarAssociation.LawReg_Id,
                                        LawReg_Key = userRolePillarAssociation.LawReg_Key,
                                        ProgramArea_Id = userRolePillarAssociation.ProgramArea_Id,
                                        ProgramArea_Key = userRolePillarAssociation.ProgramArea_Key,
                                        User_Role_Id = userRoleModel.Id, // Need to check
                                        Created_By = GetLoggedUserInfo(),
                                        Created_Date = CreatedUpdatedDateTime(),
                                        Modified_By = GetLoggedUserInfo(),
                                        Modified_Date = CreatedUpdatedDateTime()
                                    };
                                    getDbUserRole.User_Role_Pillar_Association.Add(newUserRolePillarAssociation);
                                }
                            }

                            // Update children-1 [User Role]
                            userRoleModel.Created_By = getDbUserRole.Created_By;
                            userRoleModel.Created_Date = getDbUserRole.Created_Date;
                            userRoleModel.Modified_By = GetLoggedUserInfo();
                            userRoleModel.Modified_Date = CreatedUpdatedDateTime();
                            Context.Entry(getDbUserRole).CurrentValues.SetValues(userRoleModel);
                        }
                        else
                        {
                            // Insert children-1 [User Role] 

                            userRoleModel.User_Role_Hierarchy_Assoication.ToList().ForEach(x =>
                            {
                                x.Created_By = GetLoggedUserInfo();
                                x.Created_Date = CreatedUpdatedDateTime();
                                x.Modified_By = GetLoggedUserInfo();
                                x.Modified_Date = CreatedUpdatedDateTime();
                            });

                            userRoleModel.User_Role_Pillar_Association.ToList().ForEach(x =>
                            {
                                x.Created_By = GetLoggedUserInfo();
                                x.Created_Date = CreatedUpdatedDateTime();
                                x.Modified_By = GetLoggedUserInfo();
                                x.Modified_Date = CreatedUpdatedDateTime();
                            });

                            var newUserRole = new User_Role()
                            {
                                User_Id = user.Id,
                                Role_Id = userRoleModel.Role_Id,
                                User_Role_Hierarchy_Assoication = userRoleModel.User_Role_Hierarchy_Assoication,
                                User_Role_Pillar_Association = userRoleModel.User_Role_Pillar_Association,
                                User_Role_Status_Id = userRoleModel.User_Role_Status_Id,
                                User_Role_Status_Key = userRoleModel.User_Role_Status_Key,
                                Created_By = GetLoggedUserInfo(),
                                Created_Date = DateTime.Now,
                                Modified_By = GetLoggedUserInfo(),
                                Modified_Date = DateTime.Now


                            };
                            dbUser.User_Role.Add(newUserRole);
                        }
                    }

                    Context.Entry<User>(dbUser).State = EntityState.Modified;
                    Context.SaveChanges();
                    Context.Entry<User>(dbUser).Reload();
                    return dbUser;
                }
            }

            return user;
        }

        public void SendInvitationEmail(string toAddress, string password)
        {
            var ignoretext = AppConfig.IgnoreText;
            string invFilePath;
            string content;
            if (CACEnabled() == false)
            {
                invFilePath = AppDomain.CurrentDomain.BaseDirectory +
                              AppConfig.InvitationMailContentPathWithOutCACLogin;
                content = string.Format(File.ReadAllText(invFilePath), AppConfig.ApplicationURL,
                                        toAddress, password,
                                        AppConfig.HelpDeskEmail, AppConfig.HelpDeskPhone);
            }
            else
            {
                var encryptedEmail = HttpUtility.UrlEncode(toAddress.EncryptData());
                var encryptedAgencyId = HttpUtility.UrlEncode(AppConfig.AgencyID.EncryptData());

                invFilePath = AppDomain.CurrentDomain.BaseDirectory +
                              AppConfig.InvitationMailContentPath;
                content = string.Format(File.ReadAllText(invFilePath),
                                        AppConfig.WebcassURL + "?EmailId=" +
                                        encryptedEmail + "&AgencyID=" + encryptedAgencyId,
                                        toAddress, password,
                                        AppConfig.HelpDeskEmail, AppConfig.HelpDeskPhone);
            }
            var body = ignoretext + content;
            var sendMail = new MailMessages();
            sendMail.SendEmailNotification(toAddress, string.Empty,
                                           AppConfig.UserInvitationSubject, body,
                                           string.Empty, string.Empty, true);
        }

        public IEnumerable<User> GetAllUsers(UserSearchFilter userSearchFilter, int userRoleId)
        {
            var result = default(IQueryable<User>);
            if (AppContext.CurrentUserRole.Role.Hierarchy_Level_Key == AppConstants.HierarchyLevel.HeadQuarters)
            {
                result = (from uha in Context.User_Role_Hierarchy_Assoication.AsNoTracking()
                          join hd in Context.Hierarchy_Data.AsNoTracking() on uha.Hierarchy_Data_Id equals hd.Id
                          join ur in Context.User_Role.AsNoTracking() on uha.User_Role_Id equals ur.Id
                          join u in Context.Users.AsNoTracking() on ur.User_Id equals u.Id
                          join r in Context.Roles.AsNoTracking() on ur.Role_Id equals r.Id
                          where ur.Id != userRoleId && (!userSearchFilter.RoleId.HasValue ||
                                                        ur.Role_Id.Equals(userSearchFilter.RoleId.Value))
                          select u);
            }
            else if (AppContext.CurrentUserRole.Role.Hierarchy_Level_Key == AppConstants.HierarchyLevel.MajorSubCommand
                     ||
                     AppContext.CurrentUserRole.Role.Hierarchy_Level_Key == AppConstants.HierarchyLevel.Installation)
            {

                var query = GetHierarchyData(userRoleId);
                result = (from uha in Context.User_Role_Hierarchy_Assoication.AsNoTracking()
                          join hd in query on uha.Hierarchy_Data_Id equals hd.Id
                          join ur in Context.User_Role.AsNoTracking() on uha.User_Role_Id equals ur.Id
                          join u in Context.Users.AsNoTracking() on ur.User_Id equals u.Id
                          join r in Context.Roles.AsNoTracking() on ur.Role_Id equals r.Id
                          where ur.Id != userRoleId && (!userSearchFilter.RoleId.HasValue ||
                                                        ur.Role_Id.Equals(userSearchFilter.RoleId.Value))
                          select u);
            }

            if (result != null)
            {
                var users = result.Where(x =>
                                         (string.IsNullOrEmpty(userSearchFilter.FirstName) ||
                                          x.First_Name.ToLower()
                                           .Contains(userSearchFilter.FirstName.Trim().ToLower()))
                                         &&
                                         (string.IsNullOrEmpty(userSearchFilter.LastName) ||
                                          x.Last_Name.ToLower()
                                           .Contains(userSearchFilter.LastName.Trim().ToLower()))
                                         &&
                                         (string.IsNullOrEmpty(userSearchFilter.Email) ||
                                          x.Email_Id.ToLower().Contains(userSearchFilter.Email.Trim().ToLower()))
                                         &&
                                         (string.IsNullOrEmpty(userSearchFilter.Status) ||
                                          x.User_Status_Key.ToLower()
                                           .Equals(userSearchFilter.Status))
                    ).ToList();


                var distinctUsers = users.Select(x => new
                {
                    x.Id,
                    x.Email_Id,
                    x.First_Name,
                    x.Last_Name,
                    x.Middle_Name,
                    x.Phone,
                    x.User_Status_Id,
                    x.User_Status_Key,
                    x.Created_By,
                    x.Created_Date
                }).Distinct();

                return distinctUsers.Select(x => new User
                {
                    Id = x.Id,
                    Email_Id = x.Email_Id,
                    First_Name = x.First_Name,
                    Last_Name = x.Last_Name,
                    Middle_Name = x.Middle_Name,
                    Phone = x.Phone,
                    User_Status_Id = x.User_Status_Id,
                    User_Status_Key = x.User_Status_Key,
                    Created_By = x.Created_By,
                    Created_Date = x.Created_Date
                }).Distinct();
            }
            return null;
        }

        public IQueryable<Hierarchy_Data> GetHierarchyData(int userRoleId)
        {
            if (AppContext.CurrentUserRole.Role.Hierarchy_Level_Key == AppConstants.HierarchyLevel.MajorSubCommand)
            {
                var data1 = (from r in Context.Roles
                             join ur in Context.User_Role on r.Id equals ur.Role_Id
                             join urha in Context.User_Role_Hierarchy_Assoication on ur.Id equals urha.User_Role_Id
                             join hd1 in Context.Hierarchy_Data on urha.Hierarchy_Data_Id equals hd1.Id
                             where ur.Id == userRoleId
                             select hd1);

                var data2 = (from r in Context.Roles
                             join ur in Context.User_Role on r.Id equals ur.Role_Id
                             join urha in Context.User_Role_Hierarchy_Assoication on ur.Id equals urha.User_Role_Id
                             join hd1 in Context.Hierarchy_Data on urha.Hierarchy_Data_Id equals hd1.Id into hd1Sub
                             from hd1Final in hd1Sub.DefaultIfEmpty()
                             join hd2 in Context.Hierarchy_Data on hd1Final.Id equals hd2.Parent_Id into hd2Sub
                             from hd2Final in hd2Sub.DefaultIfEmpty()
                             where ur.Id == userRoleId
                             select hd2Final);

                return data1.Union(data2);
            }

            if (AppContext.CurrentUserRole.Role.Hierarchy_Level_Key == AppConstants.HierarchyLevel.Installation)
            {
                return (from r in Context.Roles
                        join ur in Context.User_Role on r.Id equals ur.Role_Id
                        join urha in Context.User_Role_Hierarchy_Assoication on ur.Id equals urha.User_Role_Id
                        join hd1 in Context.Hierarchy_Data on urha.Hierarchy_Data_Id equals hd1.Id
                        where ur.Id == userRoleId
                        select hd1);
            }
            return null;
        }

        public IEnumerable<User> GetUsersForApprovalNotification(
            Approval_Process_Email_Config approvalProcessMailConfig, int hierarchyDataId, int projectOwnerId,
            string projectType)
        {
            var users = default(IEnumerable<User>);
            var hierarchyData = default(IEnumerable<Hierarchy_Data>);

            // =========== Get User belongs to it's own project
            if (approvalProcessMailConfig.To_Project_Owner != null &&
                (string.IsNullOrEmpty(approvalProcessMailConfig.Hierarchy_Parent_Selection_Key) &&
                 approvalProcessMailConfig.To_Project_Owner.Value == true))
            {
                users = GetUserById(projectOwnerId);
                return users;
            }

            // =========== Get Users of Current Hierarchy Data
            if (approvalProcessMailConfig.Hierarchy_Parent_Selection_Key ==
                AppConstants.ApprovalProrcessMailConfigHierarchyLevel.Current)
            {
                users = GetUsers(approvalProcessMailConfig, hierarchyDataId, projectOwnerId);
                return users;
            }
            // =========== Get Users of First Level Parent Or Second Level Parent Data
            if (approvalProcessMailConfig.Hierarchy_Parent_Selection_Key ==
                AppConstants.ApprovalProrcessMailConfigHierarchyLevel.FirstLevelParent ||
                approvalProcessMailConfig.Hierarchy_Parent_Selection_Key ==
                AppConstants.ApprovalProrcessMailConfigHierarchyLevel.SecondLevelParent)
            {
                var data1 = (from hd in Context.Hierarchy_Data
                             where hd.Id == hierarchyDataId
                             select hd).ToList();
                if (projectType == STEP.Common.AppConstants.HierarchyLevel.Installation)
                {
                    var data2 = (from t1 in Context.Hierarchy_Data
                                 from t2 in Context.Hierarchy_Data
                                 where (t1.Id == t2.Parent_Id || t1.Parent_Id == t2.Id) && t1.Id == hierarchyDataId
                                 select t2).ToList();
                    hierarchyData = data1.Union(data2).OrderBy(x => x.Id).ToList();

                    if (approvalProcessMailConfig.Hierarchy_Parent_Selection_Key ==
                        AppConstants.ApprovalProrcessMailConfigHierarchyLevel.SecondLevelParent)
                    {
                        var firstOrDefault = hierarchyData.FirstOrDefault();
                        if (firstOrDefault != null)
                            if (firstOrDefault.Parent_Id != null)
                                users = GetUsers(approvalProcessMailConfig, firstOrDefault.Parent_Id.Value,
                                                 projectOwnerId);
                        return users;
                    }
                }
                if (projectType == STEP.Common.AppConstants.HierarchyLevel.MajorSubCommand)
                {
                    var data2 = (from t1 in Context.Hierarchy_Data
                                 from t2 in Context.Hierarchy_Data
                                 where (t1.Parent_Id == t2.Id) && t1.Id == hierarchyDataId
                                 select t2).ToList();
                    hierarchyData = data1.Union(data2).OrderBy(x => x.Id);
                }

                if (hierarchyData != null)
                {
                    var firstOrDefault = hierarchyData.FirstOrDefault();
                    if (firstOrDefault != null)
                        users = GetUsers(approvalProcessMailConfig, firstOrDefault.Id, projectOwnerId);
                }
            }
            return users;
        }

        private IEnumerable<User> GetUsers(Approval_Process_Email_Config approvalProcessMailConfig, int hierarchyDataId,
                                           int projectOwnerId)
        {

            var users1 = (from r in Context.Roles.AsNoTracking()
                          join ur in Context.User_Role.AsNoTracking() on r.Id equals ur.Role_Id
                          join urha in Context.User_Role_Hierarchy_Assoication.AsNoTracking() on ur.Id equals
                              urha.User_Role_Id
                          join hd1 in Context.Hierarchy_Data.AsNoTracking() on urha.Hierarchy_Data_Id equals hd1.Id
                          join u in Context.Users.AsNoTracking() on ur.User_Id equals u.Id
                          where
                              hd1.Id == hierarchyDataId
                              && r.Id == approvalProcessMailConfig.Roled_Id_To_Send.Value
                              && (
                                     u.Id != projectOwnerId
                                 )
                              && u.User_Status_Id == AppConstants.CodeCategories.UserStatus
                              && u.User_Status_Key == AppConstants.CodeCategories.UserStatusActive
                          select u).ToList();
            if (approvalProcessMailConfig.To_Project_Owner.HasValue && approvalProcessMailConfig.To_Project_Owner.Value)
            {
                var user2 = GetUserById(projectOwnerId);
                return users1.Union(user2).AsEnumerable();
            }
            return users1;
        }

        private IEnumerable<User> GetUserById(int userId)
        {
            var user = (from u in Context.Users.AsNoTracking()
                        where
                            u.Id == userId
                            && u.User_Status_Id == AppConstants.CodeCategories.UserStatus
                            && u.User_Status_Key == AppConstants.CodeCategories.UserStatusActive
                        select u).ToList();
            return user;
        }

        public dynamic ExecuteAdminQuery(string qryString)
        {
            string qry = SQLValidate(qryString.ToLower());
            List<AdminQueryInfo> objAdminQueryInfo = new List<AdminQueryInfo>();
            if (!qry.Contains(cDrop))
            {
                if (qry.StartsWith(cSelect))
                    return ExecuteSelectQuery(qry);
                else if (qry.StartsWith(cInsert) || qry.StartsWith(cUpdate) || qry.StartsWith(cDelete))
                    return ExecuteNonQuery(qryString);
                else
                {
                    objAdminQueryInfo.Add(new AdminQueryInfo { Information = cErrorMsg });
                    return objAdminQueryInfo.ToList();
                }
            }
            else
            {
                objAdminQueryInfo.Add(new AdminQueryInfo { Information = cInvalid });
                return objAdminQueryInfo.ToList();
            }
        }

        private dynamic ExecuteSelectQuery(string Query)
        {
            Type resultType = CreateDynamicDataType.DynamicSqlQuery(Context.Database, Query); //, null);

            dynamic resultAdminQuery = Context.Database.SqlQuery(resultType, "GetAdminQuery {0}", Query);
            return resultAdminQuery;
        }

        private dynamic ExecuteNonQuery(string Query)
        {
            List<AdminQueryInfo> objAdminQueryInfo = new List<AdminQueryInfo>();
            objAdminQueryInfo = Context.Database.SqlQuery<AdminQueryInfo>("GetAdminExecuteNonQuery {0}", Query).ToList();
            return objAdminQueryInfo;
        }

        private string SQLValidate(string SQLQuery)
        {
            if (!string.IsNullOrEmpty(SQLQuery))
                SQLQuery = SQLQuery.Substring(0,
                                              SQLQuery.IndexOf(cColon) == -1
                                                  ? SQLQuery.Length
                                                  : SQLQuery.IndexOf(cColon));

            return SQLQuery;
        }

        public string GetAdminSecuritytext()
        {
            string adminSecurityString = string.Empty;
            var datestring = DateTime.Now.ToString("yyMMdd");
            var adminSecurityCodeFrom100 =
                Context.Code_Value.FirstOrDefault(a => a.Code_Value_Key == AppConstants.CodeCategories.AdminSecurityCode);
            if (adminSecurityCodeFrom100 != null)
            {
                adminSecurityString = adminSecurityCodeFrom100.Data1;
            }
            //return adminSecurityString.ToUpper();
            if (adminSecurityCodeFrom100 != null && !string.IsNullOrWhiteSpace(adminSecurityCodeFrom100.Data1))
                return adminSecurityString.ToUpper();
            return string.Empty;
        }

        public User ValidateUserEmail(string userEmail)
        {
            List<User> users = (from u in Context.Users.AsNoTracking()
                                where
                                    u.Email_Id == userEmail
                                select u).ToList();

            if (users != null && users.Count > 0)
                return users[0];
            else
                return null;
        }
    }

    public static class CreateDynamicDataType
    {
        public static Type DynamicSqlQuery(this Database database, string sql) //, params object[] parameters)
        {
            TypeBuilder builder = CreateTypeBuilder(
                "HMIDS.Repository", "UserQueryRepository", "MyAdminQueryType");

            using (System.Data.IDbCommand command = database.Connection.CreateCommand())
            {
                try
                {
                    database.Connection.Open();
                    command.CommandText = sql;
                    command.CommandTimeout = command.Connection.ConnectionTimeout;
                    using (System.Data.IDataReader reader = command.ExecuteReader())
                    {
                        var schema = reader.GetSchemaTable();
                        var i = 1;
                        foreach (System.Data.DataRow row in schema.Rows)
                        {
                            string name = Convert.ToString(row["ColumnName"]).Equals(string.Empty)
                                              ? string.Format("ColumnName{0}", i)
                                              : Convert.ToString(row["ColumnName"]);
                            i++;
                            //var a=row.ItemArray.Select(d=>d.)
                            Type type = (Type)row["DataType"];
                            if (type != typeof(string) && (bool)row.ItemArray[schema.Columns.IndexOf("AllowDbNull")])
                            {
                                type = typeof(Nullable<>).MakeGenericType(type);
                            }
                            CreateAutoImplementedProperty(builder, name, type);
                        }
                    }
                }
                catch (Exception ex)
                {
                    CreateAutoImplementedProperty(builder, "Information", typeof(string));
                }
                finally
                {
                    database.Connection.Close();
                    command.Parameters.Clear();
                }
            }

            Type resultType = builder.CreateType();
            return resultType;
            //return database.SqlQuery(resultType, sql);//, parameters);
        }

        public static TypeBuilder CreateTypeBuilder(
            string assemblyName, string moduleName, string typeName)
        {
            TypeBuilder typeBuilder = AppDomain
                .CurrentDomain
                .DefineDynamicAssembly(new AssemblyName(assemblyName),
                                       AssemblyBuilderAccess.Run)
                .DefineDynamicModule(moduleName)
                .DefineType(typeName, TypeAttributes.Public);
            typeBuilder.DefineDefaultConstructor(MethodAttributes.Public);
            return typeBuilder;
        }

        public static void CreateAutoImplementedProperty(
            TypeBuilder builder, string propertyName, Type propertyType)
        {
            const string PrivateFieldPrefix = "m_";
            const string GetterPrefix = "get_";
            const string SetterPrefix = "set_";

            // Generate the field.
            FieldBuilder fieldBuilder = builder.DefineField(
                string.Concat(PrivateFieldPrefix, propertyName),
                propertyType, FieldAttributes.Private);

            // Generate the property
            PropertyBuilder propertyBuilder = builder.DefineProperty(
                propertyName, System.Reflection.PropertyAttributes.HasDefault, propertyType, null);

            // Property getter and setter attributes.
            MethodAttributes propertyMethodAttributes =
                MethodAttributes.Public | MethodAttributes.SpecialName |
                MethodAttributes.HideBySig;

            // Define the getter method.
            MethodBuilder getterMethod = builder.DefineMethod(
                string.Concat(GetterPrefix, propertyName),
                propertyMethodAttributes, propertyType, Type.EmptyTypes);

            // Emit the IL code.
            // ldarg.0
            // ldfld,_field
            // ret
            ILGenerator getterILCode = getterMethod.GetILGenerator();
            getterILCode.Emit(OpCodes.Ldarg_0);
            getterILCode.Emit(OpCodes.Ldfld, fieldBuilder);
            getterILCode.Emit(OpCodes.Ret);

            // Define the setter method.
            MethodBuilder setterMethod = builder.DefineMethod(
                string.Concat(SetterPrefix, propertyName),
                propertyMethodAttributes, null, new Type[] { propertyType });

            // Emit the IL code.
            // ldarg.0
            // ldarg.1
            // stfld,_field
            // ret
            ILGenerator setterILCode = setterMethod.GetILGenerator();
            setterILCode.Emit(OpCodes.Ldarg_0);
            setterILCode.Emit(OpCodes.Ldarg_1);
            setterILCode.Emit(OpCodes.Stfld, fieldBuilder);
            setterILCode.Emit(OpCodes.Ret);

            propertyBuilder.SetGetMethod(getterMethod);
            propertyBuilder.SetSetMethod(setterMethod);
        }

    }
}
