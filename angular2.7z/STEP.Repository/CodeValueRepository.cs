﻿using System.Collections.Generic;
using STEP.Models;
using System.Linq;
using System.Data.Linq;

namespace STEP.Repository
{
    public class CodeValueRepository : EntityBaseRepository<Code_Value>, ICodeValueRepository
    {
        public readonly STEPContext Context;
        public CodeValueRepository(STEPContext context)
            : base(context)
        {

            Context = context;
        }

        public IList<Code_Value> GetCodeValues(int codeId)
        {
            return this.FindBy(x => x.Code_ID == codeId).ToList();
        } 

        /// <summary>
        /// Gets the code description of corresponding codeId and Code Key.
        /// </summary>
        /// <param name="codeId">Code ID</param>
        /// <param name="codeKey">Code Key</param>
        /// <returns>Code Descriprion</returns>
       
        public string GetCodeDescription(int codeId, string codeKey)
        {
            var codevalue = Context.Code_Value.AsQueryable<Code_Value>().ToList();
            var codeDescription = codevalue.Where(p => p.Code_Value_Key == codeKey &&
                                                      p.Code_ID == codeId)
                                          .Select(p => p.Code_Value_Description).FirstOrDefault();
            return codeDescription;
        }

        public Code_Value GetCodeValue(int codeId, string codeKey)
        {
            return GetSingle(x => x.Code_ID == codeId && x.Code_Value_Key == codeKey);
        }


        public List<Code_Value> GetCodeValues(List<Code_Value> codeValueList, int codeId, bool isExcludeAll = false)
        {
            if (isExcludeAll)
            {
                var data1 =
                    codeValueList.Where(
                        x =>
                        x.Code_ID == codeId && x.Code_Value_Key.ToUpper() != STEP.Common.AppConstants.CodeCategories.ALL)
                                 .Select(y => new Code_Value()
                                     {
                                         Id = y.Id,
                                         Code_ID = y.Code_ID,
                                         Code_Value_Key = y.Code_Value_Key,
                                         Code_Value_Description = y.Code_Value_Description,
                                         Data1 = y.Data1,
                                         SequenceNumber = y.SequenceNumber
                                     }).ToList();
                return data1;
            }

            var data = codeValueList.Where(x => x.Code_ID == codeId).Select(y => new Code_Value()
            {
                Id = y.Id,
                Code_ID = y.Code_ID,
                Code_Value_Key = y.Code_Value_Key,
                Code_Value_Description = y.Code_Value_Description,
                Data1 = y.Data1,
                SequenceNumber = y.SequenceNumber
            }).ToList();
            return data;
        }

        public Code_Value GetCodeValue(List<Code_Value> codeValueList, int codeId,string codeKey) 
         {
             return codeValueList.FirstOrDefault(x => x.Code_ID == codeId && x.Code_Value_Key == codeKey);
         }
    }
}
