using System;
using System.Security.Cryptography;
using System.Text;
// This following references code added by Narender Patlolla for FIPS 03/27/2014
//using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;
using System.Configuration;
using System.IO;


namespace STEP.Common
{
    public static class EncryptDecrypt
    {
        // This following variables added by Narender Patlolla for FIPS 03/27/2014

        private static string passphrase;
        private static readonly int KeyLengthBits;
        private static readonly int SaltLength;
        private static readonly RNGCryptoServiceProvider rng;

        // This following new constructor added by Narender Patlolla for FIPS 03/27/2014
        //FIPS Changes added static constructor to instantiate sttaic varaiables and contants
        static EncryptDecrypt()
        {
            passphrase = ConfigurationManager.AppSettings["SecurityKey"].ToString();
            KeyLengthBits = 256; //AES Key Length in bits
            SaltLength = 8; //Salt length in bytes
            rng = new RNGCryptoServiceProvider();
        }

        #region Encrypt string


        public static string EncryptData(this string toEncrypt)
        {
            //This following code commented and added new code by Narender Patlolla for FIPS 03/27/2014
            //Modified new FIPS Hash code for EncryptData
            //return EncryptString(toEncrypt, passphrase);
            string ec = EncryptString(toEncrypt, passphrase);
            return ec;
        }

        public static string DecryptData(string cipherString)
        {
            //This following code commented and added new code by Narender Patlolla for FIPS 03/27/2014
            //Modified new FIPS Hash code for DecryptData
            //return DecryptString(cipherString, passphrase);

            string dc = DecryptString(cipherString, passphrase);
            return dc;
        }


        private static string DecryptString(string ciphertext, string passphrase)
        // This following new methods added by Narender Patlolla for FIPS 03/27/2014
        //New FIPS Methods Begin
        {
            var inputs = ciphertext.Split(":".ToCharArray(), 3);
            var iv = Convert.FromBase64String(inputs[0]); // Extract the IV
            var salt = Convert.FromBase64String(inputs[1]); // Extract the salt
            var ciphertextBytes = Convert.FromBase64String(inputs[2]); // Extract the ciphertext
            byte[] plaintext = null;
            //try
            //{

            // Derive the key from the supplied passphrase and extracted salt
            byte[] key = DeriveKeyFromPassphrase(passphrase, salt);

            // Decrypt
            plaintext = DoCryptoOperation(ciphertextBytes, key, iv, false);

            //}
            //catch (Exception e)
            //{ 

            //}

            // Return the decrypted string
            return Encoding.UTF8.GetString(plaintext);
        }

        private static string EncryptString(string plaintext, string passphrase)
        {
            var salt = GenerateRandomBytes(SaltLength); // Random salt
            var iv = GenerateRandomBytes(16); // AES is always a 128-bit block size
            var key = DeriveKeyFromPassphrase(passphrase, salt); // Derive the key from the passphrase

            // Encrypt
            var ciphertext = DoCryptoOperation(Encoding.UTF8.GetBytes(plaintext), key, iv, true);

            // Return the formatted string
            return String.Format("{0}:{1}:{2}", Convert.ToBase64String(iv), Convert.ToBase64String(salt), Convert.ToBase64String(ciphertext));
        }

        private static byte[] DeriveKeyFromPassphrase(string passphrase, byte[] salt)
        {
            int iterationCount = 2000;
            var keyDerivationFunction = new Rfc2898DeriveBytes(passphrase, salt, iterationCount);  //PBKDF2

            return keyDerivationFunction.GetBytes(KeyLengthBits / 8);
        }

        private static byte[] GenerateRandomBytes(int lengthBytes)
        {
            var bytes = new byte[lengthBytes];
            rng.GetBytes(bytes);

            return bytes;
        }

        // This function does both encryption and decryption, depending on the value of the "encrypt" parameter
        private static byte[] DoCryptoOperation(byte[] inputData, byte[] key, byte[] iv, bool encrypt)
        {
            byte[] output;

            using (var aes = new AesCryptoServiceProvider())
            using (var ms = new MemoryStream())
            {
                //aes.Padding = PaddingMode.None;
                var cryptoTransform = encrypt ? aes.CreateEncryptor(key, iv) : aes.CreateDecryptor(key, iv);

                using (var cs = new CryptoStream(ms, cryptoTransform, CryptoStreamMode.Write))
                    cs.Write(inputData, 0, inputData.Length);

                output = ms.ToArray();
            }

            return output;
        }

        //FIPS Methods End

        #endregion

        public static string CreateRandomPassword()
        {
            char[] chars;
            //Generate a random password of length given to intLenghtOfString
            int PasswordLength = STEP.Common.AppConstants.PasswordLength;

            string _allowedChars = STEP.Common.AppConstants.RandomPasswordAllowedCharacters;
            Random randomNumber = new Random();
            chars = new char[PasswordLength];
            int allowedCharCount = _allowedChars.Length;

            for (int PasswordCharIndex = 0; PasswordCharIndex < PasswordLength; PasswordCharIndex++)
            {
                chars[PasswordCharIndex] = _allowedChars[(Convert.ToInt32(randomNumber.Next(allowedCharCount)))];
            }

            return new string(chars);
        }
    }
}
