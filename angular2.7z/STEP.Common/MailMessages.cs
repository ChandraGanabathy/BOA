using System;
using System.Net.Mail;
using System.Web;

namespace STEP.Common
{
    public class MailMessages
    {
        private readonly MailMessage _message = new MailMessage();
        private readonly SmtpClient _smtpClient = new SmtpClient();

        #region Fields & Properties

        private string _strSmtpServer = string.Empty;
        // Naren for FIPS Test
        private readonly bool _strMailServerEnabled;
        private int _intSmtpPort = 0;

        #endregion

        public MailMessages()
        {
            var keyEmailEnabled = System.Configuration.ConfigurationManager.AppSettings["SendEmail"];
            _strMailServerEnabled = !string.IsNullOrEmpty(keyEmailEnabled) && Convert.ToBoolean(keyEmailEnabled);
        }

        public string SendEmailNotification(string toAdd, string frmAdd, string subject, string content, string filepath,
                                            string fileName, bool isHtmlContent)
        {
            string strRetVal = "";
            _strSmtpServer = AppConfig.EmailServer;
            _intSmtpPort = AppConfig.EmailServerPort;
            // From address will be taken from the configuration rather than using the SMTP user name
            var senderEmail = AppConfig.FromEmail;
            var fromAddress = new MailAddress(senderEmail);
            var adminEmailAddress = AppConfig.AdminEmail.Replace(',', ';');

            var strEMailContent = content;

            _message.From = fromAddress;
            _message.Subject = subject;
            if (!isHtmlContent)
                strEMailContent = strEMailContent.Replace("\r\n", "</br>").Replace("\n", "</br>");
            _message.Body = strEMailContent;
            _message.IsBodyHtml = true;

            _smtpClient.Host = _strSmtpServer;
            _smtpClient.Port = _intSmtpPort;

            var smtpUseCredentials = AppConfig.SMTPUseCredentials;
            var issmtpUseCredentials = false;
            if (!string.IsNullOrEmpty(smtpUseCredentials))
            {
                issmtpUseCredentials = Convert.ToBoolean(smtpUseCredentials);
            }
            if (issmtpUseCredentials)
            {
                _smtpClient.Credentials = new System.Net.NetworkCredential(AppConfig.SMTPUserName,
                                                                           AppConfig.SMTPPassword);
                _smtpClient.EnableSsl = true;
            }
            if (!string.IsNullOrEmpty(filepath) && !string.IsNullOrEmpty(fileName))
            {
                var emailNotificationAttachment =
                    new Attachment(HttpContext.Current.Server.MapPath(AppConfig.FileURL + fileName))
                        {
                            Name = fileName
                        };
                _message.Attachments.Add(emailNotificationAttachment);
            }
            if (toAdd.Contains(";"))
            {
                toAdd = toAdd.Substring(0, toAdd.Length - 1);
            }
            //  remove the last ; in the string since that will introduce a blank email into the toAddress string array.
            string[] toAddress = toAdd.TrimEnd(';').Split(';');
            string strSuccessfulRecipients = "";
            string strUnsuccessfulRecipients = "";

            //  Mail will not be sent if the # of email addresses are > a defined number (defined in the Inetmgr-->MailServer) - Restriction on Mail server.
            //  This Max number is hardocded in the config file - Ensure that it is the same as the number defined in Inetmgr
            //  All mail addresses will be split into groups of max_number and email will be sent out in phases to each of the groups of the max_number of users.
            int intMaxNumberOfAllowedRecipients = AppConfig.MassEMailMaxRecipientsPerMail;
            int intNumberOfGroupsOfMaxAllowedRecipients = toAddress.Length / intMaxNumberOfAllowedRecipients;
            //bool boolFinalResult = true;
            if (intNumberOfGroupsOfMaxAllowedRecipients > 0)
            {
                for (int intCurrentGroup = 1;
                     intCurrentGroup <= intNumberOfGroupsOfMaxAllowedRecipients;
                     intCurrentGroup++)
                {
                    bool boolMessageSentInCurrentLoop = true;
                    _message.To.Clear();

                    int intCurrentStartIndex = ((intCurrentGroup - 1) * intMaxNumberOfAllowedRecipients);
                    //starts at 0, 100, 200, etc. if max_number = 100
                    int intCurrentEndIndex = intCurrentStartIndex + (intMaxNumberOfAllowedRecipients - 1);
                    //ends at 99, 199, 299, etc. if max_number = 100
                    for (int index = intCurrentStartIndex; index <= intCurrentEndIndex; index++)
                    {
                        _message.To.Add(new MailAddress(toAddress[index]));
                    }

                    try
                    {
                        if (_strMailServerEnabled)
                        {
                            _smtpClient.Timeout = 10000000;
                            _smtpClient.Send(_message);
                        }
                    }
                    catch (Exception ex)
                    {
                        boolMessageSentInCurrentLoop = false;
                    }
                    if (boolMessageSentInCurrentLoop)
                    {
                        for (int index = intCurrentStartIndex; index <= intCurrentEndIndex; index++)
                        {
                            strSuccessfulRecipients += toAddress[index] + ";";
                        }
                    }
                    else
                    {
                        for (int index = intCurrentStartIndex; index <= intCurrentEndIndex; index++)
                        {
                            strUnsuccessfulRecipients += toAddress[index] + ";";
                        }
                    }
                }
                //  Sending email to last group of users (group contains less than 100 email addresses and hence will not be part of the above lists)
                bool boolMessageSent = true;
                for (int index = intNumberOfGroupsOfMaxAllowedRecipients * intMaxNumberOfAllowedRecipients;
                     index <= toAddress.Length - 1;
                     index++)
                {
                    _message.To.Add(new MailAddress(toAddress[index]));
                }
                try
                {
                    if (_strMailServerEnabled)
                    {
                        _smtpClient.Timeout = 10000000;
                        _smtpClient.Send(_message);
                    }
                }
                catch (Exception ex)
                {
                    boolMessageSent = false;
                }
                if (boolMessageSent)
                {
                    for (int index = intNumberOfGroupsOfMaxAllowedRecipients * intMaxNumberOfAllowedRecipients;
                         index <= toAddress.Length - 1;
                         index++)
                    {
                        strSuccessfulRecipients += toAddress[index] + ";";
                    }
                }
                else
                {
                    for (int index = intNumberOfGroupsOfMaxAllowedRecipients * intMaxNumberOfAllowedRecipients;
                         index <= toAddress.Length - 1;
                         index++)
                    {
                        strUnsuccessfulRecipients += toAddress[index] + ";";
                    }
                }
            }
            else //less than 100 emails addresses to be sent
            {
                bool boolMessageSent = true;
                for (int index = 0; index <= toAddress.Length - 1; index++)
                {
                    _message.To.Add(new MailAddress(toAddress[index]));
                }
                try
                {
                    if (_strMailServerEnabled)
                    {
                        _smtpClient.Send(_message);
                    }
                }
                catch (Exception ex)
                {
                    boolMessageSent = false;
                    //throw new Exception(ex.ToString());
                }
                if (boolMessageSent)
                {
                    for (int index = 0; index <= toAddress.Length - 1; index++)
                    {
                        strSuccessfulRecipients += toAddress[index] + ";";
                    }
                }
                else
                {
                    for (int index = 0; index <= toAddress.Length - 1; index++)
                    {
                        strUnsuccessfulRecipients += toAddress[index] + ";";
                    }
                }
            }
            //  send email to the from address with all the address that this email has been sent to.

            if (!string.IsNullOrEmpty(adminEmailAddress))  // Only if AdminEmail address present then send the Status email.
            {

                if (!strUnsuccessfulRecipients.Equals(""))
                {
                    strUnsuccessfulRecipients = strUnsuccessfulRecipients.Substring(0, strUnsuccessfulRecipients.Length - 1);
                }
                if (!strSuccessfulRecipients.Equals(""))
                {
                    strSuccessfulRecipients = strSuccessfulRecipients.Substring(0, strSuccessfulRecipients.Length - 1);
                }

                string[] strUnsuccessfulRecipientsList = strUnsuccessfulRecipients.Split(';');
                string[] strSuccessfulRecipientsList = strSuccessfulRecipients.Split(';');

                _message.To.Clear();


                string[] adminEmailArray = adminEmailAddress.Split(';');
                foreach (string email in adminEmailArray)
                {
                    if (!string.IsNullOrEmpty(email))
                        _message.To.Add(new MailAddress(email));
                }


                if (!strUnsuccessfulRecipients.Equals(""))
                {
                    _message.Subject = subject + " - ALERT! EMail not sent to some email addresses.";
                }
                else
                {
                    _message.Subject = subject + " - sent to all email addresses.";
                }
                _message.Body = "The E-Mail with the following message:</br></br>";
                if (!isHtmlContent)
                    strEMailContent = strEMailContent.Replace("\r\n", "</br>").Replace("\n", "</br>");
                _message.Body += strEMailContent;

                //            message.Body += toAdd;
                if (!strUnsuccessfulRecipients.Equals(""))
                {
                    _message.Body += "</br></br>has NOT been sent to the following email addresses:</br></br>";
                    for (int index = 0; index <= strUnsuccessfulRecipientsList.Length - 1; index++)
                    {
                        _message.Body += strUnsuccessfulRecipientsList[index] + "</br>";
                    }
                }

                if (!strSuccessfulRecipients.Equals(""))
                {
                    if (!strUnsuccessfulRecipients.Equals(""))
                    {
                        _message.Body +=
                            "</br></br>and has been successfully sent to the following email addresses:</br></br>";
                    }
                    else
                    {
                        _message.Body += "</br></br>has been successfully sent to the following email addresses:</br></br>";
                    }

                    for (int index = 0; index <= strSuccessfulRecipientsList.Length - 1; index++)
                    {
                        _message.Body += strSuccessfulRecipientsList[index] + "</br>";
                    }
                }

                _message.IsBodyHtml = true;

                try
                {
                    if (_strMailServerEnabled)
                    {
                        _smtpClient.Send(_message);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.ToString());
                }


                if (!strSuccessfulRecipients.Equals("")) //  Some received recipients are there
                {
                    if (!strUnsuccessfulRecipients.Equals("")) //  Some failed recipients are there
                    {
                        strRetVal = "PartiallySent";
                    }
                    else //  No failed recipients are there
                    {
                        strRetVal = "Sent";
                    }
                }
                else // No Successful Recipients
                {
                    if (!strUnsuccessfulRecipients.Equals("")) //  Some failed recipients are there
                    {
                        strRetVal = "Fail";
                    }
                    else //  No failed recipients are there
                    {
                        strRetVal = "Unknown";
                    }
                }
                _message.Dispose();


            } // End of sending the status email to the AdminEmail address
            return strRetVal;
        }
    }
}