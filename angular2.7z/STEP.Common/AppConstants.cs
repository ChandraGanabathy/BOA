﻿using System;

namespace STEP.Common
{
    public static class AppConstants
    {
        public static readonly Int16 TopRecordCount = 10;
        public static readonly string ImageFolderPath = "../Content/Images/";
        public static readonly string JsonDateFormatString = "MM/dd/yyyy";
        public static string Created_By_Default = "Plateauinc";
        public static string DefaultUserPasssword = "step";
        public static string NoAccessAction = "NoAccess";
        public static string UserEmailNotSentNotification = "The User is Invited but the Email is not sent";
        public const string UserInvitationSubject = "Invitation to join STEP";
        public const int PasswordLength = 9;
        public const string RandomPasswordAllowedCharacters = "123456789ABCDEFGHJKLMNOPQRSTUVWXYZ";


        public class CodeCategories
        {
            public static int SystemConstant = 100;
            public static int State = 200;
            public static int UserAuditAction = 300;

            public static int Theme = 1100;
            public static int UserStatus = 1300;
            public static int PageSize = 1400;

            public static int PAFGStatus = 1800;
            public static int PrioritizationStatus = 1801;
            public static int Status = 1999;
            public static int Pillar = 2000;
            public static int PB28Title = 2001;
            public static int PB28Category = 2002;
            public static int PB28SubCategory = 2003;
            public static int LawReg = 2004;
            public static int ProgramArea = 2005;
            public static int AnswerType = 2006;
            public static int ProjectStatus = 2007;
            public static int SourceOfProject = 2008;
            public static int Type = 2009;
            public static int ApprovalStatuss = 2010;
            public static int Class = 2011;
            public static int ResourceSponsor = 2012;
            public static int ChangeType = 2014;
            public static int ApprovalAction = 2015;
            public static int ReportsAction = 2016;
            public static int MDEP = 2019;
            public static int RoleGroups = 2018;
            public static int ImpacttoMission = 2020;
            public static int EnvironmentalImpact = 2022;
            public static int ProjectModuleConfig = 2023;
            public static int FundingStatus = 2024;


            public static string ALL = "ALL";
            public static string NumberofRecords = "TRCT";
            public static string Agency = "AGNY";
            public static string TotalNumberofRecordsTurnOn = "TOTC";
            public static string EnterPriseEMailFormat = "EEML";
            public static string AKOEMailFormat = "AEML";
            public static string FSCTopNRecords = "FSCT";
            public static string PagesCountToShow = "PCTS";
            public static string ApplicationVersion = "VRSN";
            public static string EmailNotificationSignature = "EMNS";
            public static string Documents = "USML";
            public static string AdminSecurityCode = "ASCD";
            public static string SessionTimeoutRedirectCodeValue = "STRU";
            public static string UserStatusActive = "ACTV";
            public static string UserStatusInActive = "IACT";
            public static string UserStatusInvited = "INVT";
            public static string UserStatusTerminated = "TERM";
            public static string SessionTimeoutRedirectUrl = "/UserManagement/AppUserLogin";
            public static string NumberOfFiscalYearRowsForFunding = "FYRO";
            public static string ProjectCreated = "PRCR";

            public static string PrioritizationCompleted = "PRCD";
            public static string NotPrioritized = "NPRD";
            public static string PlanningCompleted = "PLND";
            public static string NotPlanned = "NPLN";
            public static string RoleGroupKey = "RLGP";
            public static string ProjectNumberFormatting = "PNFU";
        }

        public enum EMailFlag
        {
            CACInvitation,
            Invitation,
            Registration,
            ForgetPassword,
            ResetPassword
        }

        public class HierarchyLevel
        {
            public static string HeadQuarters = "HQ";
            public static string MajorSubCommand = "MSC";
            public static string Installation = "INST";
        }

        public class ApprovalStatus
        {
            public static string PendingSubmission = "PRCR";
            public static string SubmittedForInstallationAdminApproval = "SIAA";
            public static string InstallationAdminApproved = "IAAP";
            public static string InstallationAdminDisapproved = "IADA";
            public static string SubmittedForMSCAdminApproval = "SMAA";
            public static string MSCAdminApproved = "MAAR";
            public static string MSCAdminDisapproved = "MADA";
            public static string SubmittedForHQApproval = "SHAP";
            public static string FundingEligible = "FELI";
            public static string FundingIneligible = "FINE";
        }

        public class SourceofProject
        {
            public static string Conversion = "CONV";
            public static string STEP = "STEP";
        }

        public class Types
        {
            public static string Manual = "MANU";
            public static string Approval = "APPR";
        }

        public class ApprovalActions
        {
            public static string SubmitForApproval = "SUBT";
            public static string Approve = "APPR";
            public static string Disapprove = "DAPP";
        }

        public class RoleAction
        {
            public static string Mvc = "MVC";
            public static string Menu = "MENU";
            public static string Ui = "UI";
        }

        public class RoleKey
        {
            public static string WebAdministrator = "WEBADMN";
            public static string HQAdministrator = "HQADMN";
            public static string HQUser = "HQUSER";
            public static string HQReadOnlyUser = "HQREAD";
            public static string MSCAdministrator = "MSCADMN";
            public static string MSCUser = "MSCUSER";
            public static string MSCReadOnlyUser = "MSCREAD";
            public static string InstallationAdministrator = "INSTADMN";
            public static string InstallationUser = "INSTUSER";
            public static string InstallationReadOnlyUser = "INSTREAD";
        }

        public class DefaultMDEP
        {
            public static string VENQ = "VENQ";
        }

        public class ChangeTypes
        {
            public static string Insert = "INST";
            public static string Update = "UPDT";
            public static string Delete = "DELT";
        }

        public class AuditTableName
        {
            public static string Project = "Project";
            public static string ProjectFunding = "Project_Funding";
            public static string ProjectAnswer = "Project_Answer";
            public static string ProjectDocument = "Project_Document";
            public static string ProjectNote = "Project_Note";
        }

        public class ReportId
        {
            public static string User = "User";
            public static string CatelogSummary = "CatalogSummary";
            public static string CatelogDetails = "CatalogDetail";
            public static string ProjectSummary = "ProjectSummary";
            public static string ProjectDetail = "ProjectDetail";
            public static string FundingSummarybyMediaLawReg = "FSbyMLawReg";
            public static string FundingSummarybyPB28 = "FSbyPB28";
            public static string CatalogUsage = "CatalogUsage";
            public static string RoleAction = "RoleAction";
        }

        public class ApprovalProrcessMailConfigHierarchyLevel
        {
            public static string Current = "CURT";
            public static string FirstLevelParent = "FLPT";
            public static string SecondLevelParent = "SLPT";
        }

        public class PageSharedKey
        {
            public static string ProjectListing = "ProjectListing";
            public static string BudgetExecution = "BudgetExecution";
            public static string CataLogListing = "CataLogListing";
            public static string AddEditProject = "AddEditProject";
        }

        public class Readonly
        {
            public static string[] ReadOnly =
                {
                    RoleKey.HQReadOnlyUser,
                    RoleKey.MSCReadOnlyUser,
                    RoleKey.InstallationReadOnlyUser
                };
        }

        public class ActionProperty
        {
            public static string MyApproval = "tabApprovalProjects";
        }

        public class ActionTypeKey
        {
            public static string UITypeKey = "UI";

        }

        public class ControllerProperty
        {
            public static string DashBoard = "DashBoard";
        }

        public class FundingsStatus
        {
            public static string Unfunded = "UNFU";
            public static string Funded = "FUND";
            public static string Obligated = "OBLI";
        }

        public class CatalogStatus
        {
            public static string Active = "ACTV";
            public static string InActive = "IACT";
        }

        public class UserAuditActions
        {
            public static string Login = "LOGI";
            public static string ChangeRole = "CHRO";
            public static string Impersonation = "IMPE";
            public static string GobacktoOriginalUser = "GOBA";
            public static string Logout = "LOGT";
        }
    }
}





