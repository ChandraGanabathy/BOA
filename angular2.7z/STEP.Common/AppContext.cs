﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using STEP.Models;
using STEP.Models.UIModel;

namespace STEP.Common
{
    public class AppContext
    {
        private const string currentUserTheme = "currentUserTheme";
        private const string applicationVersion = "applicationVersion";
        private const string currentUser = "currentUser";
        private const string currentRole = "currentRole";
        private const string catalogSearchFilter = "catalogSearchFilter";
        private const string _PAFGSearchFilter = "PAFGSearchFilter";
        private const string prioritizationSearchFilter = "prioritizationSearchFilter";
        private const string userSearchFilter = "userSearchFilter";
        private const string projectSearchFilter = "projectSearchFilter";
        private const string fileManagerSearchFilter = "fileManagerSearchFilter";
        private const string currentUserPageSize = "currentUserPageSize";
        private const string CurrentRole = "currentRole";
        private const string currentUserRoleHierarchyData = "currentUserRoleHierarchyData";
        private const string currentFiscalYear = "currentFiscalYear";
        private static string sessionUserEmail = "sessionUserEmail";

        private const string fiscalYears = "fiscalYears";

        private const string budgetExecutionSearchFilter = "budgetExecutionSearchFilter";

        private const string pillars = "pillars";
        private const string lawRegs = "lawRegs";
        private const string programAreas = "programAreas";
        private const string pb28Title = "pb28Title";
        private const string pb28Catagory = "pb28Catagory";

        private const string pagesCountToShow = "pagesCountToShow";
        private const string sessionAction = "sessionRoles";
        private const string projectOwnerFilter = "projectOwnerFilter";
        private const string isTopRecordsPermitted = "isTopRecordsPermitted";
        private const string topNRecords = "topNRecords";
        private const string hasAgencyIsAMC = "hasAgencyIsAMC";

        private const string impersonatingUser = "impersonatingUser";
        private const string impersonatingUserRole = "impersonatingUserRole";
        private const string impersonatingUserTheme = "impersonatingUserTheme";
        private const string impersonatingUserProperties = "impersonatingUserProperties";

        public static HttpSessionState Session
        {
            get { return HttpContext.Current.Session; }
        }

        public static string CurrentUserTheme
        {
            get
            {
                string userTheme = null;
                if (Session[currentUserTheme] != null)
                {
                    userTheme = (string)Session[currentUserTheme];
                }
                return userTheme;
            }
            set
            {
                Session[currentUserTheme] = value;
            }
        }

        public static int? CurrentUserPageSize
        {
            get
            {
                int? top = null;
                if (Session[currentUserPageSize] != null)
                {
                    top = Convert.ToInt32(Session[currentUserPageSize]);
                }
                return top;
            }
            set { Session[currentUserPageSize] = value; }
        }

        public static Fiscal_Year CurrentFiscalYear
        {
            get
            {
                var objFiscalYear = new Fiscal_Year();
                if (Session[currentFiscalYear] != null)
                {
                    objFiscalYear = (Fiscal_Year)Session[currentFiscalYear];
                }
                return objFiscalYear;
            }
            set { Session[currentFiscalYear] = value; }
        }

        public static bool IsTopRecordsPermitted
        {
            get { return Convert.ToBoolean(Session[isTopRecordsPermitted]); }
            set { Session[isTopRecordsPermitted] = value; }
        }

        public static int? TopNRecords
        {
            get
            {
                int? top = null;
                if (Session[topNRecords] != null)
                {
                    top = Convert.ToInt32(Session[topNRecords]);
                }
                return top;
            }
            set { Session[topNRecords] = value; }
        }

        public static List<Fiscal_Year> FiscalYears
        {
            get
            {
                List<Fiscal_Year> lstFiscalYears = null;
                if (Session[fiscalYears] != null)
                {
                    lstFiscalYears = (List<Fiscal_Year>)Session[fiscalYears];
                }
                return lstFiscalYears;
            }
            set { Session[fiscalYears] = value; }
        }

        public static string ApplicationVersion
        {
            get
            {
                string version = null;
                if (Session[applicationVersion] != null)
                {
                    version = (string)Session[applicationVersion];
                }
                return version;
            }
            set { Session[applicationVersion] = value; }
        }

        public static User CurrentUser
        {
            get
            {
                var objUser = new User();
                if (Session[currentUser] != null)
                {
                    objUser = (User)Session[currentUser];
                }
                return objUser;
            }
            set { Session[currentUser] = value; }
        }

        public static User_Role CurrentUserRole
        {
            get
            {
                var objRole = new User_Role();
                if (Session[CurrentRole] != null)
                {
                    objRole = (User_Role)Session[CurrentRole];
                }
                return objRole;
            }
            set { Session[CurrentRole] = value; }
        }

        public static IEnumerable<Hierarchy_Data> CurrentUserRoleHierarchyData
        {
            get
            {
                IEnumerable<Hierarchy_Data> objHierarchyData = null;
                if (Session[currentUserRoleHierarchyData] != null)
                {
                    objHierarchyData = (IEnumerable<Hierarchy_Data>)Session[currentUserRoleHierarchyData];
                }
                return objHierarchyData;
            }
            set { Session[currentUserRoleHierarchyData] = value; }
        }

        public static string CurrentUserEmail
        {
            get
            {
                if (Session[sessionUserEmail] != null)
                {
                    return Session[sessionUserEmail].ToString();
                }
                return string.Empty;
            }
            set
            {
                Session[sessionUserEmail] = value;
            }
        }

        public static CatalogSearchFilter CatalogSearchFilter
        {
            get
            {
                var objCatalogSearchFilter = new CatalogSearchFilter();
                if (Session[catalogSearchFilter] != null)
                {
                    objCatalogSearchFilter = (CatalogSearchFilter)Session[catalogSearchFilter];
                }
                return objCatalogSearchFilter;
            }
            set { Session[catalogSearchFilter] = value; }
        }

        public static PAFGSearchFilter PAFGSearchFilter
        {
            get
            {
                var objPAFGSearchFilter = new PAFGSearchFilter();
                if (Session[_PAFGSearchFilter] != null)
                {
                    objPAFGSearchFilter = (PAFGSearchFilter)Session[_PAFGSearchFilter];
                }
                return objPAFGSearchFilter;
            }
            set { Session[_PAFGSearchFilter] = value; }
        }

        public static PrioritizationSearchFilter PrioritizationSearchFilter
        {
            get
            {
                var objPrioritizationSearchFilter = new PrioritizationSearchFilter();
                if (Session[prioritizationSearchFilter] != null)
                {
                    objPrioritizationSearchFilter = (PrioritizationSearchFilter)Session[prioritizationSearchFilter];
                }
                return objPrioritizationSearchFilter;
            }
            set { Session[prioritizationSearchFilter] = value; }
        }

        public static UserSearchFilter UserSearchFilter
        {
            get
            {
                var objUserSearchFilter = new UserSearchFilter();
                if (Session[userSearchFilter] != null)
                {
                    objUserSearchFilter = (UserSearchFilter)Session[userSearchFilter];
                }
                return objUserSearchFilter;
            }
            set { Session[userSearchFilter] = value; }
        }

        public static ProjectSearchFilter ProjectSearchFilter
        {
            get
            {
                var objProjectSearchFilter = new ProjectSearchFilter();
                if (Session[projectSearchFilter] != null)
                {
                    objProjectSearchFilter = (ProjectSearchFilter)Session[projectSearchFilter];
                }
                return objProjectSearchFilter;
            }
            set { Session[projectSearchFilter] = value; }
        }

        public static ProjectSearchFilter BudgetExecutionSearchFilter
        {
            get
            {
                var objBudgetExecutionSearchFilter = new ProjectSearchFilter();
                if (Session[budgetExecutionSearchFilter] != null)
                {
                    objBudgetExecutionSearchFilter = (ProjectSearchFilter)Session[budgetExecutionSearchFilter];
                }
                return objBudgetExecutionSearchFilter;
            }
            set { Session[budgetExecutionSearchFilter] = value; }
        }

        public static FileManagerSearchFilter FileManagerSearchFilter
        {
            get
            {
                var objFileManagerSearchFilter = new FileManagerSearchFilter();
                if (Session[fileManagerSearchFilter] != null)
                {
                    objFileManagerSearchFilter = (FileManagerSearchFilter)Session[fileManagerSearchFilter];
                }
                return objFileManagerSearchFilter;
            }
            set { Session[fileManagerSearchFilter] = value; }
        }

        public static List<Pillar> CurrentUserRolePillars
        {
            get
            {
                List<Pillar> lstPillars = null;
                if (Session[pillars] != null)
                {
                    lstPillars = (List<Pillar>)Session[pillars];
                }
                return lstPillars;
            }
            set { Session[pillars] = value; }
        }

        public static List<LawReg> CurrentUserRoleLawRegs
        {
            get
            {
                List<LawReg> lstLawRegs = null;
                if (Session[lawRegs] != null)
                {
                    lstLawRegs = (List<LawReg>)Session[lawRegs];
                }
                return lstLawRegs;
            }
            set { Session[lawRegs] = value; }
        }

        public static List<ProgramArea> CurrentUserRoleProgramAreas
        {
            get
            {
                List<ProgramArea> lstProgramAreas = null;
                if (Session[programAreas] != null)
                {
                    lstProgramAreas = (List<ProgramArea>)Session[programAreas];
                }
                return lstProgramAreas;
            }
            set { Session[programAreas] = value; }
        }

        public static List<PB28Title> CurrentPB28TitleByPillar
        {
            get
            {
                List<PB28Title> lstPB28Title = null;
                if (Session[pb28Title] != null)
                {
                    lstPB28Title = (List<PB28Title>)Session[pb28Title];
                }
                return lstPB28Title;
            }
            set { Session[pb28Title] = value; }
        }

        public static List<PB28Category> CurrentPB28CatagoryByPillarandTitle
        {
            get
            {
                List<PB28Category> lstPB28Catagory = null;
                if (Session[pb28Catagory] != null)
                {
                    lstPB28Catagory = (List<PB28Category>)Session[pb28Catagory];
                }
                return lstPB28Catagory;
            }
            set { Session[pb28Catagory] = value; }
        }

        public static int? PagesCountToShow
        {
            get
            {
                int? top = null;
                if (Session[pagesCountToShow] != null)
                {
                    top = Convert.ToInt32(Session[pagesCountToShow]);
                }
                return top;
            }
            set { Session[pagesCountToShow] = value; }
        }

        public static List<STEP.Models.Action> SessionActions
        {
            get
            {
                var objAction = new List<STEP.Models.Action>();
                if (Session[sessionAction] != null)
                {
                    objAction = (List<STEP.Models.Action>)Session[sessionAction];
                }
                return objAction;
            }
            set
            {
                Session[sessionAction] = value;
            }
        }

        public static ProjectOwnerSearchFilter ProjectOwnerSearchFilter
        {
            get
            {
                var objProjectOwnerFilter = new ProjectOwnerSearchFilter();
                if (Session[projectOwnerFilter] != null)
                {
                    objProjectOwnerFilter = (ProjectOwnerSearchFilter)Session[projectOwnerFilter];
                }
                return objProjectOwnerFilter;
            }
            set { Session[projectOwnerFilter] = value; }
        }

        public static User ImpersonatingtUser
        {
            get
            {
                var objUser = new User();
                if (Session[impersonatingUser] != null)
                {
                    objUser = (User)Session[impersonatingUser];
                }
                return objUser;
            }
            set
            {
                Session[impersonatingUser] = value;
            }
        }

        public static User_Role ImpersonatingUserRole
        {
            get
            {
                var objImpersonatingRole = new User_Role();
                if (Session[impersonatingUserRole] != null)
                {
                    objImpersonatingRole = (User_Role)Session[impersonatingUserRole];
                }
                return objImpersonatingRole;
            }
            set
            {
                Session[impersonatingUserRole] = value;
            }
        }

        public static bool HasAgencyIsAMC
        {
            get { return Convert.ToBoolean(Session[hasAgencyIsAMC]); }
            set { Session[hasAgencyIsAMC] = value; }
        }
    }
}
