﻿using System;
using System.Configuration;

namespace STEP.Common
{
    public class AppConfig
    {

        //Admin
        public static readonly string EmailServer = ConfigurationManager.AppSettings["EmailServer"] ?? string.Empty;

        public static readonly int EmailServerPort =
            Convert.ToInt32(ConfigurationManager.AppSettings["EmailServerPort"] ?? string.Empty);

        public static readonly string SMTPUseCredentials = ConfigurationManager.AppSettings["SMTPUseCredentials"] ??
                                                           string.Empty;

        public static readonly string SMTPUserName = ConfigurationManager.AppSettings["SMTPUserName"] ?? string.Empty;
        public static readonly string SMTPPassword = ConfigurationManager.AppSettings["SMTPPassword"] ?? string.Empty;

        //Email Values
        public static readonly string SendEmail = string.IsNullOrEmpty(ConfigurationManager.AppSettings["SendEmail"])
                                                      ? string.Empty
                                                      : ConfigurationManager.AppSettings["SendEmail"];

        public static readonly string FromEmail = string.IsNullOrEmpty(ConfigurationManager.AppSettings["FromEmail"])
                                                     ? string.Empty
                                                     : ConfigurationManager.AppSettings["FromEmail"];

        public static readonly string AdminEmail = string.IsNullOrEmpty(ConfigurationManager.AppSettings["AdminEmail"])
                                                     ? string.Empty
                                                     : ConfigurationManager.AppSettings["AdminEmail"];

        public static readonly string IgnoreText = ConfigurationManager.AppSettings["IgnoreText"] ?? string.Empty;

        public static readonly string UserInvitationSubject =
            string.IsNullOrEmpty(ConfigurationManager.AppSettings["UserInvitationSubject"])
                ? string.Empty
                : ConfigurationManager.AppSettings["UserInvitationSubject"];

        public static readonly string InvitationMailContentPath =
            ConfigurationManager.AppSettings["InvitationMailContentPath"] ?? string.Empty;

        public static readonly string InvitationMailContentPathWithOutCACLogin =
            string.IsNullOrEmpty(ConfigurationManager.AppSettings["InvitationMailContentPathWithOutCACLogin"])
                ? string.Empty
                : ConfigurationManager.AppSettings["InvitationMailContentPathWithOutCACLogin"];

        public static readonly string ApplicationURL =
            string.IsNullOrEmpty(ConfigurationManager.AppSettings["ApplicationURL"])
                ? string.Empty
                : ConfigurationManager.AppSettings["ApplicationURL"];

        public static readonly string WebcassURL =
            string.IsNullOrEmpty(ConfigurationManager.AppSettings["WebcassURL"])
                ? string.Empty
                : ConfigurationManager.AppSettings["WebcassURL"];

        public static readonly string HelpDeskEmail =
            string.IsNullOrEmpty(ConfigurationManager.AppSettings["HelpDeskEmail"])
                ? string.Empty
                : ConfigurationManager.AppSettings["HelpDeskEmail"];

        public static readonly string HelpDeskPhone =
            string.IsNullOrEmpty(ConfigurationManager.AppSettings["HelpDeskPhone"])
                ? string.Empty
                : ConfigurationManager.AppSettings["HelpDeskPhone"];

        public static readonly int MassEMailMaxRecipientsPerMail =
            Convert.ToInt32(ConfigurationManager.AppSettings["MassEMailMaxRecipientsPerMail"] ?? string.Empty);

        //System Constant Default
        public static readonly string DefaultTheme =
            string.IsNullOrEmpty(ConfigurationManager.AppSettings["DefaultTheme"])
                ? string.Empty
                : ConfigurationManager.AppSettings["DefaultTheme"];

        public static readonly int DefaultPageSize =
            Convert.ToInt32(ConfigurationManager.AppSettings["DefaultPageSize"] ?? string.Empty);

        public static readonly string Agency = ConfigurationManager.AppSettings["Agency"] ?? string.Empty;

        public static readonly string EnableCAC = string.IsNullOrEmpty(ConfigurationManager.AppSettings["EnableCAC"])
                                                      ? string.Empty
                                                      : ConfigurationManager.AppSettings["EnableCAC"];

        public static readonly string AgencyID = string.IsNullOrEmpty(ConfigurationManager.AppSettings["AgencyID"])
                                                     ? string.Empty
                                                     : ConfigurationManager.AppSettings["AgencyID"];

        // File Management Directories
        public static readonly string FileURL = string.IsNullOrEmpty(ConfigurationManager.AppSettings["FileURL"])
                                                    ? string.Empty
                                                    : ConfigurationManager.AppSettings["FileURL"];

        public static readonly string FileManagerUploadLocation =
            ConfigurationManager.AppSettings["FileManagerUploadLocation"] ?? string.Empty;

        public static readonly string ProjectDocumentsUploadUrl =
            string.IsNullOrEmpty(ConfigurationManager.AppSettings["ProjectDocumentsUploadUrl"])
                ? string.Empty
                : ConfigurationManager.AppSettings["ProjectDocumentsUploadUrl"];
    }
}
