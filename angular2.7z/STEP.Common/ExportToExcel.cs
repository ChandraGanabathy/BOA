﻿using System;
using System.Data;
using System.Text;

namespace STEP.Common
{
    public class ExportToExcel
    {
        public ExportToExcel()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        //DTID_DAL dataAccess = new DTID_DAL();

        public string GetExportString(DataTable dtReport, string FileName)
        {
            StringBuilder sb = new StringBuilder();

            int iTblColumnCount = dtReport.Columns.Count;
            sb.Append(RenderWorksheetStartTag(FileName));
            sb.Append(RenderReportHeader(FileName, iTblColumnCount));
            sb.Append(RenderTableHeader(dtReport));
            sb.Append(RenderTableContent(dtReport));
            sb.Append(RenderEmptyRow(iTblColumnCount));
            sb.Append(RenderWorkSheetEndTag());

            return Convert.ToString(sb);
        }

        public string RenderWorksheetStartTag(string strSheetName)
        {
            StringBuilder sbHeader = new StringBuilder();
            sbHeader.Append("<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" ");
            sbHeader.Append("xmlns=\"http://www.w3.org/TR/REC-html40\"><head><meta http-equiv=Content-Type content=\"text/html; charset=windows-1252\">");
            sbHeader.Append("<meta name=ProgId content=Excel.Sheet><meta name=Generator content=\"Microsoft Excel 9\">");
            sbHeader.Append("<!--[if gte mso 9]>");

            sbHeader.Append("<xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>" + strSheetName + "</x:Name><x:WorksheetOptions>");
            sbHeader.Append("<x:Selected/><x:ProtectContents>False</x:ProtectContents><x:ProtectObjects>False</x:ProtectObjects>");
            sbHeader.Append("<x:ProtectScenarios>False</x:ProtectScenarios></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets>");
            sbHeader.Append("<x:ProtectStructure>False</x:ProtectStructure><x:ProtectWindows>False</x:ProtectWindows></x:ExcelWorkbook></xml>");
            sbHeader.Append("<![endif]--></head><body>");
            return Convert.ToString(sbHeader);
        }

        public string RenderReportHeader(string headerText1, int colCount)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<Table><tr>");
            for (int i = 0; i < colCount / 2; i++)
                sb.Append("<td></td>");
            sb.Append("<td style=\"font-weight:bold;white-space:nowrap;\">");
            sb.Append(headerText1);
            sb.Append("</td>");
            sb.Append("</tr></table>");
            return Convert.ToString(sb);
        }

        public string RenderTableHeader(DataTable dt)
        {
            int columnsCount = dt.Columns.Count;
            StringBuilder sb = new StringBuilder();
            sb.Append("<table><tr><td></td>");
            for (int i = 0; i < columnsCount; i++)
            {
                sb.Append("<td style=\"font-weight:bold\">" + dt.Columns[i].ColumnName + "</td>");
            }
            sb.Append("</tr>");
            return Convert.ToString(sb);
        }

        public string RenderTableContent(System.Data.DataTable dt)
        {
            StringBuilder sb = new StringBuilder();
            for (int x = 0; x < dt.Rows.Count; x++)
            {
                sb.Append("<tr><td></td>");
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    System.Type rowType;
                    rowType = dt.Rows[x][i].GetType();
                    switch (Convert.ToString(rowType))
                    {
                        case "System.String":
                            sb.Append("<td>" + dt.Rows[x][i] + "</td>");
                            break;
                        case "System.Decimal":
                            sb.Append("<td style=\"mso-style-parent:style0; mso-number-format:Fixed;\">" + dt.Rows[x][i] + "</td>");
                            break;
                        case "System.Double":
                            sb.Append("<td style=\"mso-style-parent:style0; mso-number-format:Fixed;\">" + dt.Rows[x][i] + "</td>");
                            break;
                        default:
                            sb.Append("<td>" + dt.Rows[x][i] + "</td>");
                            break;
                    }

                }
                sb.Append("</tr>");
            }
            return Convert.ToString(sb);

        }

        public string RenderEmptyRow(int columnCount)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<tr>");
            for (int x = 0; x < columnCount + 1; x++)
            {
                sb.Append("<td></td>");
            }
            sb.Append("</tr>");
            return Convert.ToString(sb);

        }

        public string RenderWorkSheetEndTag()
        {
            return "</table></body></html>";
        }
    }
}
