﻿using System;
using System.Collections.Generic;
using System.Reflection;
using STEP.Models.UIModel;

namespace STEP.Common
{
    public static class AppExtensions
    {
        public static bool IsNull(this object item)
        {
            return (item == null);
        }

        public static List<AuditLog> CompareEntityForAudit<T>(T object1, T object2, List<string> object3 = null)
        {
            var lstAuditLog = new List<AuditLog>();

            //Get the type of the object
            Type type = typeof(T);

            //return false if any of the object is false
            if (object1 == null || object2 == null)
                return lstAuditLog;

            //Loop through each properties inside class and get values for the property from both the objects and compare
            foreach (PropertyInfo property in type.GetProperties())
            {
                var excludeProprties = new List<string> { "Created_By", "Created_Date", "Modified_By", "Modified_Date" };
                if (object3.IsNull())
                    object3 = new List<String>(excludeProprties);

                if (!object3.Contains(property.Name))
                {
                    var isPropertyVirtual = type.GetProperty(property.Name).GetGetMethod().IsVirtual;
                    if (isPropertyVirtual == false)
                    {
                        var propertyType = property.PropertyType;
                        if (propertyType.IsGenericType &&
                            propertyType.GetGenericTypeDefinition() == typeof(Nullable<>) &&
                            propertyType.GetGenericArguments()[0] == typeof(System.Decimal))
                        {


                            decimal object1Value = 0;
                            decimal object2Value = 0;
                            if (type.GetProperty(property.Name).GetValue(object1, null) != null)
                            {
                                object1Value = Convert.ToDecimal(type.GetProperty(property.Name).GetValue(object1, null));
                                object1Value = Math.Truncate(object1Value);
                            }
                            if (type.GetProperty(property.Name).GetValue(object2, null) != null)
                            {
                                object2Value = Convert.ToDecimal(type.GetProperty(property.Name).GetValue(object2, null));
                                object2Value = Math.Truncate(object2Value);
                            }
                            if (object1Value.Equals(object2Value) == false)
                            {
                                //return lstAuditLog;
                                lstAuditLog.Add(new AuditLog
                                {
                                    ColumnName = property.Name,
                                    OldValue = Convert.ToString(object2Value),
                                    NewValue = Convert.ToString(object1Value),
                                });
                            }
                        }
                        else
                        {
                            string object1Value = string.Empty;
                            string object2Value = string.Empty;
                            if (type.GetProperty(property.Name).GetValue(object1, null) != null)
                                object1Value = type.GetProperty(property.Name).GetValue(object1, null).ToString();
                            if (type.GetProperty(property.Name).GetValue(object2, null) != null)
                                object2Value = type.GetProperty(property.Name).GetValue(object2, null).ToString();
                            if (object1Value.Trim() != object2Value.Trim())
                            {
                                //return lstAuditLog;
                                lstAuditLog.Add(new AuditLog
                                {
                                    ColumnName = property.Name,
                                    OldValue = object2Value.Trim(),
                                    NewValue = object1Value.Trim()
                                });
                            }
                        }
                    }
                }
            }
            return lstAuditLog;
        }

        public static string DataTrim(string data)
        {
            if (string.IsNullOrEmpty(data))
                return data;
            return data.Trim();
        }
    }
}

