﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STEP.Models.UIModel
{
    public class Roles
    {
        public int Role_Id { get; set; }
        public string Role_Key { get; set; }
        public string Role_Name { get; set; }

        [NotMapped]
        public int Action_Id { get; set; }
        [NotMapped]
        public string Action_Name { get; set; }

        [NotMapped]
        public string Action_Description { get; set; }
    }

    public class Actions
    {
        public int Action_Id { get; set; }
        public string Action_Name { get; set; }
        public string Action_Description{ get; set; }
        public string Controller_Name { get; set; }
        public string Type_Description { get; set; }
    }

    //public class RoleActionData
    //{
    //    public int Role_Id { get; set; }
    //    List<int> ActionIds { get; set; }
    //}

    //public class Actions
    //{
    //    public int Action_Id { get; set; }
    //    public string Action_Name { get; set; }
    //    public string Action_Description { get; set; }
    //}
}
