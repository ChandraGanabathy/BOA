﻿using System;

namespace STEP.Models.UIModel
{
   public class UserQueryReport
    {
        public string DTIDNumber { get; set; }
        public string SiteName { get; set; }
        public string EPAId { get; set; }
        public DateTime? EarliestAccumulationStartDate { get; set; }
        public string WasteCodeDescription { get; set; }
        public string ContactName { get; set; }
        public string ContactTelephone { get; set; }
        public string InventoryItemName { get; set; }
        public int? quantity { get; set; }
        public Int32? DisposalWeight { get; set; }
        public string CLINOrHIN { get; set; }
        public decimal? DisposalUnitPrice { get; set; }
        public decimal? TotalDisposalCost { get; set; }
        public string ContainerDescriptionType { get; set; }
        public string NIIN { get; set; }
        public string Description { get; set; }
        public DateTime? EnteredCurrentStatus { get; set; }
        public string PickupManifestNumber { get; set; }        
        public string WPSNo { get; set; }
        public string MSDSNumber { get; set; }
        public string ProperShippingName { get; set; }
        public string ProcessName { get; set; }
        public string city { get; set; }
        public string ShipToName { get; set; }
        public string State { get; set; }
        public string DeliveryOrderNumber { get; set; }
        public string DeliveryOrderLineItemNumber { get; set; }

        public string SupplyConditionCode { get; set; }
        public string ItemDemilCode { get; set; }
        public string FSC { get; set; }
        public string EPAHazardousWasteCode { get; set; }
        public string StateWasteCode { get; set; }

        public Int64 RowNumber { get; set; }
        public int No_of_Records { get; set; }
    }
}
