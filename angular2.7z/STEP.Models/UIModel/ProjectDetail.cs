﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using STEP.Models;

namespace STEP.Models.UIModel
{
    public class ProjectDetail
    {
        public int? Id { get; set; }
        public int? CatalogId { get; set; }
        public string ProjectNumber { get; set; }
        public string ProjectName { get; set; }
        public string Property { get; set; }
        public string CatalogNumber { get; set; }
        public string CatalogName { get; set; }
        public string ResourceSponsor { get; set; }
        public string Class { get; set; }
        public string CatalogStatus { get; set; }
        public string Pillar { get; set; }
        public string LawReg { get; set; }
        public string ProgramArea { get; set; }
        public string Pb28Title { get; set; }
        public string Pb28Category { get; set; }
        public string Pb28SubCategory { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public int FiscalYear { get; set; }
        public decimal InitialRequired { get; set; }
        public decimal CurrentRequired { get; set; }
        public string ReviewStatus { get; set; }
        public int LocalPriority { get; set; }
        public decimal Planned { get; set; }
        public decimal Funded { get; set; }
        public decimal Obligated { get; set; }
        public bool IsRecurring { get; set; }
        public string ProjectType { get; set; }
        public string Amsco { get; set; }
        public string Mdep { get; set; }
        public string ImpactMission { get; set; }
        public string MissionCode { get; set; }
        public string ProgressCode { get; set; }
        public string EnvorimentalImpact { get; set; }
        public string ProjectOwener { get; set; }
        public string ROI { get; set; }
        public string ProjectDescription { get; set; }
        public List<Project_Funding> Project_Fundings { get; set; }
        public List<ProjectAnswers> Project_Answers { get; set; } 
    }

    public class ProjectAnswers
    {
        public int Id { get; set; }
        public int 	FiscalYear{ get; set; }
        public string  Question{ get; set; }
        public string Answer{ get; set; }

    }
    public class ProjectFunding
    {
        public int Id { get; set; }
        public int FiscalYear{ get; set; }
        public string MDEPCode { get; set; }
        public decimal Validated { get; set; }
        public decimal Programmed { get; set; }
        public string	ReviewStatus{ get; set; }
        public int	LocalPriority{ get; set; }
        public int MSCPriority { get; set; }
        public int HQPriority { get; set; }
        public decimal Planned { get; set; }
        public decimal Funded { get; set; }
        public decimal Obligated { get; set; }
        public string IsUFR { get; set; }
        public string Agency { get; set; }
        public string FundingStatus { get; set; }
    }

    public class ProjectOwnerDetails
    {
        public int Id { get; set; }
        public string Project_Name { get; set; }
        public string Project_Number { get; set; }
        public string Pillar { get; set; }
        public string Property { get; set; }
        public string LawReg { get; set; }
        public string ProgramArea { get; set; }
        public int HierarchyDataId { get; set; }
        public string SelectedUser { get; set; }
        public string ExistingOwner { get; set; }
        public int ExistingOwnerId { get; set; }
        public string ImpactMission { get; set; }
        public string MissionCode { get; set; }
        
        public IEnumerable<OwnerList> Users { get; set; }

        [NotMapped]
        public string Message { get; set; }
    }

    public class OwnerList
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
