﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STEP.Models.UIModel
{
    public class ReportParameters
    {
        public string ReportType { get; set; }
        public List<int> SelectedRoles { get; set; }
        public bool IsRoleAllSelected { get; set; }
        public List<int> SelectedProperty { get; set; }
        public bool IsPropertyAllSelected { get; set; }
        public List<string> SelectedStatus { get; set; }
        public bool IsSatusAllSelected { get; set; }
        public List<string> SelectedPillar { get; set; }
        public bool IsPillarAllSelected { get; set; }
        public List<LawReg> SelectedLawReg { get; set; }
        public bool IsLawRegAllSelected { get; set; }
        public List<string> SelectedProgramArea { get; set; }
        public bool IsProgramAreaAllSelected { get; set; }

        public List<string> SelectedResourceSponcer { get; set; }
        public bool IsAllResourceSponcer { get; set; }
        public List<string> SelectedApprovalStatus { get; set; }
        public bool IsAllApprovalStatus { get; set; }
        public List<int> SelectedFiscalYears { get; set; }
        public bool IsAllFiscalYears { get; set; }
        public List<string> SelectedClass { get; set; }
        public bool IsAllClass { get; set; }
        public List<string> SelectedFundingStatus { get; set; }
        public bool IsAllFundingStatus { get; set; }
        public List<string> SelectedPB28Title { get; set; }
        public bool IsAllPB28Title { get; set; }
        public List<string> selectedPB28Category { get; set; }
        public bool IsAllPB28Category { get; set; }
        public List<string> SelectedImpacttoMission { get; set; }
        public bool IsAllImpacttoMission { get; set; }

    }
}
