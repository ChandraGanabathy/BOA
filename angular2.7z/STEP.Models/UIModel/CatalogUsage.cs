﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STEP.Models.UIModel
{
    public class CatalogUsage
    {
        public int Id { get; set; }
        public string Property { get; set; }
        public int ProjectCount { get; set; }
        public string CatalogNumber { get; set; }
        public string CatalogName { get; set; }
        public string Pillar { get; set; }
        public string LawReg { get; set; }
        public string ProgramArea { get; set; }
        public decimal Validated { get; set; }
        public decimal Programmed { get; set; }
        public decimal Planned { get; set; }
        public decimal Funded { get; set; }
        public decimal Obligated { get; set; }
        public string ApprovalStatus { get; set; }
    }
    public class FundingSummaryByPB28
    {
        public int Id { get; set; }
        public string Property { get; set; }
        public string Pillar { get; set; }
        public string LawReg { get; set; }
        public int FiscalYear { get; set; }
        public string Pb28Title { get; set; }
        public string Pb28Category { get; set; }
        public string ProgramArea { get; set; }
        public decimal Validated { get; set; }
        public decimal Programmed { get; set; }
        public decimal Planned { get; set; }
        public decimal Funded { get; set; }
        public decimal Obligated { get; set; }
    }
    public class FundingSummaryByMediaLawReg
    {
        public int Id { get; set; }
        public string Property { get; set; }
        public string Pillar { get; set; }
        public string LawReg { get; set; }
        public string ProgramArea { get; set; }
        public int FiscalYear { get; set; }
        public decimal Validated { get; set; }
        public decimal Programmed { get; set; }
        public decimal Planned { get; set; }
        public decimal Funded { get; set; }
        public decimal Obligated { get; set; }
    }
}
