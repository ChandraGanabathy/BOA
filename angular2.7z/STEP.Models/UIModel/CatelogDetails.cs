﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STEP.Models.UIModel
{
    public class CatelogDetails
    {
        public int? Id { get; set; }
        public string CatalogNumber { get; set; }
        public string CatalogName { get; set; }
        public string CatalogNarrative { get; set; }
        public string Pillar { get; set; }
        public string LawReg { get; set; }
        public string ProgramArea { get; set; }
        public string Pb28Title { get; set; }
        public string Pb28Category { get; set; }
        public string Pb28SubCategory { get; set; }
        public string Class { get; set; }
        public string CatelogStatus { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public string IsRequired { get; set; }
        public int? StartFY { get; set; }
        public int? EndFY { get; set; }
        public string ASMCOCode { get; set; }
        public string AMSCOCodeDescription { get; set; }
        public int? AMSCOStartFY { get; set; }
        public int? AMSCOEndFY { get; set; }
        public string CFYAMSCOCode { get; set; }
        
    }
    public class CatelogQuestions
    {
        public int Id { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public string IsRequired { get; set; }
        public int? StartFY { get; set; }
        public int? EndFY { get; set; }
    }

    public class CatelogAMSCO
    {
        public int Id { get; set; }
        public string AMSCOCode { get; set; }
        public string AMSCODescription { get; set; }
        public int? StartFY { get; set; }
        public int? EndFY { get; set; }
    }
}
