using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public class DrilldownChartData
    {
        public string ParentId { get; set; }
        public string ParentKey { get; set; }
        public Nullable<decimal> ParentValue { get; set; }

        public List<ChildLevel1> ChildLevel1 { get; set; }
    }

    public class ChildLevel1
    {
        public string ChildLevel1Id { get; set; }
        public string ChildLevel1Key { get; set; }
        public Nullable<decimal> ChildLevel1Value { get; set; }

        public List<ChildLevel2> ChildLevel2 { get; set; }
    }

    public class ChildLevel2
    {
        public string ChildLevel2Id { get; set; }
        public string ChildLevel2Key { get; set; }
        public Nullable<decimal> ChildLevel2Value { get; set; }
    }
}
