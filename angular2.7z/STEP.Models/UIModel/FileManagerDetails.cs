﻿namespace STEP.Models
{
    public class FileManagerDetails
    {
        public string IconUrl { get; set; }
        public string FullName { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string LastModified { get; set; }
        public string FileSize { get; set; }
        public string DisplayName { get; set; }
    }
}
