using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public class ChartData
    {
        public string Key { get; set; }
        public Nullable<decimal> Value { get; set; }
    }
}
