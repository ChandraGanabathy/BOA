using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public class ProjectDetails
    {
        public int Id { get; set; }
        public string Project_Name { get; set; }
        public string Project_Number { get; set; }
        public string Pillar { get; set; }
        public string MLR { get; set; }
        public string Program_Area { get; set; }
        public string Status { get; set; }
    }
}
