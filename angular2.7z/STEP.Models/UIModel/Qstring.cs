﻿using System.Collections.Generic;

namespace STEP.Models.UIModel
{
    public class Qstring
    {
        public string Id { get; set; }
        public string ReportName { get; set; }
        public string IsUserInfo { get; set; }
        public string ChartName { get; set; }
        public string Status { get; set; }
        public string ControllerName { get; set; }
        public string ActionName { get; set; }
        public string CatalogId { get; set; }
        public int ProjectId { get; set; }
        public int FiscalId { get; set; }
        public string UserId { get; set; } 
    }

    public class Pillar
    {
        public int PillarId { get; set; }
        public string PillarKey { get; set; }
        public string PillarDescription { get; set; }
    }

    public class LawReg : Pillar
    {
        public int LawRegId { get; set; }
        public string LawRegKey { get; set; }
        public string LawRegDescription { get; set; }
        public string CodeValueKey { get; set; }
    }

    public class ProgramArea : LawReg
    {
        public int ProgramAreaId { get; set; }
        public string ProgramAreaKey { get; set; }
        public string ProgramAreaDescription { get; set; }
    }

    public class PB28Title : Pillar
    {
        public int TitleId { get; set; }
        public string TitleKey { get; set; }
        public string TitleDescription { get; set; }
    }

    public class PB28Category : PB28Title
    {
        public int PB28CategoryId { get; set; }
        public string PB28CategoryKey { get; set; }
        public string PB28CategoryDescription { get; set; }
        public string CodeValueKey { get; set; }
    }

    public class PB28CategoryTitle : Pillar
    {
        public int PB28TitleId { get; set; }
        public string PB28TitleKey { get; set; }
        public string PB28TitleDescription { get; set; }
        public int PB28CategoryId { get; set; }
        public string PB28CategoryKey { get; set; }
        public string PB28CategoryDescription { get; set; }
    }
    public class AuditLog
    {
        public string ColumnName { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
    }
}
