﻿namespace STEP.Models.UIModel
{
   public class RoleActionReport
    {
        public string Action { get; set; }
        public string Controller { get; set; }
        public string ActionType { get; set; }
        public bool IsWEBADMN { get; set; }
        public bool IsHQADMN { get; set; }
        public bool IsHQUSER { get; set; }
        public bool IsHQREAD { get; set; }
        public bool IsMSCADMN { get; set; }
        public bool IsMSCUSER { get; set; }
        public bool IsMSCREAD { get; set; }
        public bool IsINSTADMN { get; set; }
        public bool IsINSTUSER { get; set; }
        public bool IsINSTREAD { get; set; }
    }
}
