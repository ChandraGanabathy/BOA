﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Data.Entity.Validation;
using System.Net;

namespace STEP.Models
{
    [DebuggerDisplay("Status: {Status}")]
    public class OperationStatus
    {
        public OperationStatus()
        {
            EntityValidationError = new List<String>() { };
        }

        public bool Status { get; set; }
        public int RecordsAffected { get; set; }
        public string Message { get; set; }
        public List<string> EntityValidationError { get; set; }
        public Object OperationID { get; set; }
        public string ExceptionMessage { get; set; }
        public string ExceptionStackTrace { get; set; }
        public string ExceptionInnerMessage { get; set; }
        public string ExceptionInnerStackTrace { get; set; }
        public Exception ExceptionObject { get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public static OperationStatus CreateFromException(string message, Exception ex)
        {
            OperationStatus opStatus = new OperationStatus
            {
                Status = false,
                Message = message,
                OperationID = null,
                ExceptionObject = ex
            };

            if (ex != null)
            {
                opStatus.ExceptionMessage = ex.Message;
                opStatus.ExceptionStackTrace = ex.StackTrace;
                opStatus.ExceptionInnerMessage = (ex.InnerException == null) ? null : ex.InnerException.Message;
                opStatus.ExceptionInnerStackTrace = (ex.InnerException == null) ? null : ex.InnerException.StackTrace;
            }
            return opStatus;
        }
        public static OperationStatus CreateFromException(string message, DbEntityValidationException dbEx)
        {
            OperationStatus opStatus = new OperationStatus
            {
                Status = false,
                Message = message,
                OperationID = null,
                ExceptionObject = dbEx
            };

            if (dbEx != null)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        var errorMsg= string.Format("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                        opStatus.EntityValidationError.Add(errorMsg);
                    }
                }
            }
            return opStatus;
        }
    }

      
}
