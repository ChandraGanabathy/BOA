﻿using System.Collections.Generic;

namespace STEP.Models
{
    public class CatalogSearchFilter
    {
        public string CatalogName { get; set; }
        public string CatalogNumber { get; set; }
        public string Pillar { get; set; }
        public string LawReg { get; set; }
        public string ProgramArea { get; set; }       
    }


    public class UserSearchFilter
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Status { get; set; }
        public int? RoleId { get; set; }
    }

    public class FileManagerSearchFilter
    {
        public string FileName { get; set; }
        public string FullName { get; set; }
        public string LastModified { get; set; }
    }

    public class ProjectSearchFilter
    {
        public string ProjectNumber { get; set; }
        public string ProjectName { get; set; }

        public string PillarKey { get; set; }
        public string LawRegKey { get; set; }
        public string ProgramAreaKey { get; set; }

        public string PB28TitleKey { get; set; }
        public string PB28CategoryKey { get; set; }

        public int? HierarchyDataId { get; set; }
        public string FundingApprovalStatusKey { get; set; }
        public int FiscalYear { get; set; }

        public string FundingStatusKey { get; set; }

        public int FY { get; set; }
        public int Approval_Status_Id { get; set; }
        public string Approval_Status_Key { get; set; }
        public string ImpactMission { get; set; }

        public string Class { get; set; } 
    }

    public class KpiFilter
    {
        public int FY { get; set; }
        public List<int> RoleHierarchyData { get; set; }
        public List<string> ProjectStatusesData { get; set; }
        public string AmountType { get; set; }
        public string PillarKey { get; set; }
        public string LawRegKey { get; set; }
        public string ProgramAreaKey { get; set; }
    }

    public class PAFGSearchFilter
    {
        public int FiscalYear { get; set; }
        public string Property { get; set; }
    }

    public class PrioritizationSearchFilter
    {
        public int FiscalYear { get; set; }
        public int? Property { get; set; }
        public string PillarKey { get; set; }
        public string Approval_Status { get; set; }
        public string LawReg { get; set; }
        public string ProgramArea { get; set; }      
    }

    public class ProjectOwnerSearchFilter
    {
        public string ProjectNumber { get; set; }
        public string ProjectName { get; set; }
        public string PillarKey { get; set; }
        public string LawRegKey { get; set; }
        public string ProgramAreaKey { get; set; }
        public int? HierarchyDataId { get; set; }
        public string ProjectOwner { get; set; }
        public string ImpactMission { get; set; }

    }

}
