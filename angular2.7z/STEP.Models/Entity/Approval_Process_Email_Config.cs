using System;

namespace STEP.Models
{
    public partial class Approval_Process_Email_Config : EntityBase
    {
        public int Approval_Process_Id { get; set; }
        public Nullable<bool> To_Project_Owner { get; set; }
        public Nullable<int> Roled_Id_To_Send { get; set; }
        public Nullable<bool> Is_Enabled { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public Nullable<int> Hierarchy_Parent_Selection_Id { get; set; }
        public string Hierarchy_Parent_Selection_Key { get; set; }
        public virtual Role Role { get; set; }
    }
}
