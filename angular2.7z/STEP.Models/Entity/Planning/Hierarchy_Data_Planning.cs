﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Hierarchy_Data_Planning : EntityBase
    {       
        public int FY { get; set; }
        public int Hierarchy_Data_Id { get; set; }
        public decimal Control_Amount { get; set; }
        public int Priority_Status_Id { get; set; }
        public string Priority_Status_Key { get; set; }
        public Nullable<DateTime> Priority_Completion_Date { get; set; }
        public int Allocation_Status_Id { get; set; }
        public string Allocation_Status_Key { get; set; }
        public Nullable<DateTime> Allocation_Completion_Date { get; set; }
        public virtual Hierarchy_Data Hierarchy_Data  { get; set; }
        
        [NotMapped]
        public string Hierarchy_Data_Name { get; set; }
        [NotMapped]
        public bool IsAllocated { get; set; }
        [NotMapped]
        public bool CanAllocate { get; set; }
    }
}