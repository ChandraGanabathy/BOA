﻿using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public class Document
    {
        public string Name { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string FileContent { get; set; }
        public bool OverWrite { get; set; }
    }
}
