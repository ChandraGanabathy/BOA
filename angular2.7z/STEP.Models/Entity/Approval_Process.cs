namespace STEP.Models
{
    public partial class Approval_Process : EntityBase
    {
         
        public int Project_Type_Id { get; set; }
        public string Project_Type_Key { get; set; }
        public int Role_Id { get; set; }
        public int Action_Id { get; set; }
        public string Action_Key { get; set; }
        public int NewStatus_Approval_Status_Id { get; set; }
        public string NewStatus_Approval_Status_Key { get; set; }
        public int CurrentStatus_Approval_Status_Id { get; set; }
        public string CurrentStatus_Approval_Status_Key { get; set; }
        public string Notes { get; set; }
        
        public virtual Role Role { get; set; }
    }
}
