﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public class EmailParam
    {
        public List<int> RoleIds { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }
        [NotMapped]
        public string Message { get; set; }
    }
}
