namespace STEP.Models
{
    public partial class Help_Documents : EntityBase
    {
        public string FileName { get; set; }
        public string DisplayName { get; set; }
    }
}
