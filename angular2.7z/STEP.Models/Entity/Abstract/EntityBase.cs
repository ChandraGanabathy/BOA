﻿using System;

namespace STEP.Models
{
    public class EntityBase : IEntityBase
    {
        public int Id { get; set; }
        public string Created_By { get; set; }
        public DateTime Created_Date { get; set; }
        public string Modified_By { get; set; }
        public DateTime? Modified_Date { get; set; }
    }

    /*public class EntityBase1<T> : IEntityBase1<T>
            where T : class, IEntityBase, new()
    {
        public EntityBase1()
        {
             
        }

        public void SetEntityBase(T entity)
        {
             
        }
    }

    public interface IEntityBase1<in T> where T : class, IEntityBase, new()
    {
        void SetEntityBase(T entity);
        
    }*/
}
