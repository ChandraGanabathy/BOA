﻿using System;

namespace STEP.Models
{
    public interface IEntityBase 
    {
        int Id { get; set; }
        string Created_By { get; set; }
        System.DateTime Created_Date { get; set; }
        string Modified_By { get; set; }
        Nullable<System.DateTime> Modified_Date { get; set; }
    }
}
