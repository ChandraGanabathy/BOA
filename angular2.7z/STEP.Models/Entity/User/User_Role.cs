using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class User_Role : EntityBase
    {
        public User_Role()
        {
            this.Audits = new List<Audit>();
            this.Projects = new List<Project>();
            this.Project_Note = new List<Project_Note>();
            this.User_Audit = new List<User_Audit>();
            this.User_Role_Hierarchy_Assoication = new List<User_Role_Hierarchy_Assoication>();
            this.User_Role_Pillar_Association = new List<User_Role_Pillar_Association>();
        }

        public int User_Id { get; set; }
        public int Role_Id { get; set; }

        public Nullable<int> User_Role_Status_Id { get; set; }
        public string User_Role_Status_Key { get; set; }

        public virtual ICollection<Audit> Audits { get; set; }
        public virtual ICollection<Project> Projects { get; set; }
        public virtual ICollection<Project_Note> Project_Note { get; set; }
        public virtual Role Role { get; set; }
        public virtual ICollection<User_Audit> User_Audit { get; set; }
        public virtual ICollection<User_Role_Hierarchy_Assoication> User_Role_Hierarchy_Assoication { get; set; }
        public virtual ICollection<User_Role_Pillar_Association> User_Role_Pillar_Association { get; set; }
        public virtual User User { get; set; }

        //[NotMapped]
        //public string CurrentUserRoleGroup { get; set; }
    }
}
