namespace STEP.Models
{
    public partial class User_Role_Pillar_Association : EntityBase
    {
        public int User_Role_Id { get; set; }
        public int Pillar_Id { get; set; }
        public string Pillar_Key { get; set; }
        public int LawReg_Id { get; set; }
        public string LawReg_Key { get; set; }
        public int ProgramArea_Id { get; set; }
        public string ProgramArea_Key { get; set; }
        
        public virtual User_Role User_Role { get; set; }
    }
}
