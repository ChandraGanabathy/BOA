namespace STEP.Models
{
    public partial class User_Preference : EntityBase
    {
        
        public int User_Id { get; set; }
        public int Theme_Id { get; set; }
        public string Theme_Key { get; set; }
        public int Page_Size_Id { get; set; }
        public string Page_Size_Key { get; set; }
        public virtual User User { get; set; }
    }
}
