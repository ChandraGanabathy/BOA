using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class User : EntityBase
    {
        public User()
        {
            this.Projects = new List<Project>();
            this.User_Preference = new List<User_Preference>();
            this.User_Role = new List<User_Role>();
        }
        public string Email_Id { get; set; }

        public string Title { get; set; }
        public string First_Name { get; set; }
        public string Middle_Name { get; set; }
        public string Last_Name { get; set; }
        public string Password { get; set; }
        public string Address_Line1 { get; set; }
        public string Address_Line2 { get; set; }
        public string City { get; set; }
        public Nullable<int> State_Id { get; set; }
        public string State_Key { get; set; }
        public string Zip { get; set; }
        public string Phone { get; set; }
        public string Organization { get; set; }
        public int User_Status_Id { get; set; }
        public string User_Status_Key { get; set; }

        public virtual ICollection<Project> Projects { get; set; }
        public virtual ICollection<User_Preference> User_Preference { get; set; }
        public virtual ICollection<User_Role> User_Role { get; set; }

        [NotMapped]
        public bool IsLoginSucessed { get; set; }

        [NotMapped]
        public string Message { get; set; }

        [NotMapped]
        public ICollection<UserRole_Hierarchy_PillarLawReg_ViewModel> UserRole_Hierarchy_PillarLawReg_ViewModel { get; set; }
    }
}
