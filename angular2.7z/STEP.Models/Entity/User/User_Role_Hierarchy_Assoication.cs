using System;

namespace STEP.Models
{
    public partial class User_Role_Hierarchy_Assoication : EntityBase
    {
        
        public Nullable<int> Hierarchy_Data_Id { get; set; }
        public Nullable<int> User_Role_Id { get; set; }
        
         
        public virtual Hierarchy_Data Hierarchy_Data { get; set; }
        public virtual User_Role User_Role { get; set; }
    }
}
