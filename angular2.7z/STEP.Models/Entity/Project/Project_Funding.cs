using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Project_Funding : EntityBase
    {
        public int Project_Id { get; set; }
        public Nullable<int> FY { get; set; }
        public Nullable<int> Priority { get; set; }
        public Nullable<decimal> Validated { get; set; }
        public Nullable<decimal> Planned { get; set; }
        public Nullable<decimal> Programmed { get; set; }
        public Nullable<decimal> Funded { get; set; }
        public Nullable<decimal> Obligated { get; set; }
        public int Approval_Status_Id { get; set; }
        public string Approval_Status_Key { get; set; }
        public bool Is_UFR { get; set; }
        public Nullable<int> MDEP_Id { get; set; }
        public string MDEP_Key { get; set; }
        public Nullable<int> MSC_Priority { get; set; }
        public Nullable<int> HQ_Priority { get; set; }
        public Nullable<int> Funding_Status_Code_Id { get; set; }
        public string Funding_Status_Code_Key { get; set; }
        
        public virtual Project Project { get; set; }

        [NotMapped]
        public virtual Code_Value ApprovalStatusCodeValue { get; set; }

        [NotMapped]
        public virtual Code_Value FundingStatusCodeValue { get; set; } 

        [NotMapped]
        public virtual bool IsCurrentRequiredEditable { get; set; }
    
        [NotMapped]
        public virtual bool IsPlannedEditable { get; set; }
    
        [NotMapped]
        public virtual bool IsFundedEditable { get; set; }
    
        [NotMapped]
        public virtual bool IsObligatedEditable { get; set; }

        [NotMapped]
        public virtual bool IsUFREditable { get; set; }


        [NotMapped]
        public virtual List<Project_Note> ApprovalProcessWorkFlow { get; set; }

    }
}
