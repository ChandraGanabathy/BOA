using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Project_Document : EntityBase
    {

        public int Project_Id { get; set; }
        public string Document_Original_Name { get; set; }
        public string Document_Name { get; set; }

        public virtual Project Project { get; set; }
        [NotMapped]
        public virtual string FileType { get; set; }
        [NotMapped]
        public virtual string FilePath { get; set; }
        [NotMapped]
        public virtual string FileContent { get; set; }
        [NotMapped]
        public virtual bool OverWrite { get; set; }
    }
}
