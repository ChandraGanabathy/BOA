using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Project_Note : EntityBase
    {
         
        public int Project_Id { get; set; }
        public Nullable<int> Type_Id { get; set; }
        public string Type_Key { get; set; }
        public Nullable<int> User_Role_Id { get; set; }
        public string Notes { get; set; }
        public Nullable<int> SubSystem_Ref_Id { get; set; }
        public Nullable<int> Approval_Status_Id { get; set; }
        public string Approval_Status_Key { get; set; }
        
        public virtual Project Project { get; set; }
        public virtual User_Role User_Role { get; set; }

        [NotMapped]
        public virtual string RoleName { get; set; }

        [NotMapped]
        public virtual Code_Value ApprovalStatusCodeValue { get; set; }
        
    }
}
