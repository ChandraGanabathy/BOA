using System;

namespace STEP.Models
{
    public partial class Project_Answer : EntityBase
    {
         
        public int Project_Id { get; set; }
        public Nullable<int> Catalog_Question_Id { get; set; }
        public Nullable<int> FY { get; set; }
        public string Answer { get; set; }
         
        public virtual Catalog_Questions Catalog_Questions { get; set; }
        public virtual Project Project { get; set; }
    }
}
