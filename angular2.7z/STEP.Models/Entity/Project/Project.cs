using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Project : EntityBase
    {
        public Project()
        {
            this.Audits = new List<Audit>();
            this.Project_Answer = new List<Project_Answer>();
            this.Project_Document = new List<Project_Document>();
            this.Project_Funding = new List<Project_Funding>();
            this.Project_Note = new List<Project_Note>();
            this.ApprovalProcess = new List<Approval_Process>();
            //this.IsSaveVisible = false;
        }

        public string Project_Name { get; set; }
        public string Project_Number { get; set; }
        public Nullable<int> Hierarchy_Data_Id { get; set; }
        public Nullable<int> Catalog_Id { get; set; }
        public Nullable<int> Class_Id { get; set; }
        public string Class_Key { get; set; }
        public Nullable<int> Owner_ID { get; set; }
        
        public Nullable<int> Created_User_Role_Id { get; set; }
        public string Project_Description { get; set; }
        public string ROI { get; set; }
        public bool Is_Recurring { get; set; }
        public Nullable<int> Impact_to_Mission_Id { get; set; }
        public string Impact_to_Mission_Key { get; set; }
        public Nullable<int> Environmental_Impact_Code_Id { get; set; }
        public string Environmental_Impact_Code_Key { get; set; }
        public virtual Catalog Catalog { get; set; }
        
        public virtual Hierarchy_Data Hierarchy_Data { get; set; }
        public virtual ICollection<Audit> Audits { get; set; }
        public virtual ICollection<Project_Answer> Project_Answer { get; set; }
        public virtual ICollection<Project_Document> Project_Document { get; set; }
        public virtual ICollection<Project_Funding> Project_Funding { get; set; }
        public virtual ICollection<Project_Note> Project_Note { get; set; }
        public virtual User_Role User_Role { get; set; }
        public virtual User User { get; set; }

        [NotMapped]
        public Fiscal_Year ProjectFiscalYear;

        [NotMapped]
        public virtual string RoleName { get; set; }
        [NotMapped]
        public string Project_Owner { get; set; }

        [NotMapped]
        public virtual bool IsSubmitForApprovalVisible { get; set; }

        [NotMapped]
        public virtual bool IsApproveVisible { get; set; }

        [NotMapped]
        public virtual bool IsDisapproveVisible { get; set; }

        [NotMapped]
        public virtual List<Approval_Process> ApprovalProcess { get; set; }

        [NotMapped]
        public virtual string ApprovalAction { get; set; }

        //[NotMapped]
        //public virtual bool IsSaveVisible { get; set; }

        [NotMapped]
        public virtual bool IsViewProjectHistoryVisible { get; set; }

        [NotMapped]
        public virtual string ApproveDisapproveNotes { get; set; }  
       
    }
}
