using System;

namespace STEP.Models
{
    public partial class Role_Action : EntityBase
    {

        public int Role_Id { get; set; }
        public int Action_Id { get; set; }
        public virtual Action Action { get; set; }
        public virtual Role Role { get; set; }
    }
}
