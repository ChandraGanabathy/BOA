using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public partial class Role : EntityBase
    {
        public Role()
        {
            this.Approval_Process = new List<Approval_Process>();
            this.Approval_Process_Email_Config = new List<Approval_Process_Email_Config>();
            //this.Report_Role_Mapping = new List<Report_Role_Mapping>();
            this.Role_Action = new List<Role_Action>();
            this.Role_Invitation_Mapping = new List<Role_Invitation_Mapping>();
            this.Role_Invitation_Mapping1 = new List<Role_Invitation_Mapping>();
            this.User_Role = new List<User_Role>();
        }

        
        public string Role_Key { get; set; }
        public string Name { get; set; }
        public int Hierarchy_Level_Id { get; set; }
        public string Hierarchy_Level_Key { get; set; }
        //public Nullable<int> Role_Group_Id { get; set; }
        //public string Role_Group_Key { get; set; }

        public virtual ICollection<Approval_Process> Approval_Process { get; set; }
        //public virtual ICollection<Report_Role_Mapping> Report_Role_Mapping { get; set; }
        public virtual ICollection<Role_Action> Role_Action { get; set; }
        public virtual ICollection<Role_Invitation_Mapping> Role_Invitation_Mapping { get; set; }
        public virtual ICollection<Role_Invitation_Mapping> Role_Invitation_Mapping1 { get; set; }
        public virtual ICollection<User_Role> User_Role { get; set; }

        public virtual ICollection<Approval_Process_Email_Config> Approval_Process_Email_Config { get; set; }
    }
}
