using System;

namespace STEP.Models
{
    public partial class Role_Invitation_Mapping : EntityBase
    {
        
        public Nullable<int> Parent_Role_Id { get; set; }
        public Nullable<int> Child_Role_Id { get; set; }


        public virtual Role Parent_Role { get; set; }
        public virtual Role Child_Role { get; set; } 
    }
}
