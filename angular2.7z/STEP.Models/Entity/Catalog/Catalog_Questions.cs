using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Catalog_Questions : EntityBase
    {
        public Catalog_Questions()
        {
            this.Project_Answer = new List<Project_Answer>();
        }
        public virtual ICollection<Project_Answer> Project_Answer { get; set; }

        public int Catalog_Id { get; set; }
        public string Question { get; set; }
        public int Answer_Type_Id { get; set; }
        public string Answer_Type_Key { get; set; }
        public bool IsRequired { get; set; }
        public int Start_FY { get; set; }
        public Nullable<int> End_FY { get; set; }
        
       
        public virtual Catalog Catalog { get; set; }

        [NotMapped]
        public Code_Value CodeValueAnswerType { get; set; }
        [NotMapped]
        public int? FiscalYear { get; set; }
        [NotMapped]
        public string Answer { get; set; }
        [NotMapped]
        public int ProjectId { get; set; }
    }
}
