using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public partial class AMSCO : EntityBase
    {
        public AMSCO()
        {
            this.Catalog_AMSCO = new List<Catalog_AMSCO>();
        }
        
        public string AMSCO_Code { get; set; }
        public string AMSCO_Description { get; set; }
        public Nullable<int> Start_FY { get; set; }
        public Nullable<int> End_FY { get; set; }
        public virtual ICollection<Catalog_AMSCO> Catalog_AMSCO { get; set; }
    }
}
