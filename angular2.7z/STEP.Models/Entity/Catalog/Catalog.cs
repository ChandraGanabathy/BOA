using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Catalog : EntityBase
    {
        public Catalog()
        {
            this.Catalog_AMSCO = new List<Catalog_AMSCO>();
            this.Catalog_Questions = new List<Catalog_Questions>();
            this.Projects = new List<Project>();
        }
        public string Catalog_Number { get; set; }
        public string Catalog_Name { get; set; }
        public int Class_Id { get; set; }
        public string Class_Key { get; set; }
        public int Status_Id { get; set; }
        public string Status_Key { get; set; }
        public Nullable<int> Pillar_Lawreg_Mapping_Id { get; set; }
        public Nullable<int> Pillar_PB28_Mapping_Id { get; set; }
        public string Catalog_Narrative { get; set; }

        public virtual ICollection<Catalog_AMSCO> Catalog_AMSCO { get; set; }
        public virtual Pillar_LawReg_Mapping Pillar_LawReg_Mapping { get; set; }
        public virtual Pillar_PB28_Mapping Pillar_PB28_Mapping { get; set; }
        public virtual ICollection<Catalog_Questions> Catalog_Questions { get; set; }
        public virtual ICollection<Project> Projects { get; set; }

        [NotMapped]
        public string AMSCOCode { get; set; }
        


    }
}
