﻿using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public partial class MDEP : EntityBase
    {
        public string MDEP_Code { get; set; }
        public int Pillar_Id { get; set; }
        public string Pillar_Key { get; set; }      
        public int Start_FY { get; set; }
        public Nullable<int> End_FY { get; set; }
    }
}
