using System;

namespace STEP.Models
{
    public partial class Catalog_AMSCO : EntityBase
    {
        
        public int Catalog_Id { get; set; }
        public int AMSCO_Id { get; set; }
        //public int Start_FY { get; set; }
        //public Nullable<int> End_FY { get; set; }
        
       
        public virtual AMSCO AMSCO { get; set; }
        public virtual Catalog Catalog { get; set; }
    }
}
