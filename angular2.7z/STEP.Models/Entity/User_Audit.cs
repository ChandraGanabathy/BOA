using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public partial class User_Audit : EntityBase
    {


        public Nullable<int> User_Role_Id { get; set; }
        public System.DateTime Date_Time { get; set; }
        public Nullable<int> Action_Id { get; set; }
        public string Action_Key { get; set; }
        public Nullable<int> Current_User_Role_Id { get; set; }
        public virtual User_Role User_Role { get; set; }
    }
}
