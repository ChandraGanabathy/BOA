using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace  STEP.Models
{
    public partial class Audit:EntityBase
    {
        public Audit()
        {
            this.Audit_Details = new List<Audit_Details>();
        }
         
        public string Table_Name { get; set; }
        public int Primary_Key { get; set; }
        public int Project_Id { get; set; }
        public int User_Role_Id { get; set; }
        public int Change_Type_Id { get; set; }
        public string Change_Type_Value { get; set; }
        public Nullable<System.Guid> Transaction_Unique_Id { get; set; }
         
        public virtual ICollection<Audit_Details> Audit_Details { get; set; }
        public virtual User_Role User_Role { get; set; }
        public virtual Project Project { get; set; }

        [NotMapped]
        public string Role { get; set; }
        [NotMapped]
        public string UserName { get; set; }

        
    }
}
