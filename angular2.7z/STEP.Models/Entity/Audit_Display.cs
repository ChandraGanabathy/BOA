using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public partial class Audit_Display : EntityBase
    {
        public string Entity_Name { get; set; }
        public string Display_Name { get; set; }
        public Nullable<int> Code_Id { get; set; }
    }
}
