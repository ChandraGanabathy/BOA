using System;
using System.Collections.Generic;

namespace  STEP.Models
{
    public partial class Audit_Details:EntityBase
    {
        
        public int Audit_Id { get; set; }
        public string Column_Name { get; set; }
        public string Old_Value { get; set; }
        public string New_Value { get; set; }
        public Nullable<int> FY { get; set; }
        public virtual Audit Audit { get; set; }
    }
}
