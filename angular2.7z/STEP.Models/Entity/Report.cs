using System.Collections.Generic;
namespace STEP.Models
{
    public partial class Report : EntityBase
    {
        public Report()
        {
            this.Report_Role_Mapping = new List<Report_Role_Mapping>();
        }
        public string Name { get; set; }
        public virtual ICollection<Report_Role_Mapping> Report_Role_Mapping { get; set; }

    }
}
