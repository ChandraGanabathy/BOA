using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public partial class Hierarchy_Data : EntityBase
    {
        public Hierarchy_Data()
        {
            this.Child_Hierarchy_Data = new List<Hierarchy_Data>();
            this.Projects = new List<Project>();
            this.User_Role_Hierarchy_Assoication = new List<User_Role_Hierarchy_Assoication>();
            this.Hierarchy_Data_Planning = new List<Hierarchy_Data_Planning>();
        }

        public Nullable<int> Parent_Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public int Hierarchy_Level_Id { get; set; }
        public string Hierarchy_Level_Key { get; set; }
        public Nullable<int> State_Id { get; set; }
        public string State_Key { get; set; }
        
        public virtual ICollection<Hierarchy_Data> Child_Hierarchy_Data { get; set; }
        public virtual Hierarchy_Data Parent_Hierarchy_Data { get; set; }
        public virtual ICollection<Project> Projects { get; set; }
        public virtual ICollection<User_Role_Hierarchy_Assoication> User_Role_Hierarchy_Assoication { get; set; }
        public virtual ICollection<Hierarchy_Data_Planning> Hierarchy_Data_Planning { get; set; }
    }
}
