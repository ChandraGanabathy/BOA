using System;
using System.Collections.Generic;

namespace STEP.Models
{
    public partial class Action : EntityBase
    {
        public Action()
        {
            this.Role_Action = new List<Role_Action>();
        }
        public string Action_Name { get; set; }
        public string Action_Description { get; set; }
        public string Controller_Name { get; set; }
        public int Type_Id { get; set; }
        public string Type_Key { get; set; }
        public virtual ICollection<Role_Action> Role_Action { get; set; }
    }
}
