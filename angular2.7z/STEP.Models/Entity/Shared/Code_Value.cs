using System;

namespace STEP.Models
{
    public partial class Code_Value : EntityBase
    {
        
        public int Code_ID { get; set; }
        public string Code_Value_Key { get; set; }
        public string Code_Value_Description { get; set; }
        public string Data1 { get; set; }
        public string Data2 { get; set; }
        public string Data3 { get; set; }
        public Nullable<int> SequenceNumber { get; set; }
        
     
        public virtual Code Code { get; set; }
    }
}
