using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Pillar_LawReg_Mapping : EntityBase
    {
        public Pillar_LawReg_Mapping()
        {
            this.Catalogs = new List<Catalog>();
            this.PillarCodeValue=new Code_Value();
            this.LawRegCodeValue = new Code_Value();
            this.ProgramAreaCodeValue = new Code_Value();
        }

        
        public int Pillar_Id { get; set; }
        public string Pillar_Key { get; set; }
        public int LawReg_Id { get; set; }
        public string LawReg_Key { get; set; }
        public int ProgramArea_Id { get; set; }
        public string ProgramArea_Key { get; set; }
         
        public virtual ICollection<Catalog> Catalogs { get; set; }
         

        [NotMapped]
        public Code_Value PillarCodeValue { get; set; }
        [NotMapped]
        public Code_Value LawRegCodeValue { get; set; }
        [NotMapped]
        public Code_Value ProgramAreaCodeValue { get; set; }
    }
}
