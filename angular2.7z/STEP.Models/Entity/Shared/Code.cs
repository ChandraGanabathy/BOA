using System.Collections.Generic;

namespace STEP.Models
{
    public partial class Code : EntityBase
    {
        public Code()
        {
            this.Code_Value = new List<Code_Value>();
        }
        public string Code_Description { get; set; }
        public virtual ICollection<Code_Value> Code_Value { get; set; }
    }
}
