using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Pillar_PB28_Mapping : EntityBase
    {
        public Pillar_PB28_Mapping()
        {
            this.Catalogs = new List<Catalog>();
        }

         
        public int Pillar_Id { get; set; }
        public string Pillar_Key { get; set; }
        public int Title_Id { get; set; }
        public string Title_Key { get; set; }
        public int Category_Id { get; set; }
        public string Category_Key { get; set; }
        public int SubCategory_Id { get; set; }
        public string SubCategory_Key { get; set; }
        
        public virtual ICollection<Catalog> Catalogs { get; set; }
         

        [NotMapped]
        public Code_Value PillarCodeValue { get; set; }
        [NotMapped]
        public Code_Value TitleCodeValue { get; set; } 
        [NotMapped]
        public Code_Value CategoryCodeValue { get; set; }
        [NotMapped]
        public Code_Value SubCategoryCodeValue { get; set; } 
       
    }
}
