using System.ComponentModel.DataAnnotations.Schema;

namespace STEP.Models
{
    public partial class Fiscal_Year : EntityBase
    {
        public int FY { get; set; }
        public System.DateTime FY_Start_Date { get; set; }
        public System.DateTime FY_End_Date { get; set; }
        public System.DateTime CurrentYear_Start_Date { get; set; }
        public System.DateTime CurrentYear_End_Date { get; set; }
        public System.DateTime Programmed_Start_Date { get; set; }
        public System.DateTime Programmed_End_Date { get; set; }
        public System.DateTime Planning_Start_Date { get; set; }
        public System.DateTime Planning_End_Date { get; set; }
        public System.DateTime Funding_Start_Date { get; set; }
        public System.DateTime Funding_End_Date { get; set; }
        public System.DateTime Obligation_Start_Date { get; set; }
        public System.DateTime Obligation_End_Date { get; set; }

        [NotMapped]
        public string Message { get; set; }
    }
}
