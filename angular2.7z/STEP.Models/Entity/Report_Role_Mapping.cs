using System;

namespace STEP.Models
{
    public partial class Report_Role_Mapping : EntityBase
    {
        
        public int Report_Id { get; set; }
        public int Role_Id { get; set; }
        public Nullable<bool> Is_Allowed { get; set; }
         
        public virtual Role Role { get; set; }
        public virtual Report Report { get; set; }
    }
}
