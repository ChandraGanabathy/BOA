﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STEP.Models
{
    public class UserRole_Hierarchy_PillarLawReg_ViewModel
    {
        public int Role_Id { get; set; }
        public string Role_Name { get; set; }
        public int User_Role_Id { get; set; }
        public string User_Role_Status_Key { get; set; }
        public string User_Role_Status_Description { get; set; }
        public int User_Role_Hierarchy_Association_Id { get; set; }
        public int? Hierarchy_Data_Id { get; set; }
        public string Hierarchy_Data_Name { get; set; }
        public int User_Role_Pillar_Association_Id { get; set; }
        public string Pillar_Key { get; set; }
        public string Pillar_Description { get; set; }
        public string LawReg_Key { get; set; }
        public string LawReg_Description { get; set; }
        public string ProgramArea_Key { get; set; }
        public string ProgramArea_Description { get; set; }

    }
}
