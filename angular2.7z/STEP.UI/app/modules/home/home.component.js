"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var common_1 = require('@angular/common');
var data_service_1 = require('../../shared/services/data-service');
var HomeComponent = (function () {
    function HomeComponent(location, dataService) {
        this.location = location;
        this.dataService = dataService;
        location.go('/home');
    }
    HomeComponent.prototype.ngOnInit = function () {
    };
    // Function After View Init
    HomeComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        this.dataService.getDataForDashboard()
            .subscribe(function (result) {
            _this.dashBoardDataAll = result;
            _this.bindChartData(_this.dashBoardDataAll[0].PFChartData, "divPFChart", "Funding Data", "column", '${point.y:.0f}', false, false);
            _this.bindChartData(_this.dashBoardDataAll[0].PercentFundChartData, "divPercentFundedChart", "Percentage by Pillar", "pie", 'Amount: ${point.y:.0f}', false, false);
        }, function (errors) {
        });
    };
    HomeComponent.prototype.bindChartData = function (chartData, containerId, chartTitle, chartType, toolTipFormat, isShowLegend, isPopup) {
        if (chartData == undefined || chartData.length == 0) {
            this.chartNoDataMessage(containerId, chartTitle);
            return;
        }
        this.chartDataPopulation(chartData, containerId, chartTitle, chartType, toolTipFormat, isShowLegend, isPopup);
    };
    HomeComponent.prototype.chartDataPopulation = function (dataSource, chartId, title, chartType, toolTipFormat, isShowLegend, isPopup) {
        var text = '[';
        var drilldowntext = '[';
        if (chartId != "divPercentFundedChart") {
            for (var i = 0; i < dataSource.length; i++) {
                text += '{ \"name\" : \"' + dataSource[i].Key + '\", ';
                text += '\"y\" : ' + dataSource[i].Value + '}, ';
            }
        }
        else {
            for (var j = 0; j < dataSource.length; j++) {
                text += '{ \"name\" : \"' + dataSource[j].ParentKey + '\", ';
                text += '\"y\" : ' + dataSource[j].ParentValue + ', ';
                text += '\"drilldown\" : \"' + dataSource[j].ParentId + '\"}, ';
                drilldowntext += '{ \"id\" : \"' + dataSource[j].ParentId + '\", ';
                //drilldowntext += '\"name\" : \"' + value.ParentKey + '\", ';
                drilldowntext += '\"name\" : \"Law Reg\", ';
                drilldowntext += '\"colorByPoint\" : true , ';
                drilldowntext += '\"data\" : [';
                for (var a = 0; a < dataSource[j].ChildLevel1.length; a++) {
                    drilldowntext += '{\"name\" : \"' + dataSource[j].ChildLevel1[a].ChildLevel1Key + '\", ';
                    drilldowntext += '\"y\" : ' + dataSource[j].ChildLevel1[a].ChildLevel1Value + ', ';
                    drilldowntext += '\"drilldown\" : \"' + dataSource[j].ChildLevel1[a].ChildLevel1Id + '\"}, ';
                }
                drilldowntext = drilldowntext.substring(0, drilldowntext.length - 2);
                drilldowntext += ']},';
                for (var b = 0; b < dataSource[j].ChildLevel1.length; b++) {
                    drilldowntext += '{ \"id\" : \"' + dataSource[j].ChildLevel1[b].ChildLevel1Id + '\", ';
                    drilldowntext += '\"name\" : \"' + dataSource[j].ChildLevel1[b].ChildLevel1Key + '\", ';
                    drilldowntext += '\"colorByPoint\" : true , ';
                    drilldowntext += '\"data\" : [';
                    for (var c = 0; c < dataSource[j].ChildLevel1[b].ChildLevel2.length; c++) {
                        drilldowntext += '{\"name\" : \"' + dataSource[j].ChildLevel1[b].ChildLevel2[c].ChildLevel2Key + '\", ';
                        drilldowntext += '\"y\" : ' + dataSource[j].ChildLevel1[b].ChildLevel2[c].ChildLevel2Value + '}, ';
                    }
                    drilldowntext = drilldowntext.substring(0, drilldowntext.length - 2);
                    drilldowntext += ']}, ';
                }
            }
            drilldowntext = drilldowntext.substring(0, drilldowntext.length - 2);
            drilldowntext += ']';
        }
        text = text.substring(0, text.length - 2);
        var chartData = [];
        if (text != "") {
            text += ']';
            chartData = JSON.parse(text);
        }
        var chartData = JSON.parse(text);
        var drilldownData = undefined;
        if (drilldowntext != '[')
            drilldownData = JSON.parse(drilldowntext);
        this.chartRendering(chartId, chartType, title, chartData, drilldownData, toolTipFormat, isShowLegend, isPopup);
    };
    HomeComponent.prototype.chartNoDataMessage = function (chartId, chartTitle) {
        jQuery('#' + chartId).html('');
        jQuery('#' + chartId).append('<div class="row spacer"><div class="col-md-12 text-center"><h3>' + chartTitle + '</h3></div><div class="col-md-12 text-center"><br /><br />No data available.</div></div>');
    };
    HomeComponent.prototype.chartRendering = function (id, chartType, chartTitleText, dataSource, drilldownData, toolTipFormat, isShowLegend, isPopup) {
        jQuery(function () {
            Highcharts.setOptions({
                lang: {
                    thousandsSep: ','
                }
            });
            jQuery('#' + id).highcharts({
                chart: {
                    type: chartType,
                },
                title: {
                    text: chartTitleText,
                },
                tooltip: {
                    pointFormat: toolTipFormat
                },
                xAxis: {
                    type: 'category'
                },
                legend: {
                    enabled: false
                },
                exporting: {
                    enabled: false
                },
                plotOptions: {
                    series: {
                        animation: true,
                        dataLabels: {
                            enabled: true,
                        },
                    },
                    pie: {
                        depth: 35,
                        minSize: 2,
                        dataLabels: {
                            style: {
                                width: '100px'
                            },
                            format: isPopup == false ? '<b>{point.name}: {point.percentage:.2f}%</b>' : '<b>{point.name}</b>: {percentage:.2f} %'
                        },
                        showInLegend: isShowLegend,
                    }
                },
                credits: {
                    enabled: false
                },
                series: [{
                        name: id = "divPercentFundedChart" ? "Pillar" : '',
                        type: chartType,
                        colorByPoint: true,
                        data: dataSource,
                        dataLabels: {
                            enabled: true,
                            formatter: function () {
                                return '$' + Highcharts.numberFormat(this.y, 0);
                            }
                        }
                    }],
                drilldown: {
                    series: drilldownData
                }
            });
        });
    };
    HomeComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'home',
            templateUrl: 'home.component.html',
        }), 
        __metadata('design:paramtypes', [common_1.Location, data_service_1.DataService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=home.component.js.map