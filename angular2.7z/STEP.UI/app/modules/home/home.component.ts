import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Location } from '@angular/common';
import { DatepickerComponent } from "../../shared/ng2-datepicker/datepicker.component";
import { DataService } from '../../shared/services/data-service';

declare var jQuery: any;

@Component({
    moduleId: module.id,
    selector: 'home',
    templateUrl: 'home.component.html',
})
export class HomeComponent implements OnInit {

    private date: string;
    private date2: string;
    dashBoardDataAll: any;
    constructor(private location: Location
        , private dataService: DataService) {
        location.go('/home');
    }
    ngOnInit() {

    }
    // Function After View Init
    ngAfterViewInit() {
        this.dataService.getDataForDashboard()
            .subscribe((result: any) => {
                this.dashBoardDataAll = result;
                this.bindChartData(this.dashBoardDataAll[0].PFChartData, "divPFChart", "Funding Data", "column", '${point.y:.0f}', false, false);
                this.bindChartData(this.dashBoardDataAll[0].PercentFundChartData, "divPercentFundedChart", "Percentage by Pillar", "pie", 'Amount: ${point.y:.0f}'
                    , false, false);
            },
            errors => {

            });
    }

    bindChartData(chartData: any, containerId: string, chartTitle: string, chartType: string, toolTipFormat: string, isShowLegend: boolean, isPopup: boolean) {
        if (chartData == undefined || chartData.length == 0) {
            this.chartNoDataMessage(containerId, chartTitle);
            return;
        }
        this.chartDataPopulation(chartData, containerId, chartTitle, chartType, toolTipFormat, isShowLegend, isPopup);
    }

    chartDataPopulation(dataSource: any, chartId: string, title: string, chartType: string, toolTipFormat: string, isShowLegend: boolean, isPopup: boolean) {
        var text = '[';
        var drilldowntext = '[';

        if (chartId != "divPercentFundedChart") {
            for (var i = 0; i < dataSource.length; i++) {
                text += '{ \"name\" : \"' + dataSource[i].Key + '\", ';
                text += '\"y\" : ' + dataSource[i].Value + '}, ';
            }
        } else {
            for (var j = 0; j < dataSource.length; j++) {
                text += '{ \"name\" : \"' + dataSource[j].ParentKey + '\", ';
                text += '\"y\" : ' + dataSource[j].ParentValue + ', ';
                text += '\"drilldown\" : \"' + dataSource[j].ParentId + '\"}, ';

                drilldowntext += '{ \"id\" : \"' + dataSource[j].ParentId + '\", ';
                //drilldowntext += '\"name\" : \"' + value.ParentKey + '\", ';
                drilldowntext += '\"name\" : \"Law Reg\", ';
                drilldowntext += '\"colorByPoint\" : true , ';
                drilldowntext += '\"data\" : [';

                for (var a = 0; a < dataSource[j].ChildLevel1.length; a++) {
                    drilldowntext += '{\"name\" : \"' + dataSource[j].ChildLevel1[a].ChildLevel1Key + '\", ';
                    drilldowntext += '\"y\" : ' + dataSource[j].ChildLevel1[a].ChildLevel1Value + ', ';
                    drilldowntext += '\"drilldown\" : \"' + dataSource[j].ChildLevel1[a].ChildLevel1Id + '\"}, ';
                }

                drilldowntext = drilldowntext.substring(0, drilldowntext.length - 2);
                drilldowntext += ']},';

                for (var b = 0; b < dataSource[j].ChildLevel1.length; b++) {
                    drilldowntext += '{ \"id\" : \"' + dataSource[j].ChildLevel1[b].ChildLevel1Id + '\", ';
                    drilldowntext += '\"name\" : \"' + dataSource[j].ChildLevel1[b].ChildLevel1Key + '\", ';
                    drilldowntext += '\"colorByPoint\" : true , ';
                    drilldowntext += '\"data\" : [';
                    for (var c = 0; c < dataSource[j].ChildLevel1[b].ChildLevel2.length; c++) {
                        drilldowntext += '{\"name\" : \"' + dataSource[j].ChildLevel1[b].ChildLevel2[c].ChildLevel2Key + '\", ';
                        drilldowntext += '\"y\" : ' + dataSource[j].ChildLevel1[b].ChildLevel2[c].ChildLevel2Value + '}, ';
                    }
                    drilldowntext = drilldowntext.substring(0, drilldowntext.length - 2);
                    drilldowntext += ']}, ';
                }
            }
            drilldowntext = drilldowntext.substring(0, drilldowntext.length - 2);
            drilldowntext += ']';
        }

        text = text.substring(0, text.length - 2);
        var chartData: any = [];
        if (text != "") {
            text += ']';
            chartData = JSON.parse(text);
        }

        var chartData = JSON.parse(text);
        var drilldownData: string = undefined;
        if (drilldowntext != '[')
            drilldownData = JSON.parse(drilldowntext);
        this.chartRendering(chartId, chartType, title, chartData, drilldownData, toolTipFormat, isShowLegend, isPopup);
    }

    chartNoDataMessage(chartId: string, chartTitle: string) {
        jQuery('#' + chartId).html('');
        jQuery('#' + chartId).append('<div class="row spacer"><div class="col-md-12 text-center"><h3>' + chartTitle + '</h3></div><div class="col-md-12 text-center"><br /><br />No data available.</div></div>');
    }

    chartRendering(id: string, chartType: string, chartTitleText: string, dataSource: any, drilldownData: string
        , toolTipFormat: string, isShowLegend: boolean, isPopup: boolean) {
        jQuery(function () {
            Highcharts.setOptions({
                lang: {
                    thousandsSep: ','
                }
            });

            jQuery('#' + id).highcharts({
                chart: {
                    type: chartType,
                },
                title: {
                    text: chartTitleText,
                },
                tooltip: {
                    pointFormat: toolTipFormat
                },
                xAxis: {
                    type: 'category'
                },
                legend: {
                    enabled: false
                },
                exporting: {
                    enabled: false
                },
                plotOptions: {
                    series: {
                        animation: true,
                        dataLabels: {
                            enabled: true,
                        },
                    },
                    pie: {
                        depth: 35,
                        minSize: 2,
                        dataLabels: {
                            style: {
                                width: '100px'
                            },
                            format: isPopup == false ? '<b>{point.name}: {point.percentage:.2f}%</b>' : '<b>{point.name}</b>: {percentage:.2f} %'
                        },
                        showInLegend: isShowLegend,
                    }
                },
                credits: {
                    enabled: false
                },
                series: [{
                    name: id = "divPercentFundedChart" ? "Pillar" : '',
                    type: chartType,
                    colorByPoint: true,
                    data: dataSource,
                    dataLabels: {
                        enabled: true,
                        formatter: function () {
                            return '$' + Highcharts.numberFormat(this.y, 0);
                        }
                    }
                }],
                drilldown: {
                    series: drilldownData
                }
            });
        });
    }
}