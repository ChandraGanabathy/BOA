import {
    Component, OnInit
    , ViewChild
    , Input, Output
    , trigger, state, style, animate, transition, AfterViewInit, ChangeDetectorRef, Directive,
    ElementRef
} from '@angular/core';

import { ModalDirective } from 'ng2-bootstrap';
import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { HttpModule, Http } from '@angular/http'
import { DataService } from '../../shared/services/data-service';
import { ItemsService } from '../../shared/utils/items-service';
import { NotificationService } from '../../shared/utils/notification-service';
import { PagerService } from '../../shared/utils/pager.service';
import { ConfigService } from '../../shared/utils/config-service';
import { IUser, Pagination, PaginatedResult } from '../../shared/interfaces';
import { PaginationComponent } from '../../shared/pagination/pagination.component';
import { Sorter } from '../../shared/pagination/sorter';
import { UserSearchFilter } from '../../filters/search-filter';

@Component({
    moduleId: module.id,
    selector: 'users',
    templateUrl: 'user-list.component.html'
})
export class UserListComponent implements OnInit {
    users: IUser[];
    usersListDataSource: IUser[];
    usersPagination: IUser[];
    userListAll: any;
    pager: any = {};
    pageloaded: boolean = false;
    sorter: Sorter;
    userSearchFilter: UserSearchFilter;
    apiHost: string;

    constructor(private dataservice: DataService
        , private itemsService: ItemsService
        , private notificationService: NotificationService
        , private loadingBarService: SlimLoadingBarService
        , private pagerService: PagerService
        , private configService: ConfigService
    ) {
        this.sorter = new Sorter();
        this.apiHost = this.configService.getApiHost();
    }

    ngOnInit() {
        this.getUserListPageLoading();
    }

    clickAcitveInactiveUser(userEntity: IUser) {
        this.notificationService.openConfirmationDialog(userEntity.User_Status_Key == 'ACTV' ? 'Are you sure you want to Inactivate the user?'
            : 'Are you sure you want to Activate the user?',
            () => {
                switch (userEntity.User_Status_Key) {
                    case 'ACTV':
                        userEntity.User_Status_Key = 'IACT';
                        break;

                    case 'IACT':
                        userEntity.User_Status_Key = 'ACTV';
                        break;
                }
                this.loadingBarService.start();
                this.dataservice.updateUserStatus(userEntity)
                    .subscribe((res: IUser) => {
                        this.loadingBarService.complete();
                        var _user: IUser = this.itemsService.getSerialized<IUser>(res);
                        this.itemsService.setItem<IUser>(this.usersListDataSource, (u) => u.Id == _user.Id, _user);
                        this.setPage(this.pager.currentPage);
                    },
                    errors => {
                        this.loadingBarService.complete();
                    });
            });
    }

    clickSearch() {
        this.loadingBarService.start();
        if (this.userSearchFilter)
            this.dataservice.getAllUsers(this.userSearchFilter)
                .subscribe((result: IUser[]) => {
                    this.clearDatas();
                    this.usersListDataSource = result;
                    if (this.usersListDataSource.length > 0) {
                        this.pager = this.pagerService.getPager(this.usersListDataSource.length, 1, 'Users');
                        this.setPage(1);
                    }
                    this.loadingBarService.complete();
                },
                errors => {
                    this.loadingBarService.complete();
                });
    }

    private clearDatas() {
        this.users = [];
        this.usersListDataSource = [];
        this.pager = undefined;
    }

    getUserListPageLoading() {
        this.loadingBarService.start();
        this.dataservice.getUserListingPageLoading()
            .subscribe((items: any) => {
                this.userListAll = items;
                this.usersListDataSource = this.userListAll[0].GetAllUsers;
                this.userSearchFilter = this.userListAll[0].UserSearchCriteria;
                this.loadingBarService.complete();
                this.setPage(1);
                this.pageloaded = true;
            },
            error => {
                this.pageloaded = true;
                this.loadingBarService.complete();
            });
    }

    pageIndexChanging(getPageIndex: number) {
        this.setPage(getPageIndex);
    }

    setPage(page: number) {
        if (page < 1 || page > this.pager.totalPages) {
            return;
        }
        // get pager object from service
        this.pager = this.pagerService.getPager(this.usersListDataSource.length, page, 'Users');
        this.pager
        // get current page of items
        this.users = this.usersListDataSource.slice(this.pager.startIndex, this.pager.endIndex + 1);
    }

    sort(key: any) {
        this.sorter.sort(key, this.usersListDataSource);
        this.users = this.usersListDataSource.slice(this.pager.startIndex, this.pager.endIndex + 1);
    }

}