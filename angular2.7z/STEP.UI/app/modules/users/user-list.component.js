"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var ng2_slim_loading_bar_1 = require('ng2-slim-loading-bar');
var data_service_1 = require('../../shared/services/data-service');
var items_service_1 = require('../../shared/utils/items-service');
var notification_service_1 = require('../../shared/utils/notification-service');
var pager_service_1 = require('../../shared/utils/pager.service');
var config_service_1 = require('../../shared/utils/config-service');
var sorter_1 = require('../../shared/pagination/sorter');
var UserListComponent = (function () {
    function UserListComponent(dataservice, itemsService, notificationService, loadingBarService, pagerService, configService) {
        this.dataservice = dataservice;
        this.itemsService = itemsService;
        this.notificationService = notificationService;
        this.loadingBarService = loadingBarService;
        this.pagerService = pagerService;
        this.configService = configService;
        this.pager = {};
        this.pageloaded = false;
        this.sorter = new sorter_1.Sorter();
        this.apiHost = this.configService.getApiHost();
    }
    UserListComponent.prototype.ngOnInit = function () {
        this.getUserListPageLoading();
    };
    UserListComponent.prototype.clickAcitveInactiveUser = function (userEntity) {
        var _this = this;
        this.notificationService.openConfirmationDialog(userEntity.User_Status_Key == 'ACTV' ? 'Are you sure you want to Inactivate the user?'
            : 'Are you sure you want to Activate the user?', function () {
            switch (userEntity.User_Status_Key) {
                case 'ACTV':
                    userEntity.User_Status_Key = 'IACT';
                    break;
                case 'IACT':
                    userEntity.User_Status_Key = 'ACTV';
                    break;
            }
            _this.loadingBarService.start();
            _this.dataservice.updateUserStatus(userEntity)
                .subscribe(function (res) {
                _this.loadingBarService.complete();
                var _user = _this.itemsService.getSerialized(res);
                _this.itemsService.setItem(_this.usersListDataSource, function (u) { return u.Id == _user.Id; }, _user);
                _this.setPage(_this.pager.currentPage);
            }, function (errors) {
                _this.loadingBarService.complete();
            });
        });
    };
    UserListComponent.prototype.clickSearch = function () {
        var _this = this;
        this.loadingBarService.start();
        if (this.userSearchFilter)
            this.dataservice.getAllUsers(this.userSearchFilter)
                .subscribe(function (result) {
                _this.clearDatas();
                _this.usersListDataSource = result;
                if (_this.usersListDataSource.length > 0) {
                    _this.pager = _this.pagerService.getPager(_this.usersListDataSource.length, 1, 'Users');
                    _this.setPage(1);
                }
                _this.loadingBarService.complete();
            }, function (errors) {
                _this.loadingBarService.complete();
            });
    };
    UserListComponent.prototype.clearDatas = function () {
        this.users = [];
        this.usersListDataSource = [];
        this.pager = undefined;
    };
    UserListComponent.prototype.getUserListPageLoading = function () {
        var _this = this;
        this.loadingBarService.start();
        this.dataservice.getUserListingPageLoading()
            .subscribe(function (items) {
            _this.userListAll = items;
            _this.usersListDataSource = _this.userListAll[0].GetAllUsers;
            _this.userSearchFilter = _this.userListAll[0].UserSearchCriteria;
            _this.loadingBarService.complete();
            _this.setPage(1);
            _this.pageloaded = true;
        }, function (error) {
            _this.pageloaded = true;
            _this.loadingBarService.complete();
        });
    };
    UserListComponent.prototype.pageIndexChanging = function (getPageIndex) {
        this.setPage(getPageIndex);
    };
    UserListComponent.prototype.setPage = function (page) {
        if (page < 1 || page > this.pager.totalPages) {
            return;
        }
        // get pager object from service
        this.pager = this.pagerService.getPager(this.usersListDataSource.length, page, 'Users');
        this.pager;
        // get current page of items
        this.users = this.usersListDataSource.slice(this.pager.startIndex, this.pager.endIndex + 1);
    };
    UserListComponent.prototype.sort = function (key) {
        this.sorter.sort(key, this.usersListDataSource);
        this.users = this.usersListDataSource.slice(this.pager.startIndex, this.pager.endIndex + 1);
    };
    UserListComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'users',
            templateUrl: 'user-list.component.html'
        }), 
        __metadata('design:paramtypes', [data_service_1.DataService, items_service_1.ItemsService, notification_service_1.NotificationService, ng2_slim_loading_bar_1.SlimLoadingBarService, pager_service_1.PagerService, config_service_1.ConfigService])
    ], UserListComponent);
    return UserListComponent;
}());
exports.UserListComponent = UserListComponent;
//# sourceMappingURL=user-list.component.js.map