﻿import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { NgForm } from '@angular/forms';

import { SlimLoadingBarService } from 'ng2-slim-loading-bar';
import { ModalDirective } from 'ng2-bootstrap';
import { DataService } from '../../shared/services/data-service';
import { NotificationService } from '../../shared/utils/notification-service';
import { ItemsService } from '../../shared/utils/items-service';
import { ConfigService } from '../../shared/utils/config-service';
import { ValidationService } from '../../shared/utils/validation-service';

import { IUser, IUser_Role, IUser_Preference, IUser_Role_Hierarchy_Assoication, IUser_Role_Pillar_Association, UserRole_Hierarchy_PillarLawReg_ViewModel }
    from '../../shared/interfaces';

declare var $: JQueryStatic;

@Component({
    moduleId: module.id,
    selector: 'app-user-edit',
    templateUrl: '../users/user-edit.component.html'
})
export class UserEditComponent implements OnInit {
    //Variable Declaration
    @ViewChild('childModal') public childModal: ModalDirective;
    userForm: any;

    public SelectedRole: any;
    SelectedRoleId: number;
    SelectedMSCId: number;
    SelectedInstallationId: number;

    apiHost: string;
    id: number;
    installationDataSource: any[];
    filterInstallationDatasByMSCId: any[];
    filterLawRegs: any[];
    filterProgramAreas: any[];
    firstHitValidation: boolean = false;
    hierarchyDataSource: any[];
    hierarchyData: any;
    lawRegDataSource: any[];
    mscDatas: any[];
    mscDataSource: any[];
    pillarDataSource: any[];
    programAreaDataSource: any[];
    rolesForInvite: any[];
    selectedPillar: string = "All";
    selectedLawReg: string = "All";;
    selectedProgramArea: string = "All";;
    states: any[];
    showMSC: boolean = false;
    showInstallation: boolean = false;
    userLoaded: boolean = false;
    userDataAll: any;
    userRoleHierarchyPillarLawRegViewModel: UserRole_Hierarchy_PillarLawReg_ViewModel[] = [];
    user: IUser;
    validationErrorMessageModal: string;
    validationAlertErrorVisibleModal: boolean = false;

    errMsgs: string[] = [];

    // Constructor
    constructor(private dataservice: DataService
        , private loadingBarService: SlimLoadingBarService
        , private route: ActivatedRoute
        , private router: Router
        , private notificationService: NotificationService
        , private itemsService: ItemsService
        , private configService: ConfigService
        , private formBuilder: FormBuilder
    ) {
        this.apiHost = configService.getApiHost();
        this.userForm = this.formBuilder.group({
            'email': ['', [Validators.required, ValidationService.emailValidator]],
            'firstName': ['', Validators.required],
            'lastName': ['', Validators.required]
        });
        console.log(this.userForm);
    }
    // View Init Function
    ngOnInit() {
        // '+' Converts string 'Id' to a number
        this.id = +this.route.snapshot.params['id'];
        this.loadUserDetails();
    }

    // Function After View Init
    ngAfterViewInit() {
        $('#tabsleft').bootstrapWizard({
            'tabClass': 'nav nav-tabs', 'debug': false, onShow: function (tab, navigation, index) {
            }, onNext: function (tab, navigation, index) {
            }, onPrevious: function (tab, navigation, index) {
            }, onLast: function (tab, navigation, index) {
            }, onTabClick: function (tab, navigation, index) {

            }, onTabShow: function (tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index + 1;
                var $percent = ($current / $total) * 100;
                $('#tabsleft .progress-bar').css({ width: $percent + '%' });

                // If it's the last tab then hide the last button and show the finish instead
                if ($current >= $total) {
                    $('#tabsleft').find('.pager .next').hide();
                    $('#tabsleft').find('.pager .finish').show();
                    $('#tabsleft').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#tabsleft').find('.pager .next').show();
                    $('#tabsleft').find('.pager .finish').hide();
                }
            }
        });

        $(".PhoneFormat").mask("999-999-9999");

        // Added Code for Zip Formatting Using Masked input jquery plugin
        $(".ZipFormat").mask("99999?-9999");

        $("#ZipFormatFiveDigit").mask("99999");

        // Added Code for Quantity Formatting Using Masked input jquery plugin
        $(".Quantity").mask("?99999");
    }

    backToUserListing() {
        this.router.navigate(['/users']);
    }

    closeUserRoleModal() {
        this.SelectedRoleId = undefined;
        this.SelectedRole = undefined;
        this.resetDataInModal();
        this.childModal.hide();
    }

    getSelectedRoleId(roleId: number) {
        this.validationErrorAlert('', false);
        this.SelectedRole = this.rolesForInvite.find(x => x.Id == roleId);
        this.SelectedRoleId = roleId;
        this.itemsService.removeItems<any>(this.mscDatas, x => x.Id < 0);
        this.itemsService.removeItems<any>(this.filterInstallationDatasByMSCId, x => x.Id < 0);
        this.showMSC = false;
        if (this.SelectedRole) {
            switch (this.SelectedRole.Role_Key) {
                case "MSCADMN":
                case "MSCUSER":
                case "MSCREAD":
                case "INSTADMN":
                case "INSTUSER":
                case "INSTREAD":
                    this.showMSC = true;
                    this.mscDatas = this.mscDataSource;
                    this.SelectedMSCId = undefined;
                    break;
            }
        }

    }

    getSelectedMSCId(mscId: any) {
        this.resetInstallation();
        this.validationErrorAlert('', false);
        if (mscId) {
            switch (this.SelectedRole.Role_Key) {
                case "INSTADMN":
                case "INSTUSER":
                case "INSTREAD":
                    this.showInstallation = true;
                    break;
            }
            if (this.showInstallation) {
                this.filterInstallationDatasByMSCId = this.installationDataSource.filter(x => x.Parent_Id == mscId);
            }
            this.hierarchyData = this.hierarchyDataSource.find(x => x.Id == mscId);
            this.SelectedMSCId = mscId;
        }
    }

    getSelectedInstId(instId: any) {
        if (instId) {
            this.hierarchyData = this.hierarchyDataSource.find(x => x.Id == instId);
            this.SelectedInstallationId = instId;
        }
    }

    getUserModal(): IUser {
        let userRolelist: IUser_Role[] = [];
        this.userRoleHierarchyPillarLawRegViewModel.forEach(x => {
            // Manipulation Hierarchy and Pillar LawReg Data
            let userRoleHierarchyAssoicaitonList: IUser_Role_Hierarchy_Assoication[] = [];
            let userRolePillarLawRegAssoicaitonList: IUser_Role_Pillar_Association[] = [];
            let urha: IUser_Role_Hierarchy_Assoication = {
                Id: x.User_Role_Hierarchy_Association_Id,
                Hierarchy_Data_Id: x.Hierarchy_Data_Id,
                User_Role_Id: x.User_Role_Id
            };
            let urpa: IUser_Role_Pillar_Association = {
                Id: x.User_Role_Pillar_Association_Id,
                User_Role_Id: x.User_Role_Id,
                Pillar_Id: 2000,
                Pillar_Key: x.Pillar_Key,
                LawReg_Id: 2004,
                LawReg_Key: x.LawReg_Key,
                ProgramArea_Id: 2005,
                ProgramArea_Key: x.ProgramArea_Key
            };
            // Pushing Item to array
            userRoleHierarchyAssoicaitonList.push(urha);
            userRolePillarLawRegAssoicaitonList.push(urpa);
            //Assign Hierarchy, Pillar Data into User Role
            let userRoleItem: IUser_Role = {
                Id: x.User_Role_Id,
                User_Id: this.user.Id,
                Role_Id: x.Role_Id,
                User_Role_Hierarchy_Assoication: userRoleHierarchyAssoicaitonList,
                User_Role_Pillar_Association: userRolePillarLawRegAssoicaitonList,
                User_Role_Status_Id: 1300,
                User_Role_Status_Key: x.User_Role_Status_Key
            };
            userRoleItem.User_Role_Hierarchy_Assoication = userRoleHierarchyAssoicaitonList;
            userRoleItem.User_Role_Pillar_Association = userRolePillarLawRegAssoicaitonList;
            userRolelist.push(userRoleItem);
        });
        //Assign User Role Object into User Property of User Role
        this.user.User_Role = userRolelist;
        return this.user;
    };

    loadUserDetails() {
        this.loadingBarService.start();
        this.dataservice.getUserDataAtPageLoading(this.id, 'true', 'true')
            .subscribe((items: any) => {
                this.userLoaded = true;
                this.userDataAll = items;
                this.setDataAfterViewLoading();
                this.loadingBarService.complete();
            },
            error => {
                this.loadingBarService.complete();
                this.notificationService.printErrorMessage(error);
            });
    }

    onChangePillar(pillar: any) {
        this.filterLawRegs = [];
        this.filterProgramAreas = [];
        this.filterLawRegs = this.lawRegDataSource.filter(x => x.PillarKey == pillar);
        this.filterLawRegs.forEach(x => {
            var pAreas = this.programAreaDataSource.filter(y => y.PillarKey == pillar && y.LawRegKey == x.LawRegKey);
            if (this.filterProgramAreas.length == 0) {
                this.filterProgramAreas = pAreas;
            } else {
                this.filterProgramAreas = this.filterProgramAreas.concat(pAreas);
            }
        });
    }

    onChangeLawReg(lawReg: any) {
        this.filterProgramAreas = [];
        this.filterProgramAreas = this.programAreaDataSource.filter(z => z.PillarKey == this.selectedPillar && z.LawRegKey == lawReg);
    }

    openUserRoleModal() {
        this.SelectedRoleId = undefined;
        this.resetDataInModal();
        this.childModal.show();
    }

    resetInstallation() {
        this.showInstallation = false;
        this.SelectedInstallationId = undefined;
        this.filterInstallationDatasByMSCId = [];
    }

    resetMSC() {
        this.showMSC = false;
        this.SelectedMSCId = undefined;
        this.mscDatas = [];
    }

    resetPillarLawRegProgramArea() {
        this.selectedPillar = this.selectedLawReg = this.selectedProgramArea = "All";
        this.filterLawRegs = [];
        this.filterProgramAreas = [];
    }

    resetDataInModal() {
        this.resetMSC(); this.resetInstallation();
        this.resetPillarLawRegProgramArea();
        this.validationErrorAlert('', false);
    }

    roleAssignClickInModal() {
        if (this.validationInModal() == false) return;
        let userRoleModal = new UserRole_Hierarchy_PillarLawReg_ViewModel();
        userRoleModal.User_Role_Id = 0;
        //GetRole
        let role = this.rolesForInvite.find(x => x.Id == this.SelectedRoleId);
        userRoleModal.Role_Id = role.RoleID;
        userRoleModal.Role_Name = role.Name;
        // Get Hierarchy Data
        if (role.Hierarchy_Level_Key == "HQ") {
            this.hierarchyData = this.hierarchyDataSource.find(x => x.Hierarchy_Level_Key == "HQ");
        }
        userRoleModal.Hierarchy_Data_Id = this.hierarchyData.Id;
        userRoleModal.Hierarchy_Data_Name = this.hierarchyData.Name;
        //Validate if Same Role and Hierarchy Data Already Added
        let existRolesAndProperty = this.userRoleHierarchyPillarLawRegViewModel.find(x => x.Role_Id == userRoleModal.Role_Id && x.Hierarchy_Data_Id == userRoleModal.Hierarchy_Data_Id);
        if (existRolesAndProperty != undefined) {
            this.validationErrorAlert("- Already assigned this selected role with same property.", true);
            return;
        }
        // Get Pillar 
        let pillar = this.pillarDataSource.find(x => x.PillarKey == this.selectedPillar);
        if (pillar == undefined || this.selectedPillar == "All") {
            userRoleModal.Pillar_Key = "ALL";
            userRoleModal.Pillar_Description = "All";
        } else {
            userRoleModal.Pillar_Key = pillar.PillarKey;
            userRoleModal.Pillar_Description = pillar.PillarDescription
        }
        // Get Law Reg
        let lawReg = this.lawRegDataSource.find(x => x.LawRegKey == this.selectedLawReg);
        if (lawReg == undefined || this.selectedLawReg == "All") {
            userRoleModal.LawReg_Key = "ALL";
            userRoleModal.LawReg_Description = "All";
        } else {
            userRoleModal.LawReg_Key = lawReg.LawRegKey;
            userRoleModal.LawReg_Description = lawReg.LawRegDescription;
        }
        // Get Program Area
        let programArea = this.programAreaDataSource.find(x => x.ProgramAreaKey == this.selectedProgramArea);
        if (programArea == undefined || this.selectedProgramArea == "All") {
            userRoleModal.ProgramArea_Key = "ALL";
            userRoleModal.ProgramArea_Description = "All";
        } else {
            userRoleModal.ProgramArea_Key = programArea.ProgramAreaKey;
            userRoleModal.ProgramArea_Description = programArea.ProgramAreaDescription;
        }
        userRoleModal.User_Role_Status_Key = "ACTV";
        userRoleModal.User_Role_Status_Description = "Active";
        this.userRoleHierarchyPillarLawRegViewModel.push(userRoleModal);
        //Close Modal Popup
        this.closeUserRoleModal();
    }

    setDataAfterViewLoading() {
        this.states = this.userDataAll[0].GetAllStates;
        this.user = this.itemsService.getSerialized<IUser>(this.userDataAll[0].GetUser);
        this.userRoleHierarchyPillarLawRegViewModel = this.userDataAll[0].GetUser.UserRole_Hierarchy_PillarLawReg_ViewModel;
        this.rolesForInvite = this.userDataAll[0].GetRolesForInvite;
        this.hierarchyDataSource = this.userDataAll[0].GetAllHierarchyData;
        this.mscDataSource = this.hierarchyDataSource.filter(x => x.Hierarchy_Level_Key == "MSC");
        this.installationDataSource = this.hierarchyDataSource.filter(x => x.Hierarchy_Level_Key == "INST");
        this.pillarDataSource = this.userDataAll[0].GetPillars;
        this.lawRegDataSource = this.userDataAll[0].GetLawRegs;
        this.programAreaDataSource = this.userDataAll[0].GetProgramAreas;
    }

    saveInviteUser(editUserForm: NgForm) {
        //if (this.userForm.dirty && this.userForm.valid) {
        //    alert(`Name: ${this.userForm.value.firstName} Email: ${this.userForm.value.firstName}`);
        //    return;
        //}

        this.firstHitValidation = true;
        let formControls: FormControl[] = this.userForm.controls;
        this.errMsgs = [];
        for (let fc in formControls) {
            let control = <FormArray>this.userForm.controls[fc];
            for (let propertyName in control.errors) {
                //if (control.errors.hasOwnProperty(propertyName) && control.touched) {
                //    return ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]);
                //}
                if (control.errors.hasOwnProperty(propertyName)) {
                    //return ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]);

                    //this.errMsgs.push(fc + "  " + ValidationService.getValidationErrorMessage(fc, control.errors[propertyName]));
                    this.errMsgs.push(ValidationService.getValidationErrorMessage(fc, control.errors[propertyName]));
                }
            }
        }
        console.log(this.errMsgs);
        console.log(this.user);
        //if (!this.userForm.dirty && !this.userForm.valid) {
        //    alert(`Name: ${this.userForm.value.firstName} Email: ${this.userForm.value.firstName}`);
        //    return;
        //}
        //let formControls: FormGroup = editUserForm.form.controls;
        /*this.errMsgs = [];
        for (let fc in editUserForm.form.controls) {
            let control = <FormArray>editUserForm.form.controls[fc];
            for (let propertyName in control.errors) {
                //if (control.errors.hasOwnProperty(propertyName) && control.touched) {
                //    return ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]);
                //}
                if (control.errors.hasOwnProperty(propertyName)) {
                    //return ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]);
                    this.errMsgs.push(fc + "  " + ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]));
                }
            }
        }
        console.log(this.errMsgs);*/
        if (this.validateMainPage() == false) return;
        this.loadingBarService.start();
        this.dataservice.doesUserExists(this.user.Email_Id)
            .subscribe((exists: boolean) => {
                this.loadingBarService.complete();
                if (exists) {
                    this.notificationService.printErrorMessage("- The entered User already exists in the system!Please check the User Email");
                } else {
                    this.saveUpdateUser();
                }
            },
            error => {
                this.loadingBarService.complete();
            });
    }

    saveUpdateUser() {
        if (this.validateMainPage() == false) return;
        this.loadingBarService.start();
        let userItem: IUser = this.getUserModal();
        if (this.user.Id == undefined || this.user.Id == 0) {
            userItem.User_Status_Key = 'IACT';
            userItem.User_Status_Id = 1300;
        }
        this.dataservice.createUpdateUser(userItem)
            .subscribe((userEntity) => {
                this.user = this.itemsService.getSerialized<IUser>(userEntity);
                this.userRoleHierarchyPillarLawRegViewModel = userEntity.UserRole_Hierarchy_PillarLawReg_ViewModel;
                this.loadingBarService.complete();
                this.notificationService.printSuccessMessage("User Information Saved Successfully.");
            },
            error => {
                this.loadingBarService.complete();
            });
    }

    validateMainPage(): boolean {
        if (this.userRoleHierarchyPillarLawRegViewModel == undefined || this.userRoleHierarchyPillarLawRegViewModel.length == 0) {
            this.notificationService.printErrorMessage("Please select atleast one role");
            return false;
        }
        return true;
    }

    validationInModal(): boolean {
        if (this.validatdIdField(this.SelectedRoleId) == false) {
            this.validationErrorAlert("Please select a Role to proceed.", true);
            return false;
        }
        if (this.SelectedRole != undefined) {
            if (this.SelectedRole.Hierarchy_Level_Key == 'MSC') {
                if (this.validatdIdField(this.SelectedMSCId) == false) {
                    this.validationErrorAlert("No MSC Selected Please select a MSC to proceed.", true);
                    return false;
                }
            }
            if (this.SelectedRole.Hierarchy_Level_Key == "INST") {
                if (this.validatdIdField(this.SelectedInstallationId) == false) {
                    this.validationErrorAlert("No Installation Selected Please select a Installation to proceed.", true);
                    return false;
                }
            }
        }
        return true;
    }

    validatdIdField(id: number): boolean {
        if (id == undefined || id == 0) return false;
        return true;
    }

    validationErrorAlert(message: string, visible: boolean) {
        this.validationAlertErrorVisibleModal = visible;
        this.validationErrorMessageModal = message;
    }
}
