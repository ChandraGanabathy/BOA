"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var forms_1 = require('@angular/forms');
var ng2_slim_loading_bar_1 = require('ng2-slim-loading-bar');
var ng2_bootstrap_1 = require('ng2-bootstrap');
var data_service_1 = require('../../shared/services/data-service');
var notification_service_1 = require('../../shared/utils/notification-service');
var items_service_1 = require('../../shared/utils/items-service');
var config_service_1 = require('../../shared/utils/config-service');
var validation_service_1 = require('../../shared/utils/validation-service');
var interfaces_1 = require('../../shared/interfaces');
var UserEditComponent = (function () {
    // Constructor
    function UserEditComponent(dataservice, loadingBarService, route, router, notificationService, itemsService, configService, formBuilder) {
        this.dataservice = dataservice;
        this.loadingBarService = loadingBarService;
        this.route = route;
        this.router = router;
        this.notificationService = notificationService;
        this.itemsService = itemsService;
        this.configService = configService;
        this.formBuilder = formBuilder;
        this.firstHitValidation = false;
        this.selectedPillar = "All";
        this.selectedLawReg = "All";
        this.selectedProgramArea = "All";
        this.showMSC = false;
        this.showInstallation = false;
        this.userLoaded = false;
        this.userRoleHierarchyPillarLawRegViewModel = [];
        this.validationAlertErrorVisibleModal = false;
        this.errMsgs = [];
        this.apiHost = configService.getApiHost();
        this.userForm = this.formBuilder.group({
            'email': ['', [forms_1.Validators.required, validation_service_1.ValidationService.emailValidator]],
            'firstName': ['', forms_1.Validators.required],
            'lastName': ['', forms_1.Validators.required]
        });
        console.log(this.userForm);
    }
    ;
    ;
    // View Init Function
    UserEditComponent.prototype.ngOnInit = function () {
        // '+' Converts string 'Id' to a number
        this.id = +this.route.snapshot.params['id'];
        this.loadUserDetails();
    };
    // Function After View Init
    UserEditComponent.prototype.ngAfterViewInit = function () {
        $('#tabsleft').bootstrapWizard({
            'tabClass': 'nav nav-tabs', 'debug': false, onShow: function (tab, navigation, index) {
            }, onNext: function (tab, navigation, index) {
            }, onPrevious: function (tab, navigation, index) {
            }, onLast: function (tab, navigation, index) {
            }, onTabClick: function (tab, navigation, index) {
            }, onTabShow: function (tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index + 1;
                var $percent = ($current / $total) * 100;
                $('#tabsleft .progress-bar').css({ width: $percent + '%' });
                // If it's the last tab then hide the last button and show the finish instead
                if ($current >= $total) {
                    $('#tabsleft').find('.pager .next').hide();
                    $('#tabsleft').find('.pager .finish').show();
                    $('#tabsleft').find('.pager .finish').removeClass('disabled');
                }
                else {
                    $('#tabsleft').find('.pager .next').show();
                    $('#tabsleft').find('.pager .finish').hide();
                }
            }
        });
        $(".PhoneFormat").mask("999-999-9999");
        // Added Code for Zip Formatting Using Masked input jquery plugin
        $(".ZipFormat").mask("99999?-9999");
        $("#ZipFormatFiveDigit").mask("99999");
        // Added Code for Quantity Formatting Using Masked input jquery plugin
        $(".Quantity").mask("?99999");
    };
    UserEditComponent.prototype.backToUserListing = function () {
        this.router.navigate(['/users']);
    };
    UserEditComponent.prototype.closeUserRoleModal = function () {
        this.SelectedRoleId = undefined;
        this.SelectedRole = undefined;
        this.resetDataInModal();
        this.childModal.hide();
    };
    UserEditComponent.prototype.getSelectedRoleId = function (roleId) {
        this.validationErrorAlert('', false);
        this.SelectedRole = this.rolesForInvite.find(function (x) { return x.Id == roleId; });
        this.SelectedRoleId = roleId;
        this.itemsService.removeItems(this.mscDatas, function (x) { return x.Id < 0; });
        this.itemsService.removeItems(this.filterInstallationDatasByMSCId, function (x) { return x.Id < 0; });
        this.showMSC = false;
        if (this.SelectedRole) {
            switch (this.SelectedRole.Role_Key) {
                case "MSCADMN":
                case "MSCUSER":
                case "MSCREAD":
                case "INSTADMN":
                case "INSTUSER":
                case "INSTREAD":
                    this.showMSC = true;
                    this.mscDatas = this.mscDataSource;
                    this.SelectedMSCId = undefined;
                    break;
            }
        }
    };
    UserEditComponent.prototype.getSelectedMSCId = function (mscId) {
        this.resetInstallation();
        this.validationErrorAlert('', false);
        if (mscId) {
            switch (this.SelectedRole.Role_Key) {
                case "INSTADMN":
                case "INSTUSER":
                case "INSTREAD":
                    this.showInstallation = true;
                    break;
            }
            if (this.showInstallation) {
                this.filterInstallationDatasByMSCId = this.installationDataSource.filter(function (x) { return x.Parent_Id == mscId; });
            }
            this.hierarchyData = this.hierarchyDataSource.find(function (x) { return x.Id == mscId; });
            this.SelectedMSCId = mscId;
        }
    };
    UserEditComponent.prototype.getSelectedInstId = function (instId) {
        if (instId) {
            this.hierarchyData = this.hierarchyDataSource.find(function (x) { return x.Id == instId; });
            this.SelectedInstallationId = instId;
        }
    };
    UserEditComponent.prototype.getUserModal = function () {
        var _this = this;
        var userRolelist = [];
        this.userRoleHierarchyPillarLawRegViewModel.forEach(function (x) {
            // Manipulation Hierarchy and Pillar LawReg Data
            var userRoleHierarchyAssoicaitonList = [];
            var userRolePillarLawRegAssoicaitonList = [];
            var urha = {
                Id: x.User_Role_Hierarchy_Association_Id,
                Hierarchy_Data_Id: x.Hierarchy_Data_Id,
                User_Role_Id: x.User_Role_Id
            };
            var urpa = {
                Id: x.User_Role_Pillar_Association_Id,
                User_Role_Id: x.User_Role_Id,
                Pillar_Id: 2000,
                Pillar_Key: x.Pillar_Key,
                LawReg_Id: 2004,
                LawReg_Key: x.LawReg_Key,
                ProgramArea_Id: 2005,
                ProgramArea_Key: x.ProgramArea_Key
            };
            // Pushing Item to array
            userRoleHierarchyAssoicaitonList.push(urha);
            userRolePillarLawRegAssoicaitonList.push(urpa);
            //Assign Hierarchy, Pillar Data into User Role
            var userRoleItem = {
                Id: x.User_Role_Id,
                User_Id: _this.user.Id,
                Role_Id: x.Role_Id,
                User_Role_Hierarchy_Assoication: userRoleHierarchyAssoicaitonList,
                User_Role_Pillar_Association: userRolePillarLawRegAssoicaitonList,
                User_Role_Status_Id: 1300,
                User_Role_Status_Key: x.User_Role_Status_Key
            };
            userRoleItem.User_Role_Hierarchy_Assoication = userRoleHierarchyAssoicaitonList;
            userRoleItem.User_Role_Pillar_Association = userRolePillarLawRegAssoicaitonList;
            userRolelist.push(userRoleItem);
        });
        //Assign User Role Object into User Property of User Role
        this.user.User_Role = userRolelist;
        return this.user;
    };
    ;
    UserEditComponent.prototype.loadUserDetails = function () {
        var _this = this;
        this.loadingBarService.start();
        this.dataservice.getUserDataAtPageLoading(this.id, 'true', 'true')
            .subscribe(function (items) {
            _this.userLoaded = true;
            _this.userDataAll = items;
            _this.setDataAfterViewLoading();
            _this.loadingBarService.complete();
        }, function (error) {
            _this.loadingBarService.complete();
            _this.notificationService.printErrorMessage(error);
        });
    };
    UserEditComponent.prototype.onChangePillar = function (pillar) {
        var _this = this;
        this.filterLawRegs = [];
        this.filterProgramAreas = [];
        this.filterLawRegs = this.lawRegDataSource.filter(function (x) { return x.PillarKey == pillar; });
        this.filterLawRegs.forEach(function (x) {
            var pAreas = _this.programAreaDataSource.filter(function (y) { return y.PillarKey == pillar && y.LawRegKey == x.LawRegKey; });
            if (_this.filterProgramAreas.length == 0) {
                _this.filterProgramAreas = pAreas;
            }
            else {
                _this.filterProgramAreas = _this.filterProgramAreas.concat(pAreas);
            }
        });
    };
    UserEditComponent.prototype.onChangeLawReg = function (lawReg) {
        var _this = this;
        this.filterProgramAreas = [];
        this.filterProgramAreas = this.programAreaDataSource.filter(function (z) { return z.PillarKey == _this.selectedPillar && z.LawRegKey == lawReg; });
    };
    UserEditComponent.prototype.openUserRoleModal = function () {
        this.SelectedRoleId = undefined;
        this.resetDataInModal();
        this.childModal.show();
    };
    UserEditComponent.prototype.resetInstallation = function () {
        this.showInstallation = false;
        this.SelectedInstallationId = undefined;
        this.filterInstallationDatasByMSCId = [];
    };
    UserEditComponent.prototype.resetMSC = function () {
        this.showMSC = false;
        this.SelectedMSCId = undefined;
        this.mscDatas = [];
    };
    UserEditComponent.prototype.resetPillarLawRegProgramArea = function () {
        this.selectedPillar = this.selectedLawReg = this.selectedProgramArea = "All";
        this.filterLawRegs = [];
        this.filterProgramAreas = [];
    };
    UserEditComponent.prototype.resetDataInModal = function () {
        this.resetMSC();
        this.resetInstallation();
        this.resetPillarLawRegProgramArea();
        this.validationErrorAlert('', false);
    };
    UserEditComponent.prototype.roleAssignClickInModal = function () {
        var _this = this;
        if (this.validationInModal() == false)
            return;
        var userRoleModal = new interfaces_1.UserRole_Hierarchy_PillarLawReg_ViewModel();
        userRoleModal.User_Role_Id = 0;
        //GetRole
        var role = this.rolesForInvite.find(function (x) { return x.Id == _this.SelectedRoleId; });
        userRoleModal.Role_Id = role.RoleID;
        userRoleModal.Role_Name = role.Name;
        // Get Hierarchy Data
        if (role.Hierarchy_Level_Key == "HQ") {
            this.hierarchyData = this.hierarchyDataSource.find(function (x) { return x.Hierarchy_Level_Key == "HQ"; });
        }
        userRoleModal.Hierarchy_Data_Id = this.hierarchyData.Id;
        userRoleModal.Hierarchy_Data_Name = this.hierarchyData.Name;
        //Validate if Same Role and Hierarchy Data Already Added
        var existRolesAndProperty = this.userRoleHierarchyPillarLawRegViewModel.find(function (x) { return x.Role_Id == userRoleModal.Role_Id && x.Hierarchy_Data_Id == userRoleModal.Hierarchy_Data_Id; });
        if (existRolesAndProperty != undefined) {
            this.validationErrorAlert("- Already assigned this selected role with same property.", true);
            return;
        }
        // Get Pillar 
        var pillar = this.pillarDataSource.find(function (x) { return x.PillarKey == _this.selectedPillar; });
        if (pillar == undefined || this.selectedPillar == "All") {
            userRoleModal.Pillar_Key = "ALL";
            userRoleModal.Pillar_Description = "All";
        }
        else {
            userRoleModal.Pillar_Key = pillar.PillarKey;
            userRoleModal.Pillar_Description = pillar.PillarDescription;
        }
        // Get Law Reg
        var lawReg = this.lawRegDataSource.find(function (x) { return x.LawRegKey == _this.selectedLawReg; });
        if (lawReg == undefined || this.selectedLawReg == "All") {
            userRoleModal.LawReg_Key = "ALL";
            userRoleModal.LawReg_Description = "All";
        }
        else {
            userRoleModal.LawReg_Key = lawReg.LawRegKey;
            userRoleModal.LawReg_Description = lawReg.LawRegDescription;
        }
        // Get Program Area
        var programArea = this.programAreaDataSource.find(function (x) { return x.ProgramAreaKey == _this.selectedProgramArea; });
        if (programArea == undefined || this.selectedProgramArea == "All") {
            userRoleModal.ProgramArea_Key = "ALL";
            userRoleModal.ProgramArea_Description = "All";
        }
        else {
            userRoleModal.ProgramArea_Key = programArea.ProgramAreaKey;
            userRoleModal.ProgramArea_Description = programArea.ProgramAreaDescription;
        }
        userRoleModal.User_Role_Status_Key = "ACTV";
        userRoleModal.User_Role_Status_Description = "Active";
        this.userRoleHierarchyPillarLawRegViewModel.push(userRoleModal);
        //Close Modal Popup
        this.closeUserRoleModal();
    };
    UserEditComponent.prototype.setDataAfterViewLoading = function () {
        this.states = this.userDataAll[0].GetAllStates;
        this.user = this.itemsService.getSerialized(this.userDataAll[0].GetUser);
        this.userRoleHierarchyPillarLawRegViewModel = this.userDataAll[0].GetUser.UserRole_Hierarchy_PillarLawReg_ViewModel;
        this.rolesForInvite = this.userDataAll[0].GetRolesForInvite;
        this.hierarchyDataSource = this.userDataAll[0].GetAllHierarchyData;
        this.mscDataSource = this.hierarchyDataSource.filter(function (x) { return x.Hierarchy_Level_Key == "MSC"; });
        this.installationDataSource = this.hierarchyDataSource.filter(function (x) { return x.Hierarchy_Level_Key == "INST"; });
        this.pillarDataSource = this.userDataAll[0].GetPillars;
        this.lawRegDataSource = this.userDataAll[0].GetLawRegs;
        this.programAreaDataSource = this.userDataAll[0].GetProgramAreas;
    };
    UserEditComponent.prototype.saveInviteUser = function (editUserForm) {
        //if (this.userForm.dirty && this.userForm.valid) {
        //    alert(`Name: ${this.userForm.value.firstName} Email: ${this.userForm.value.firstName}`);
        //    return;
        //}
        var _this = this;
        this.firstHitValidation = true;
        var formControls = this.userForm.controls;
        this.errMsgs = [];
        for (var fc in formControls) {
            var control = this.userForm.controls[fc];
            for (var propertyName in control.errors) {
                //if (control.errors.hasOwnProperty(propertyName) && control.touched) {
                //    return ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]);
                //}
                if (control.errors.hasOwnProperty(propertyName)) {
                    //return ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]);
                    //this.errMsgs.push(fc + "  " + ValidationService.getValidationErrorMessage(fc, control.errors[propertyName]));
                    this.errMsgs.push(validation_service_1.ValidationService.getValidationErrorMessage(fc, control.errors[propertyName]));
                }
            }
        }
        console.log(this.errMsgs);
        console.log(this.user);
        //if (!this.userForm.dirty && !this.userForm.valid) {
        //    alert(`Name: ${this.userForm.value.firstName} Email: ${this.userForm.value.firstName}`);
        //    return;
        //}
        //let formControls: FormGroup = editUserForm.form.controls;
        /*this.errMsgs = [];
        for (let fc in editUserForm.form.controls) {
            let control = <FormArray>editUserForm.form.controls[fc];
            for (let propertyName in control.errors) {
                //if (control.errors.hasOwnProperty(propertyName) && control.touched) {
                //    return ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]);
                //}
                if (control.errors.hasOwnProperty(propertyName)) {
                    //return ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]);
                    this.errMsgs.push(fc + "  " + ValidationService.getValidationErrorMessage(propertyName, control.errors[propertyName]));
                }
            }
        }
        console.log(this.errMsgs);*/
        if (this.validateMainPage() == false)
            return;
        this.loadingBarService.start();
        this.dataservice.doesUserExists(this.user.Email_Id)
            .subscribe(function (exists) {
            _this.loadingBarService.complete();
            if (exists) {
                _this.notificationService.printErrorMessage("- The entered User already exists in the system!Please check the User Email");
            }
            else {
                _this.saveUpdateUser();
            }
        }, function (error) {
            _this.loadingBarService.complete();
        });
    };
    UserEditComponent.prototype.saveUpdateUser = function () {
        var _this = this;
        if (this.validateMainPage() == false)
            return;
        this.loadingBarService.start();
        var userItem = this.getUserModal();
        if (this.user.Id == undefined || this.user.Id == 0) {
            userItem.User_Status_Key = 'IACT';
            userItem.User_Status_Id = 1300;
        }
        this.dataservice.createUpdateUser(userItem)
            .subscribe(function (userEntity) {
            _this.user = _this.itemsService.getSerialized(userEntity);
            _this.userRoleHierarchyPillarLawRegViewModel = userEntity.UserRole_Hierarchy_PillarLawReg_ViewModel;
            _this.loadingBarService.complete();
            _this.notificationService.printSuccessMessage("User Information Saved Successfully.");
        }, function (error) {
            _this.loadingBarService.complete();
        });
    };
    UserEditComponent.prototype.validateMainPage = function () {
        if (this.userRoleHierarchyPillarLawRegViewModel == undefined || this.userRoleHierarchyPillarLawRegViewModel.length == 0) {
            this.notificationService.printErrorMessage("Please select atleast one role");
            return false;
        }
        return true;
    };
    UserEditComponent.prototype.validationInModal = function () {
        if (this.validatdIdField(this.SelectedRoleId) == false) {
            this.validationErrorAlert("Please select a Role to proceed.", true);
            return false;
        }
        if (this.SelectedRole != undefined) {
            if (this.SelectedRole.Hierarchy_Level_Key == 'MSC') {
                if (this.validatdIdField(this.SelectedMSCId) == false) {
                    this.validationErrorAlert("No MSC Selected Please select a MSC to proceed.", true);
                    return false;
                }
            }
            if (this.SelectedRole.Hierarchy_Level_Key == "INST") {
                if (this.validatdIdField(this.SelectedInstallationId) == false) {
                    this.validationErrorAlert("No Installation Selected Please select a Installation to proceed.", true);
                    return false;
                }
            }
        }
        return true;
    };
    UserEditComponent.prototype.validatdIdField = function (id) {
        if (id == undefined || id == 0)
            return false;
        return true;
    };
    UserEditComponent.prototype.validationErrorAlert = function (message, visible) {
        this.validationAlertErrorVisibleModal = visible;
        this.validationErrorMessageModal = message;
    };
    __decorate([
        core_1.ViewChild('childModal'), 
        __metadata('design:type', ng2_bootstrap_1.ModalDirective)
    ], UserEditComponent.prototype, "childModal", void 0);
    UserEditComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'app-user-edit',
            templateUrl: '../users/user-edit.component.html'
        }), 
        __metadata('design:paramtypes', [data_service_1.DataService, ng2_slim_loading_bar_1.SlimLoadingBarService, router_1.ActivatedRoute, router_1.Router, notification_service_1.NotificationService, items_service_1.ItemsService, config_service_1.ConfigService, forms_1.FormBuilder])
    ], UserEditComponent);
    return UserEditComponent;
}());
exports.UserEditComponent = UserEditComponent;
//# sourceMappingURL=user-edit.component.js.map