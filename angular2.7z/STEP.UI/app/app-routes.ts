import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from '../app/modules/home/home.component';
import { UserListComponent } from '../app/modules/users/user-list.component';
import { UserEditComponent } from '../app/modules/users/user-edit.component';

const appRoutes: Routes = [
    { path: '', component: HomeComponent },
    //{ path: '**', component: HomeComponent },
    { path: 'Home/Index', component: HomeComponent },
    { path: 'home', component: HomeComponent },
    { path: 'users', component: UserListComponent },
    { path: 'users/:id/edit', component: UserEditComponent },
    { path: 'users/:id/save', component: UserEditComponent }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes, { useHash: true });
