"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var ng2_bootstrap_1 = require('ng2-bootstrap');
var config_service_1 = require('./shared/utils/config-service');
var data_service_1 = require('./shared/services/data-service');
var items_service_1 = require('./shared/utils/items-service');
var pubsubService_1 = require('./shared/services/abstract/pubsubService');
// Add the Rxjs for observable
require('./rxjs-operators');
core_1.enableProdMode();
var AppComponent = (function () {
    function AppComponent(viewContainerRef, configService, dataService, itemsService, pubSubService) {
        this.viewContainerRef = viewContainerRef;
        this.configService = configService;
        this.dataService = dataService;
        this.itemsService = itemsService;
        this.pubSubService = pubSubService;
        this.pageLoaded = false;
        this.showLoader = false;
        // You need this small hack in order to catch application root view container ref
        this.viewContainerRef = viewContainerRef;
        this.apiHost = configService.getApiHost();
        this._pubsub = pubSubService;
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dataService.getSessionsData()
            .subscribe(function (result) {
            _this.sessionDatas = result;
            if (_this.sessionDatas != undefined) {
                _this.sessionActions = _this.sessionDatas[0].SessionActions;
                _this.currentUser = _this.itemsService.getSerialized(_this.sessionDatas[0].CurrentUser);
                _this.currentUserRole = _this.itemsService.getSerialized(_this.sessionDatas[0].CurrentUserRole);
                if (_this.currentUserRole != null && _this.currentUserRole.Role != null) {
                    _this.userDisplayName = _this.currentUser.First_Name + " " + _this.currentUser.Last_Name + " (" + _this.currentUserRole.Role.Name + ")";
                }
                else {
                    _this.userDisplayName = _this.currentUser.First_Name + " " + _this.currentUser.Last_Name;
                }
            }
            _this.pageLoaded = true;
        }, function (error) {
        });
    };
    AppComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        this._pubsub.beforeRequest.subscribe(function (data) {
            _this.showLoader = true;
            _this.spinnerModel.show();
        });
        this._pubsub.afterRequest.subscribe(function (data) {
            _this.showLoader = false;
            _this.spinnerModel.hide();
        });
    };
    AppComponent.prototype.logOut = function () {
        window.location.href = this.configService.getApiHost() + "/UserManagement/SignOut/";
    };
    AppComponent.prototype.showPage = function (controllerName, actionName, typeKey) {
        return this.sessionActions.find(function (x) { return x.Controller_Name == controllerName && x.Action_Name == actionName && x.Type_Key == typeKey; }) != undefined;
    };
    __decorate([
        core_1.ViewChild('spinnerModel'), 
        __metadata('design:type', ng2_bootstrap_1.ModalDirective)
    ], AppComponent.prototype, "spinnerModel", void 0);
    AppComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'step-app',
            templateUrl: 'app.component.html'
        }), 
        __metadata('design:paramtypes', [core_1.ViewContainerRef, config_service_1.ConfigService, data_service_1.DataService, items_service_1.ItemsService, pubsubService_1.PubSubService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map