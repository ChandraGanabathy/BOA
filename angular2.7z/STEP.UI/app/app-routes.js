"use strict";
var router_1 = require('@angular/router');
var home_component_1 = require('../app/modules/home/home.component');
var user_list_component_1 = require('../app/modules/users/user-list.component');
var user_edit_component_1 = require('../app/modules/users/user-edit.component');
var appRoutes = [
    { path: '', component: home_component_1.HomeComponent },
    //{ path: '**', component: HomeComponent },
    { path: 'Home/Index', component: home_component_1.HomeComponent },
    { path: 'home', component: home_component_1.HomeComponent },
    { path: 'users', component: user_list_component_1.UserListComponent },
    { path: 'users/:id/edit', component: user_edit_component_1.UserEditComponent },
    { path: 'users/:id/save', component: user_edit_component_1.UserEditComponent }
];
exports.routing = router_1.RouterModule.forRoot(appRoutes, { useHash: true });
//# sourceMappingURL=app-routes.js.map