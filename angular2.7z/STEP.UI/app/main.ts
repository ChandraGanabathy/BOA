import {platformBrowserDynamic  } from '@angular/platform-browser-dynamic';
import { AppModule } from './app-module';
//import { LocationStrategy, HashLocationStrategy, APP_BASE_HREF } from '@angular/common';
platformBrowserDynamic().bootstrapModule(AppModule);
