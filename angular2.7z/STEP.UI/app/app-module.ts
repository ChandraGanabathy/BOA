import './rxjs-operators';

import { NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http, XHRBackend, RequestOptions } from '@angular/http';
import { LocationStrategy, APP_BASE_HREF, PathLocationStrategy } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { PaginationModule } from 'ng2-bootstrap/ng2-bootstrap';
import { DatepickerModule } from 'ng2-bootstrap/ng2-bootstrap';
import { Ng2BootstrapModule } from 'ng2-bootstrap/ng2-bootstrap';
import { ModalModule } from 'ng2-bootstrap/ng2-bootstrap';
import { ProgressbarModule } from 'ng2-bootstrap/ng2-bootstrap';
import { SlimLoadingBarService, SlimLoadingBarComponent } from 'ng2-slim-loading-bar';
import { TimepickerModule } from 'ng2-bootstrap/ng2-bootstrap';

import { AppComponent } from '../app/app.component';
import { UserListComponent } from '../app/modules/users/user-list.component';
import { UserEditComponent } from '../app/modules/users/user-edit.component';
import { HomeComponent } from '../app/modules/home/home.component';
import { routing } from '../app/app-routes';

import { ControlMessageComponent } from './shared/messages/control-message';
import { PaginationComponent } from './shared/pagination/pagination.component';
import { DatepickerComponent } from "./shared/ng2-datepicker/datepicker.component";

import { DataService } from '../app/shared/services/data-service';
import { ConfigService } from '../app/shared/utils/config-service';
import { ItemsService } from '../app/shared/utils/items-service';
import { NotificationService } from './shared/utils/notification-service';
import { ValidationService } from './shared/utils/validation-service';
import { PagerService } from './shared/utils/pager.service';
import { CustomHttp } from '../app/shared/services/abstract/customhttp'
import { PubSubService } from '../app/shared/services/abstract/pubsubService'

enableProdMode();

@NgModule({
    imports: [
        BrowserModule, DatepickerModule, FormsModule, HttpModule, Ng2BootstrapModule
        , ModalModule, ProgressbarModule, PaginationModule, routing, TimepickerModule
        , ReactiveFormsModule
    ],
    declarations: [
        AppComponent, HomeComponent, SlimLoadingBarComponent, UserListComponent, UserEditComponent
        , ControlMessageComponent, PaginationComponent, DatepickerComponent
    ],
    providers: [
        { provide: LocationStrategy, useClass: PathLocationStrategy },
        ConfigService, DataService, ItemsService, NotificationService, SlimLoadingBarService, ValidationService, PagerService, PubSubService
        ,
        {
            provide: Http
            , useFactory: (backend: XHRBackend, defaultOptions: RequestOptions, pubsub: PubSubService) => new CustomHttp(backend, defaultOptions, pubsub)
            , deps: [XHRBackend, RequestOptions, PubSubService]
        },
        /*{
            provide: Http
            , useFactory: (backend: XHRBackend, defaultOptions: RequestOptions, globalService: GlobalService) => new HttpLoading(backend, defaultOptions, globalService)
            , deps: [XHRBackend, RequestOptions, GlobalService]
        },*/
    ],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule {

}


