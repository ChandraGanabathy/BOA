"use strict";
var UserSearchFilter = (function () {
    function UserSearchFilter() {
    }
    return UserSearchFilter;
}());
exports.UserSearchFilter = UserSearchFilter;
//# sourceMappingURL=search-filter.js.map