﻿export class UserSearchFilter {
    FirstName: string;
    LastName: string;
    Email: string;
    Status: string;
    RoleId?: number;
}