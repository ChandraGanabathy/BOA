﻿import { Component, OnInit, ViewContainerRef, enableProdMode, AfterViewInit, ViewChild } from '@angular/core';
//import { Location, LocationStrategy, HashLocationStrategy } from '@angular/common';
import { HttpModule, Http } from '@angular/http'
import { ModalDirective } from 'ng2-bootstrap';

import { ConfigService } from './shared/utils/config-service';
import { DataService } from './shared/services/data-service';
import { ItemsService } from './shared/utils/items-service';
import { IAction, IUser, IUser_Role } from './shared/interfaces';
import { PubSubService } from './shared/services/abstract/pubsubService';
// Add the Rxjs for observable
import './rxjs-operators';
enableProdMode();
@Component({
    moduleId: module.id,
    selector: 'step-app',
    templateUrl: 'app.component.html'
    /*providers: [
        Http, HttpModule,
        { provide: LocationStrategy, useClass: HashLocationStrategy }]*/
})

export class AppComponent implements OnInit, AfterViewInit {
    @ViewChild('spinnerModel') public spinnerModel: ModalDirective;
    apiHost: string;
    currentUser: IUser;
    currentUserRole: any;
    pageLoaded: boolean = false;
    sessionDatas: any;
    sessionActions: IAction[];
    userDisplayName: string;
    showLoader = false;
    _pubsub: PubSubService;
    constructor(private viewContainerRef: ViewContainerRef
        , private configService: ConfigService
        , private dataService: DataService
        , private itemsService: ItemsService
        , private pubSubService: PubSubService
    ) {
        // You need this small hack in order to catch application root view container ref
        this.viewContainerRef = viewContainerRef;
        this.apiHost = configService.getApiHost();
        this._pubsub = pubSubService;
    }
    ngOnInit() {
        this.dataService.getSessionsData()
            .subscribe((result: any) => {
                this.sessionDatas = result;
                if (this.sessionDatas != undefined) {
                    this.sessionActions = this.sessionDatas[0].SessionActions;
                    this.currentUser = this.itemsService.getSerialized<IUser>(this.sessionDatas[0].CurrentUser);
                    this.currentUserRole = this.itemsService.getSerialized<IUser_Role>(this.sessionDatas[0].CurrentUserRole);
                    if (this.currentUserRole != null && this.currentUserRole.Role != null) {
                        this.userDisplayName = this.currentUser.First_Name + " " + this.currentUser.Last_Name + " (" + this.currentUserRole.Role.Name + ")";
                    } else {
                        this.userDisplayName = this.currentUser.First_Name + " " + this.currentUser.Last_Name;
                    }

                }
                this.pageLoaded = true;
            },
            error => {
            });
    }

    ngAfterViewInit() {
        this._pubsub.beforeRequest.subscribe(data => {
            this.showLoader = true
            this.spinnerModel.show();
        });
        this._pubsub.afterRequest.subscribe(data => {
            this.showLoader = false
            this.spinnerModel.hide();
        });
    }

    logOut() {
        window.location.href = this.configService.getApiHost() + "/UserManagement/SignOut/";
    }
    showPage(controllerName: string, actionName: string, typeKey: string) {
        return this.sessionActions.find(x => x.Controller_Name == controllerName && x.Action_Name == actionName && x.Type_Key == typeKey) != undefined;
    }
}
