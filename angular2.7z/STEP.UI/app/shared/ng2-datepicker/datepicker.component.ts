import { Component, AfterViewChecked, EventEmitter, Output, Input } from '@angular/core';
import { ConfigService} from '../utils/config-service';
@Component({
    moduleId: module.id,
    selector: 'ng2-datepicker',
    templateUrl: 'datepicker.component.html',
})
export class DatepickerComponent implements AfterViewChecked {
    @Input() ID: string;
    @Output() dateSelected: EventEmitter<string> = new EventEmitter();
    private date: string;
    private apiHost: string;
    constructor(private configService: ConfigService) {
        this.apiHost = configService.getApiHost();
    }
    ngAfterViewChecked(): void {
        let datepickerElement = $('#' + this.ID);        
        datepickerElement.datetimepicker({
            format: 'MM/DD/YYYY',
            icons: {
                previous: 'glyphicon-chevron-left',
                next: 'glyphicon-chevron-right',
            },
        });
        datepickerElement.on('dp.change', (e: any) => {
            this.date = e.date;
            this.dateSelected.emit(this.date);
        });
    }
}
