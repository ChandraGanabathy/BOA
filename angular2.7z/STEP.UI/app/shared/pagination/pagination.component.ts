﻿import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { PagerService } from '../utils/pager.service';

@Component({
    moduleId: module.id,
    selector: 'pagination',
    templateUrl: 'pagination.component.html'
})
export class PaginationComponent {
    @Input() pager: any;
    @Output() setPageIndex = new EventEmitter();
    //@Output() cry: EventEmitter<number> = new EventEmitter<number>();    
    constructor() {

    }
    setPage(index: number) {
        this.setPageIndex.next(index);
    }
}