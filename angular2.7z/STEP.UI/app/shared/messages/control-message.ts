﻿import { Component, Input } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';

import { ValidationService } from '../utils/validation-service';

@Component({
    selector: 'control-messages',
    //template: `<div *ngIf="errorMessage !== null">{{errorMessage}}</div>`
    template: `<div *ngIf="errorMessage !== null">{{errorMessage}}</div> <div class="alert alert-danger" *ngIf="errorsMessage.length>0">
<strong>
    <ul *ngFor="let r of errorsMessage">
        <li><i>{{r}}</i></li>
    </ul></strong>
</div>`
})

export class ControlMessageComponent {
    //@Input() control: FormControl;
    @Input() errorsMessage: string[];
    constructor() {

    }

    //get errorMessage() {
    //    for (let propertyName in this.control.errors) {
    //        if (this.control.errors.hasOwnProperty(propertyName) && this.control.touched) {
    //            return ValidationService.getValidationErrorMessage(propertyName, this.control.errors[propertyName]);
    //        }
    //    }
    //    return null;
    //}
}