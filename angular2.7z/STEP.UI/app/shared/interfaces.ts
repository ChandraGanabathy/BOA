export interface IUser {
    Id: number;
    Email_Id: string;
    Title: string;
    First_Name: string;
    Middle_Name: string;
    Last_Name: string;
    Password: string;
    Address_Line1: string;
    Address_Line2: string;
    City: string;
    State_Id: number;
    State_Key: string;
    Zip: string;
    Phone: string;
    Organization: string;
    User_Status_Id: number;
    User_Status_Key: string;
    IsLoginSucessed: boolean;
    Message: string;
    User_Role: IUser_Role[];
    User_Preference: IUser_Preference[];
    UserRole_Hierarchy_PillarLawReg_ViewModel: UserRole_Hierarchy_PillarLawReg_ViewModel[];
}

export interface IUser_Role {
    Id: number;
    User_Id: number;
    Role_Id: number;
    User_Role_Status_Id: number;
    User_Role_Status_Key: string;
    User_Role_Hierarchy_Assoication: IUser_Role_Hierarchy_Assoication[];
    User_Role_Pillar_Association: IUser_Role_Pillar_Association[];
}

export interface IUser_Role_Hierarchy_Assoication {
    Id: number;
    Hierarchy_Data_Id: number;
    User_Role_Id: number;
}

export interface IUser_Role_Pillar_Association {
    Id: number;
    User_Role_Id: number;
    Pillar_Id: number;
    Pillar_Key: string;
    LawReg_Id: number;
    LawReg_Key: string;
    ProgramArea_Id: number;
    ProgramArea_Key: string;
}

export interface IUser_Preference {
    Id: number;
    User_Id: number;
    Theme_Id: number;
    Theme_Key: string;
    Page_Size_Id: number;
    Page_Size_Key: number;
}

export class UserRole_Hierarchy_PillarLawReg_ViewModel {
    Role_Id: number;
    Role_Name: string
    User_Role_Id: number;
    User_Role_Status_Key: string
    User_Role_Status_Description: string
    User_Role_Hierarchy_Association_Id: number;
    Hierarchy_Data_Id?: number;
    Hierarchy_Data_Name: string;
    User_Role_Pillar_Association_Id: number;
    Pillar_Key: string
    Pillar_Description: string
    LawReg_Key: string
    LawReg_Description: string
    ProgramArea_Key: string
    ProgramArea_Description: string
}

export interface IAction {
    Id: number;
    Action_Name: string;
    Action_Description: string;
    Controller_Name: string;
    Type_Id: number;
    Type_Key: string;
}

export interface Pagination {
    CurrentPage: number;
    ItemsPerPage: number;
    TotalItems: number;
    TotalPages: number;
}

export class PaginatedResult<T>{
    result: T;
    pagination: Pagination;
}

export interface Predicate<T> {
    (item: T): boolean;
}
