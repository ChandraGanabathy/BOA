"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var MobileHideDirective = (function () {
    function MobileHideDirective(el) {
        this._defaultMaxWidth = 768;
        this.el = el.nativeElement;
    }
    MobileHideDirective.prototype.onResize = function (event) {
        var window = event.target;
        var currentWidth = window.innerWidth;
        if (currentWidth < (this.mobileHide || this._defaultMaxWidth)) {
            this.el.style.display = 'none';
        }
        else {
            this.el.style.display = 'block';
        }
    };
    __decorate([
        core_1.Input('mobileHide'), 
        __metadata('design:type', Number)
    ], MobileHideDirective.prototype, "mobileHide", void 0);
    MobileHideDirective = __decorate([
        core_1.Directive({
            selector: '[mobileHide]',
            host: {
                '(window:resize)': 'onResize($event)'
            }
        }), 
        __metadata('design:paramtypes', [core_1.ElementRef])
    ], MobileHideDirective);
    return MobileHideDirective;
}());
exports.MobileHideDirective = MobileHideDirective;
//# sourceMappingURL=mobile-hidedirective.js.map