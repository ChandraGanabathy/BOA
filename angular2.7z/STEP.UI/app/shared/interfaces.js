"use strict";
var UserRole_Hierarchy_PillarLawReg_ViewModel = (function () {
    function UserRole_Hierarchy_PillarLawReg_ViewModel() {
    }
    return UserRole_Hierarchy_PillarLawReg_ViewModel;
}());
exports.UserRole_Hierarchy_PillarLawReg_ViewModel = UserRole_Hierarchy_PillarLawReg_ViewModel;
var PaginatedResult = (function () {
    function PaginatedResult() {
    }
    return PaginatedResult;
}());
exports.PaginatedResult = PaginatedResult;
//# sourceMappingURL=interfaces.js.map