import { Injectable } from '@angular/core';
import { Predicate } from '../interfaces';

declare var alertify: any;

@Injectable()
export class NotificationService {
    private _notifier: any = alertify;
    constructor() {
    }

    /*
       Opens a confirmation dialog using the alertify.js lib
    */
    openConfirmationDialog(message: string, okCallBack: () => any) {
        this._notifier.confirm(message, function (e) {
            if (e) {
                okCallBack();
            } else {

            }
        });
    }

    /*
        Prints a sucessmessage using the alertify.js lib
    */
    printSuccessMessage(message: string) {
        this._notifier.success(message);
    }

    /*
        prints a errormessage using the alertify.js lib
    */
    printErrorMessage(message: string) {
        this._notifier.error(message);
    }
}