"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
//Grab everything with import 'rxjs/Rx';
var Observable_1 = require('rxjs/Observable');
require('rxjs/add/operator/map');
require('rxjs/add/operator/catch');
require('../interfaces');
var config_service_1 = require('../utils/config-service');
var items_service_1 = require('../utils/items-service');
var DataService = (function () {
    function DataService(http, itemsService, configService) {
        this.http = http;
        this.itemsService = itemsService;
        this.configService = configService;
        this._baseUrl = '';
        this._baseUrl = configService.getApiURI();
        this.id = 1;
    }
    DataService.prototype.getHeaders = function () {
        var headers = new http_1.Headers();
        headers.append('Accept', 'application/json');
        return headers;
    };
    DataService.prototype.postHeaders = function () {
        var headers = new http_1.Headers();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return headers;
    };
    DataService.prototype.handleError = function (error) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors = '';
        if (!serverError.type) {
            console.log(serverError);
            console.log('Error');
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }
        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
        return Observable_1.Observable.throw(applicationError || modelStateErrors || 'Server error');
    };
    DataService.prototype.getSessionsData = function () {
        return this.http.get(this._baseUrl + '/AccountService/GetSessionsData', { headers: this.getHeaders() })
            .map(function (res) {
            return res.json();
        })
            .catch(this.handleError);
    };
    /* START => Home Module Web Api Service Call  */
    DataService.prototype.getDataForDashboard = function () {
        return this.http.get(this._baseUrl + 'ProjectManagementService/GetDataForDashboard/', { headers: this.getHeaders() })
            .map(function (res) {
            return res.json();
        })
            .catch(this.handleError);
    };
    /* END => Home Module Web Api Service Call  */
    /* START => User Management Web Api Service Call  */
    DataService.prototype.getUserListingPageLoading = function () {
        return this.http.get(this._baseUrl + 'UserManagementService/GetUserListingPageLoading/', { headers: this.getHeaders() })
            .map(function (res) {
            return res.json();
        })
            .catch(this.handleError);
    };
    DataService.prototype.getAllUsers = function (userSearchFilter) {
        return this.http.post(this._baseUrl + 'UserManagementService/GetAllUsers/', JSON.stringify(userSearchFilter), { headers: this.postHeaders() })
            .map(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    DataService.prototype.updateUserStatus = function (user) {
        return this.http.post(this._baseUrl + 'UserManagementService/UpdateUserStatus/', JSON.stringify(user), { headers: this.postHeaders() })
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    DataService.prototype.getUserDataAtPageLoading = function (userId, inviteStatusFromLogin, isUserInfo) {
        return this.http.get(this._baseUrl + 'UserManagementService/GetUserDataAtPageLoading/?userId=' + userId + '&inviteStatusFromLogin=' + inviteStatusFromLogin + '&isUserInfo=' + isUserInfo, { headers: this.getHeaders() })
            .map(function (res) {
            return res.json();
        })
            .catch(this.handleError);
    };
    DataService.prototype.doesUserExists = function (emailId) {
        return this.http.get(this._baseUrl + 'UserManagementService/DoesUserExists/?emailId=' + emailId, { headers: this.getHeaders() })
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    DataService.prototype.createUpdateUser = function (user) {
        return this.http.post(this._baseUrl + 'UserManagementService/CreateUser/', JSON.stringify(user), { headers: this.postHeaders() })
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    DataService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, items_service_1.ItemsService, config_service_1.ConfigService])
    ], DataService);
    return DataService;
}());
exports.DataService = DataService;
//# sourceMappingURL=data-service.js.map