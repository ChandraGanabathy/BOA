import { Injectable } from '@angular/core';
import { Http, Response, Headers, HttpModule } from '@angular/http';
//Grab everything with import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import '../interfaces';
import { IUser, IUser_Role, IUser_Role_Hierarchy_Assoication, IUser_Role_Pillar_Association, IUser_Preference, IAction } from '../interfaces'
import { ConfigService } from '../utils/config-service';
import { ItemsService } from '../utils/items-service';
import { UserSearchFilter } from '../../filters/search-filter';

@Injectable()
export class DataService {
    _baseUrl: string = '';
    id: number;
    constructor(private http: Http,
        private itemsService: ItemsService,
        private configService: ConfigService) {
        this._baseUrl = configService.getApiURI();
        this.id = 1;
    }

    private getHeaders() {
        let headers = new Headers();
        headers.append('Accept', 'application/json');
        return headers;
    }

    private postHeaders() {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        return headers;
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';
        if (!serverError.type) {
            console.log(serverError);
            console.log('Error');
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }
        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }

    getSessionsData(): Observable<any> {
        return this.http.get(this._baseUrl + '/AccountService/GetSessionsData', { headers: this.getHeaders() })
            .map((res: Response) => {
                return res.json()
            })
            .catch(this.handleError);
    }

    /* START => Home Module Web Api Service Call  */
    getDataForDashboard(): Observable<any> {
        return this.http.get(this._baseUrl + 'ProjectManagementService/GetDataForDashboard/', { headers: this.getHeaders() })
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError)
    }
    /* END => Home Module Web Api Service Call  */

    /* START => User Management Web Api Service Call  */
    getUserListingPageLoading(): Observable<any> {
        return this.http.get(this._baseUrl + 'UserManagementService/GetUserListingPageLoading/', { headers: this.getHeaders() })
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }

    getAllUsers(userSearchFilter: UserSearchFilter): Observable<IUser[]> {
        return this.http.post(this._baseUrl + 'UserManagementService/GetAllUsers/', JSON.stringify(userSearchFilter), { headers: this.postHeaders() })
            .map((response: Response) => <IUser[]>response.json())
            .catch(this.handleError);
    }

    updateUserStatus(user: IUser): Observable<IUser> {
        return this.http.post(this._baseUrl + 'UserManagementService/UpdateUserStatus/', JSON.stringify(user), { headers: this.postHeaders() })
            .map((res: Response) => <IUser>res.json())
            .catch(this.handleError);
    }

    getUserDataAtPageLoading(userId: number, inviteStatusFromLogin: string, isUserInfo: string): Observable<any> {
        return this.http.get(this._baseUrl + 'UserManagementService/GetUserDataAtPageLoading/?userId=' + userId + '&inviteStatusFromLogin=' + inviteStatusFromLogin + '&isUserInfo=' + isUserInfo
            , { headers: this.getHeaders() })
            .map((res: Response) => {
                return res.json();
            })
            .catch(this.handleError);
    }

    doesUserExists(emailId: string): Observable<boolean> {
        return this.http.get(this._baseUrl + 'UserManagementService/DoesUserExists/?emailId=' + emailId, { headers: this.getHeaders() })
            .map((res: Response) => <boolean>res.json())
            .catch(this.handleError);
    }

    createUpdateUser(user: IUser): Observable<any> {
        return this.http.post(this._baseUrl + 'UserManagementService/CreateUser/', JSON.stringify(user), { headers: this.postHeaders() })
            .map((res: Response) => { return res.json() })
            .catch(this.handleError);
    }
    /* END => User Management Web Api Services Call  */
}