﻿module.exports = function () {
    var base = 'http://localhost:62243/';

    var config = {
        base: base,
        compiledTs: './app/**/*.js',
        dist: 'dist',
        index: base + 'Home/Index.html',
        ngTemplates: './app/**/*.html',
        sourceMaps: './app/**/*.map',
        tsFiles: './app/**/*.ts',
        tsConfig: './tsconfig.json',
        vendors: base + 'vendors'
    };

    return config;
};
