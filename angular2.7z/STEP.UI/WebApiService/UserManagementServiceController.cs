﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using STEP.Common;
using STEP.Models;
using STEP.Repository;

namespace STEP.WebAPI
{
    public class UserManagementServiceController : ApiController
    {
        private readonly IUserRepository _userRepository;
        private readonly ICodeValueRepository _codeValueRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IRoleMappingRepository _roleMappingRepository;
        private readonly IUserPreferenceRepository _userPreferenceRepository;
        private readonly IPillarLawRegMappingRepository _pillarLawRegMappingRepository;
        private readonly IFiscalYearRepository _fiscalYearRepository;
        private readonly IHierarchyDataRepository _hierarchyDataRepository;

        public UserManagementServiceController(
            IUserRepository userRepository,
            ICodeValueRepository codeValueRepository,
            IRoleRepository roleRepository,
            IRoleMappingRepository roleMappingRepository,
            IUserPreferenceRepository userPreferenceRepository,
            IPillarLawRegMappingRepository pillarLawRegMappingRepository,
            IFiscalYearRepository fiscalYearRepository,
            IHierarchyDataRepository hierarchyDataRepository
            )
        {
            _userRepository = userRepository;
            _codeValueRepository = codeValueRepository;
            _roleRepository = roleRepository;
            _roleMappingRepository = roleMappingRepository;
            _userPreferenceRepository = userPreferenceRepository;
            _pillarLawRegMappingRepository = pillarLawRegMappingRepository;
            _fiscalYearRepository = fiscalYearRepository;
            _hierarchyDataRepository = hierarchyDataRepository;
        }

        [HttpGet]
        public object GetUserDataAtPageLoading(int userId, string inviteStatusFromLogin, string isUserInfo)
        {
            var codeValue = string.Empty;

            if (userId == 0)
            {
                codeValue = AppConstants.CodeCategories.UserStatusInvited;
            }
            else
            {
                if (string.IsNullOrEmpty(inviteStatusFromLogin) == false && inviteStatusFromLogin == "true")
                {
                    codeValue = AppConstants.CodeCategories.UserStatusActive;
                }
            }
            User getUser;
            if (userId == 0)
            {
                getUser = new User();
            }
            else
            {
                getUser = GetUserByUserId(userId);
            }

            var getPillars = _pillarLawRegMappingRepository.GetPillarsByUserRole(
                                        AppConstants.CodeCategories.Pillar, string.Empty);
            var getLawRegs = _pillarLawRegMappingRepository.GetLawRegByUserRole(
                                        string.Empty, AppConstants.CodeCategories.LawReg,
                                                                                   string.Empty);
            var getProgramAreas = _pillarLawRegMappingRepository.GetProgramAreaUserRole(
                                        string.Empty, string.Empty, AppConstants.CodeCategories.ProgramArea, string.Empty);

            // Get All Code Value Based on Code Ids
            var codeValues = GetCodeValuesForUserData();

            var getUserRoleHierarchyPillarLawRegViewModel = GetUserRoleHierarchyPillarLawRegViewModel(getUser, codeValues);

            // Get User Role Hierarchy Data Pillar Association
            getUser.UserRole_Hierarchy_PillarLawReg_ViewModel = getUserRoleHierarchyPillarLawRegViewModel;
            // Get all Roles
            var getAllRoles = _roleRepository.GetAll().Select(x => new
            {
                x.Id,
                x.Role_Key,
                x.Name
            }).ToList();

            var getLoggedInUserRoleId = AppContext.CurrentUserRole.Role_Id;

            // Get Immediate Child Role Data
            var getRolesForInvite = GetImmedidateChildRoles();


            // Get Hierarchy Data for Current User Role Id
            var getAllHierarchyDatas = _hierarchyDataRepository.GetAll().ToList().Select(y => new
            {
                y.Id,
                y.Parent_Id,
                y.Code,
                y.Name,
                y.Hierarchy_Level_Id,
                y.Hierarchy_Level_Key,
                y.State_Id,
                y.State_Key
            });

            // User Status From Code Value
            var getUserStatus = codeValues
                .FirstOrDefault(
                    us =>
                    us.Code_Value_Key.Equals(codeValue,
                                             StringComparison.OrdinalIgnoreCase));


            var getLoginUserRole = STEP.Common.AppContext.CurrentUserRole;

            if (!string.IsNullOrEmpty(getUser.State_Key))
            {
                getUser.State_Key = getUser.State_Key.Trim();
            }
            // Grouping all the data in anonyoumous variable 
            // Usage is to restrict many ajax request and make it as single ajax request

            var userDataAtPageLoading = new[]
                {
                        new
                            {
                                GetUser = getUser,
                                GetUserStatus = getUserStatus,
                                GetAllRoles = getAllRoles,
                                GetLoggedInUserRoleId = getLoggedInUserRoleId,
                                GetAllStates =_codeValueRepository.GetCodeValues(codeValues.ToList(), AppConstants.CodeCategories.State),
                                GetRolesForInvite = getRolesForInvite,
                                GetPillars =getPillars,
                                GetLawRegs =getLawRegs,
                                GetProgramAreas =getProgramAreas,
                                GetAllHierarchyData = getAllHierarchyDatas,
                                GetLoginUserRole = getLoginUserRole,
                                //GetUserRoleHierarchyPillarLawRegViewModel=getUserRoleHierarchyPillarLawRegViewModel
                            }
                    };
            return userDataAtPageLoading;
        }
        private User GetUserByUserId(int userId)
        {
            return _userRepository.GetSingle(x => x.Id == userId, x => x.User_Role,
                                                       x => x.User_Role.Select(y => y.Role),
                                                       x => x.User_Role.Select(y => y.User_Role_Hierarchy_Assoication),
                                                       x => x.User_Role.Select(y => y.User_Role_Hierarchy_Assoication.Select(z => z.Hierarchy_Data)),
                                                       x => x.User_Role.Select(y => y.User_Role_Pillar_Association));
        }
        private ICollection<Code_Value> GetCodeValuesForUserData()
        {
            var codeIds = new[]
                {
                        AppConstants.CodeCategories.State, AppConstants.CodeCategories.UserStatus,
                         AppConstants.CodeCategories.Pillar, AppConstants.CodeCategories.LawReg,
                        AppConstants.CodeCategories.ProgramArea,AppConstants.CodeCategories.UserStatus
                    };

            return _codeValueRepository.FindBy(x => codeIds.Contains(x.Code_ID)).ToList();
        }

        private ICollection<UserRole_Hierarchy_PillarLawReg_ViewModel> GetUserRoleHierarchyPillarLawRegViewModel(User user, ICollection<Code_Value> codeValues)
        {
            // Populate User Role Hierarchy Data Plilar LawReg Program Area Data
            List<UserRole_Hierarchy_PillarLawReg_ViewModel> lstUserRole_Hierarchy_PillarLawReg_ViewModel = new List<UserRole_Hierarchy_PillarLawReg_ViewModel>();
            if (user != null)
            {
                user.User_Role.ToList().ForEach(x =>
                {
                    UserRole_Hierarchy_PillarLawReg_ViewModel model = new UserRole_Hierarchy_PillarLawReg_ViewModel();

                    model.User_Role_Id = x.Id;
                    model.User_Role_Status_Key = x.User_Role_Status_Key;
                    model.User_Role_Status_Description = codeValues.Where(y => y.Code_Value_Key == x.User_Role_Status_Key).FirstOrDefault().Code_Value_Description;
                    model.Role_Id = x.Role_Id;
                    model.Role_Name = x.Role.Name;

                    model.User_Role_Hierarchy_Association_Id = x.User_Role_Hierarchy_Assoication.FirstOrDefault().Id;
                    model.Hierarchy_Data_Id = x.User_Role_Hierarchy_Assoication.FirstOrDefault().Hierarchy_Data_Id;
                    model.Hierarchy_Data_Name = x.User_Role_Hierarchy_Assoication.FirstOrDefault().Hierarchy_Data.Name;

                    var urp = x.User_Role_Pillar_Association.FirstOrDefault();
                    model.User_Role_Pillar_Association_Id = urp.Id;
                    model.Pillar_Key = urp.Pillar_Key;
                    model.Pillar_Description = codeValues.Where(y => y.Code_Value_Key == urp.Pillar_Key).FirstOrDefault().Code_Value_Description;
                    model.LawReg_Key = urp.LawReg_Key;
                    model.LawReg_Description = codeValues.Where(y => y.Code_Value_Key == urp.LawReg_Key).FirstOrDefault().Code_Value_Description;
                    model.ProgramArea_Key = urp.ProgramArea_Key;
                    model.ProgramArea_Description = codeValues.Where(y => y.Code_Value_Key == urp.ProgramArea_Key).FirstOrDefault().Code_Value_Description;

                    lstUserRole_Hierarchy_PillarLawReg_ViewModel.Add(model);
                });
            }
            return lstUserRole_Hierarchy_PillarLawReg_ViewModel;
        }

        [HttpGet]
        public bool DoesUserExists(string emailId)
        {
            var isUserExists =
                //_userRepository.FindBy(x => x.Email_Id == emailId && x.Ako_Email_Id == akoEmailId).Any();
                _userRepository.FindBy(x => x.Email_Id == emailId).Any();
            return isUserExists;
        }

        [HttpPost]
        public User CreateUser(User user)
        {
            var objUser = _userRepository.CreateUpdateUser(user);
            objUser = GetUserByUserId(objUser.Id);
            if (!string.IsNullOrEmpty(objUser.State_Key))
            {
                objUser.State_Key.Trim();
            }
            // Get All Code Value Based on Code Ids
            var codeValues = GetCodeValuesForUserData();
            var getUserRoleHierarchyPillarLawRegViewModel = GetUserRoleHierarchyPillarLawRegViewModel(objUser, codeValues);
            // Get User Role Hierarchy Data Pillar Association
            objUser.UserRole_Hierarchy_PillarLawReg_ViewModel = getUserRoleHierarchyPillarLawRegViewModel;
            return objUser;
        }

        [HttpGet]
        public string GetSessionTimeOutRedirectUrl()
        {
            var codeValues =
                _codeValueRepository.FindBy(
                    x =>
                    x.Code_ID == AppConstants.CodeCategories.SystemConstant &&
                    x.Code_Value_Key == AppConstants.CodeCategories.SessionTimeoutRedirectCodeValue)
                                    .FirstOrDefault();
            return codeValues != null ? codeValues.Data1 : AppConstants.CodeCategories.SessionTimeoutRedirectUrl;
        }

        [HttpPost]
        public IEnumerable<User> GetAllUsers(UserSearchFilter userSearchFilter)
        {
            AppContext.UserSearchFilter = userSearchFilter;
            if (!string.IsNullOrEmpty(userSearchFilter.Status) && userSearchFilter.Status.Equals("All"))
            {
                userSearchFilter.Status = string.Empty;
            }
            if (userSearchFilter.RoleId.HasValue && userSearchFilter.RoleId == 0)
            {
                userSearchFilter.RoleId = null;
            }
            var objUsers = _userRepository.GetAllUsers(userSearchFilter, AppContext.CurrentUserRole.Id);
            return objUsers;
        }

        //[Route("api/UserManagementService/GetUsers")]
        /*[HttpGet]
        public IEnumerable<User> GetUsers()
        {

            var objUsers = _userRepository.GetAll().ToList();
            return objUsers;
        }*/

        [HttpGet]
        public object GetUserListingPageLoading()
        {
            // Get Immediate Child Role Data
            var getImmediateChildRoles = GetImmedidateChildRoles();
            var getUserStatus =
                _codeValueRepository.FindBy(x => x.Code_ID.Equals(AppConstants.CodeCategories.UserStatus)).ToList();
            var userListingDataAtPageLoading = new[]
                {
                        new

                        {
                                GetRoles = getImmediateChildRoles,
                                GetUserStatus = getUserStatus,
                                GetAllUsers=GetAllUsers(AppContext.UserSearchFilter),
                                UserSearchCriteria=AppContext.UserSearchFilter
                        }
                    };
            return userListingDataAtPageLoading;
        }

        private object GetImmedidateChildRoles()
        {
            return _roleMappingRepository.
                AllIncluding(x => x.Child_Role, x => x.Parent_Role).Where(x =>
                                                                          x.Parent_Role_Id ==
                                                                          AppContext.CurrentUserRole
                                                                                    .Role_Id &&
                                                                          x.Child_Role_Id >=
                                                                          AppContext.CurrentUserRole
                                                                                    .Role_Id)
                                         .Select(item => new
                                         {
                                             item.Id,
                                             item.Child_Role_Id,
                                             item.Parent_Role_Id,
                                             item.Child_Role.Role_Key,
                                             item.Child_Role.Name,
                                             item.Child_Role.Hierarchy_Level_Key,
                                             RoleID = item.Child_Role.Id,
                                         }).OrderBy(x => x.Child_Role_Id).ToList();
        }

        /// <summary>
        /// Get All Data for User Preference Page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public object GetUserPreferenceDataAtPageLoading()
        {
            // Get All Code Value Based on Code Ids
            var codeIds = new[] { AppConstants.CodeCategories.Theme, AppConstants.CodeCategories.PageSize };
            var codeValues = _codeValueRepository.FindBy(x => codeIds.Contains(x.Code_ID)).ToList();

            // Theme Data Data
            var getAllThemes =
                codeValues.Where(x => x.Code_ID == AppConstants.CodeCategories.Theme).Select(y => new
                {
                    y.Code_ID,
                    y.Code_Value_Key,
                    y.Code_Value_Description,
                    y.Data1
                });

            // Page Size Data
            var getPageSize =
                codeValues.Where(x => x.Code_ID == AppConstants.CodeCategories.PageSize).Select(y => new
                {
                    y.Code_ID,
                    y.Code_Value_Key,
                    y.Code_Value_Description,
                    y.Data1
                });

            // Get User Preference data
            var getUserPreference = AppContext.CurrentUser.User_Preference.FirstOrDefault();

            var userPreferenceAtPageLoading = new[]
                {
                        new
                            {
                                GetAllThemes = getAllThemes,
                                GetPageSize = getPageSize,
                                GetUserPreference = getUserPreference,
                            }
                    };
            return userPreferenceAtPageLoading;
        }

        [HttpPost]
        public User_Preference SaveUpdateUserPreference(User_Preference userPreference)
        {
            // Add User_Preference
            if (userPreference.Id == 0)
            {
                userPreference.Created_By = GetLoggedUserInfo();
                userPreference.Created_Date = CreatedUpdatedDateTime();
                userPreference.Modified_By = GetLoggedUserInfo();
                userPreference.Modified_Date = CreatedUpdatedDateTime();

                _userPreferenceRepository.Add(userPreference);
                _userPreferenceRepository.Commit();
            }
            // Update User Preference
            else
            {
                var updateUserPreference = _userPreferenceRepository.GetSingle(r => r.Id == userPreference.Id);

                updateUserPreference.User_Id = userPreference.User_Id;
                updateUserPreference.Theme_Id = userPreference.Theme_Id;
                updateUserPreference.Theme_Key = userPreference.Theme_Key;
                updateUserPreference.Page_Size_Id = userPreference.Page_Size_Id;
                updateUserPreference.Page_Size_Key = userPreference.Page_Size_Key;
                updateUserPreference.Modified_By = GetLoggedUserInfo();
                updateUserPreference.Modified_Date = CreatedUpdatedDateTime();

                _userPreferenceRepository.Edit(updateUserPreference);
                _userPreferenceRepository.Commit();
            }

            STEP.Common.AppContext.CurrentUserTheme =
                _codeValueRepository.GetCodeValue(userPreference.Theme_Id, userPreference.Theme_Key).Code_Value_Key;

            int pageSize;
            var getPageSize = _codeValueRepository.GetCodeValue(userPreference.Page_Size_Id,
                                                                userPreference.Page_Size_Key);
            Int32.TryParse(getPageSize.Code_Value_Description, out pageSize);
            STEP.Common.AppContext.CurrentUserPageSize = pageSize;

            var user = AppContext.CurrentUser;

            var lstUserPreference = new List<User_Preference> { userPreference };
            user.User_Preference = lstUserPreference;
            AppContext.CurrentUser = user;

            return userPreference;
        }

        [HttpPost]
        public User UpdateUserStatus(User user)
        {
            var updateUser = _userRepository.GetSingle(x => x.Id == user.Id);
            updateUser.User_Status_Id = user.User_Status_Id;
            updateUser.User_Status_Key = user.User_Status_Key;
            updateUser.Modified_By = GetLoggedUserInfo();
            updateUser.Modified_Date = CreatedUpdatedDateTime();
            _userRepository.Edit(updateUser);
            _userRepository.Commit();
            return updateUser;
        }

        [HttpGet]
        public int DeleteUser(int userId)
        {
            var deleteUser = _userRepository.GetSingle(r => r.Id == userId);
            _userRepository.Delete(deleteUser);
            _userRepository.Commit();
            return 1;
        }

        [HttpGet]
        public object GetFiscalDataAtPageLoading(int FiscalId)
        {
            return _fiscalYearRepository.GetFiscalDataAtPageLoading(FiscalId);
        }

        [HttpGet]
        public List<object> GetAllFiscal()
        {
            var objUsers = _fiscalYearRepository.GetAllFiscal();
            return objUsers;
        }

        [HttpPost]
        public Fiscal_Year CreateFiscalValue(Fiscal_Year fiscalValue)
        {
            var objFiscal = _fiscalYearRepository.CreateFiscalValue(fiscalValue);
            return objFiscal;
        }
        public string GetLoggedUserInfo()
        {
            if (AppContext.CurrentUser != null)
                return AppContext.CurrentUser.First_Name + ' ' + AppContext.CurrentUser.Last_Name;
            return string.Empty;
        }

        public DateTime CreatedUpdatedDateTime()
        {
            return DateTime.Now;
        }
    }
}