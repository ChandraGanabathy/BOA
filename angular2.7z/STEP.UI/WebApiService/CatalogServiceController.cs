﻿using STEP.Common;
using STEP.Models;
using STEP.Repository;
using System;
using System.Linq;
using System.Web.Http;

namespace STEP.WebAPI
{
    public class CatalogServiceController : ApiController
    {
        private readonly ICatalogRepository _catalogRepository;
        private readonly ICodeValueRepository _codeValueRepository;
        private readonly IAMSCORepository _AMSCORepository;
        private readonly ICatalogAMSCORepository _catalog_AMSCORepository;
        private readonly ICatalogQuestionsRepository _catalog_QuestionsRepository;
        private readonly IFiscalYearRepository _fiscal_YearRepository;
        private readonly IPillarPB28MappingRepository _pillar_PB28_MappingRepository;
        private readonly IPillarLawRegMappingRepository _pillar_LawReg_MappingRepository;
        private readonly IMDEPRepository _MDEPRepository;
        private readonly IProjectAnswerRepository _projectAnswerRepository;


        public CatalogServiceController(
            ICatalogRepository catalogRepository,
            ICodeValueRepository codeValueRepository,
            IAMSCORepository AMSCORepository,
            ICatalogAMSCORepository catalog_AMSCORepository,
            ICatalogQuestionsRepository catalog_QuestionsRepository,
            IFiscalYearRepository fiscal_YearRepository,
            IPillarPB28MappingRepository pillar_PB28_MappingRepository,
             IPillarLawRegMappingRepository pillar_LawReg_MappingRepository,
            IMDEPRepository MDEPRepository,
            IProjectAnswerRepository projectAnswerRepository
           )
        {
            _catalogRepository = catalogRepository;
            _codeValueRepository = codeValueRepository;
            _AMSCORepository = AMSCORepository;
            _catalog_AMSCORepository = catalog_AMSCORepository;
            _catalog_QuestionsRepository = catalog_QuestionsRepository;
            _fiscal_YearRepository = fiscal_YearRepository;
            _pillar_PB28_MappingRepository = pillar_PB28_MappingRepository;
            _pillar_LawReg_MappingRepository = pillar_LawReg_MappingRepository;
            _MDEPRepository = MDEPRepository;
            _projectAnswerRepository = projectAnswerRepository;
        }

        #region Public Methods

        [HttpGet]
        public object GetDataForCatalogListingPageLoading(string SharedPageKey)
        {
            // Gets all the Pillar List
            //var pillarList = GetLoadList(AppConstants.CodeCategories.Pillar);
            //var lawregList = GetLoadList(AppConstants.CodeCategories.LawReg);
            //var programAreaList = GetLoadList(AppConstants.CodeCategories.ProgramArea);
            var pillarList = AppContext.CurrentUserRolePillars;
            var lawregList = AppContext.CurrentUserRoleLawRegs;
            var programAreaList = AppContext.CurrentUserRoleProgramAreas;

            // Gets all the catlaog data
            var catalogList = _catalogRepository.SearchCatalogs(SharedPageKey, AppContext.CatalogSearchFilter);


            // Object containing Pillar and CatalogList data
            var catalogDataAtPageLoading = new[]
                {
                                                       new
                                                       {
                                                           PillarLoadList = pillarList,
                                                           CatalogList = catalogList,
                                                           LawRegList = lawregList,
                                                           ProgramAreaList = programAreaList
                        }
                };

            return catalogDataAtPageLoading;
        }

        [HttpGet]
        public object GetCatalogById(int catalogId)
        {
            var catalogDetail = _catalogRepository.GetCatalogById(catalogId);
            return catalogDetail;
        }

        [HttpGet]
        public object GetCatalogMasterData()
        {
            var catalogMasterData = _catalogRepository.GetCatalogMasterData();
            return catalogMasterData;
        }

        [HttpPost]
        public object SearchCatalogs(string SharedPageKey, CatalogSearchFilter catalogFilter)
        {


            AppContext.CatalogSearchFilter = catalogFilter;
            if (catalogFilter != null)
            {

                if (catalogFilter.Pillar != null)
                {
                    // If ALL selected on pillar there is no condition needed on pillar
                    catalogFilter.Pillar = catalogFilter.Pillar == "ALL" ? string.Empty : catalogFilter.Pillar;
                }
                if (catalogFilter.LawReg != null)
                {
                    // If ALL selected on pillar there is no condition needed on pillar
                    catalogFilter.LawReg = catalogFilter.LawReg == "ALL" ? string.Empty : catalogFilter.LawReg;
                }
                if (catalogFilter.ProgramArea != null)
                {
                    // If ALL selected on pillar there is no condition needed on pillar
                    catalogFilter.ProgramArea = catalogFilter.ProgramArea == "ALL"
                                                    ? string.Empty
                                                    : catalogFilter.ProgramArea;
                }
            }
            //else
            //{
            //    catalogFilter = new CatalogSearchFilter { };
            //}
            // Gets all the catlaog data
            var catalogList = _catalogRepository.SearchCatalogs(SharedPageKey, catalogFilter);

            return catalogList;
        }

        [HttpPost]
        public Catalog CreateUpdateCatalog(Catalog catalog)
        {
            var pillarPB28Mapping =
                _pillar_PB28_MappingRepository.FindBy(x => x.Pillar_Key == catalog.Pillar_PB28_Mapping.Pillar_Key &&
                                                           x.Title_Key == catalog.Pillar_PB28_Mapping.Title_Key &&
                                                           x.Category_Key == catalog.Pillar_PB28_Mapping.Category_Key &&
                                                           x.SubCategory_Key ==
                                                           catalog.Pillar_PB28_Mapping.SubCategory_Key)
                                              .ToList();
            var pillarLawregMapping =
                _pillar_LawReg_MappingRepository.FindBy(x => x.Pillar_Key == catalog.Pillar_PB28_Mapping.Pillar_Key &&
                                                             x.LawReg_Key == catalog.Pillar_LawReg_Mapping.LawReg_Key &&
                                                             x.ProgramArea_Key ==
                                                             catalog.Pillar_LawReg_Mapping.ProgramArea_Key
                    ).ToList();
            catalog.Pillar_PB28_Mapping_Id = (pillarPB28Mapping.Count == 0) ? 0 : pillarPB28Mapping[0].Id;
            catalog.Pillar_Lawreg_Mapping_Id = (pillarLawregMapping.Count == 0) ? 0 : pillarLawregMapping[0].Id;

            if (catalog.Id == 0)
            {
                var catalogNumberList =
                    _catalogRepository.FindBy(x => x.Catalog_Number.Contains(catalog.Pillar_LawReg_Mapping.Pillar_Key))
                                      .OrderBy(x => x.Catalog_Number)
                                      .ToList();
                var catalogNumberprefix =
                    _codeValueRepository.FindBy(
                        x =>
                        x.Code_ID == AppConstants.CodeCategories.Pillar &&
                        x.Code_Value_Key == catalog.Pillar_LawReg_Mapping.Pillar_Key).Single().Data2;
                if (catalogNumberList.Count == 0)
                    catalog.Catalog_Number = catalogNumberprefix + "0001";
                else
                {
                    var number =
                        Convert.ToInt32(catalogNumberList[catalogNumberList.Count - 1].Catalog_Number.Remove(0, 3)) + 1;
                    catalog.Catalog_Number = catalogNumberprefix + number.ToString("D" + 4);
                }
            }

            var pillar = catalog.Pillar_PB28_Mapping.Pillar_Key;
            var objCatalog = _catalogRepository.CreateUpdateCatalog(catalog);

            var fy = AppContext.CurrentFiscalYear.FY;
            var amscoCode = "";

            var amscoId = catalog.Catalog_AMSCO.Select(y => y.AMSCO_Id).ToList();
            var catalogAMSCO =
                _AMSCORepository.FindBy(x => amscoId.Contains(x.Id)).ToList();

            /*var currentAmscoList =
                catalog.Catalog_AMSCO.Where(
                    y => (y.End_FY == null && y.Start_FY <= fy) || (y.Start_FY <= fy && y.End_FY >= fy)).ToList();*/
            var currentAmscoList = catalogAMSCO.Where(
                y =>
                ((y != null && y.End_FY == null) && (y.Start_FY <= fy)) ||
                ((y != null && y.Start_FY <= fy) && (y.End_FY >= fy))).ToList();
            if (currentAmscoList.Count != 0)
            {
                /*var matchList = _AMSCORepository.GetSingle(currentAmscoList[0].AMSCO_Id);
                amscoCode = (matchList != null) ? matchList.AMSCO_Code + " - " + matchList.AMSCO_Description : string.Empty;*/
                var firstOrDefault = catalog.Catalog_AMSCO.FirstOrDefault();
                if (firstOrDefault != null)
                {
                    var matchList = _AMSCORepository.GetSingle(firstOrDefault.AMSCO_Id);
                    amscoCode = (matchList != null)
                                    ? matchList.AMSCO_Code + " - " + matchList.AMSCO_Description
                                    : string.Empty;
                }
            }
            objCatalog.AMSCOCode = amscoCode;

            return objCatalog;

        }

        #endregion

        #region Private Methods

        private object GetLoadList(int listId)
        {
            var loadList = _codeValueRepository.FindBy(x => x.Code_ID == listId)
                                               .Where(x => x.Code_Value_Key != (AppConstants.CodeCategories.ALL))
                                               .Select(x =>
                                                         new
                                                         {
                                                             Key = x.Code_Value_Key,
                                                             Description = x.Code_Value_Description
                                                         }).AsQueryable<object>();
            return loadList;
        }

        #endregion

    }

}
