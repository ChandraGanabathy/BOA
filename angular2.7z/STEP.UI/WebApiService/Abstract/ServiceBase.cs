﻿using System;
using System.Web;
using STEP.Common;
using STEP.Models;
using System.Net.Http;
using System.Net;
using System.Web.Http;

namespace STEP.WebAPI
{
    public class ServiceBase : ApiController
    {
        protected internal HttpResponseMessage ResponseMessage<T>(T entity, OperationStatus response)
        {
            HttpResponseMessage responseMessage;

            if (response.Status)
            {
                responseMessage = Request.CreateResponse(HttpStatusCode.Created, entity);
            }
            else
            {
                HttpContext.Current.ClearError();
                responseMessage = Request.CreateResponse(response.StatusCode > 0 ? response.StatusCode : HttpStatusCode.BadRequest, entity);
                if (response.ExceptionObject == null) return responseMessage;
                //ErrorLog.GetDefault(HttpContext.Current).Log(new Error(response.ExceptionObject));
                responseMessage.ReasonPhrase = response.ExceptionObject.Message;
            }
            return responseMessage;
        }

        public string GetLoggedUserInfo()
        {
            if (AppContext.CurrentUser != null)
                return AppContext.CurrentUser.First_Name + ' ' + AppContext.CurrentUser.Last_Name;
            return string.Empty;
        }

        public DateTime CreatedUpdatedDateTime()
        {
            return DateTime.Now;
        }

        public bool SendEmailEnabled()
        {
            string keyEmailEnabled = AppConfig.SendEmail;
            if (string.IsNullOrEmpty(keyEmailEnabled)) return false;
            bool isEmailEnabled = Convert.ToBoolean(keyEmailEnabled);
            return isEmailEnabled;
        }
    }
}