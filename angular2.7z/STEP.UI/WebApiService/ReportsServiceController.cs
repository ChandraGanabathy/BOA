﻿using System;
using System.Linq;
using System.Web;
using System.Web.Http;
using STEP.Common;
using STEP.Models.UIModel;
using STEP.Repository;

namespace STEP.WebAPI
{
    public class ReportsServiceController : ServiceBase
    {
        private readonly IRoleRepository _roleRepository;
        private readonly ICodeValueRepository _codeValueRepository;
        private readonly IPillarLawRegMappingRepository _pillarLawRegMappingRepository;

        public ReportsServiceController(
            IRoleRepository roleRepository,
            ICodeValueRepository codeValueRepository,
            IPillarLawRegMappingRepository pillarLawRegMappingRepository)
        {

            _roleRepository = roleRepository;
            _codeValueRepository = codeValueRepository;
            _pillarLawRegMappingRepository = pillarLawRegMappingRepository;
        }

        [HttpGet]
        public object GetReportListItems(int roleId)
        {
            var actionsList = AppContext.SessionActions;
            var reportList = actionsList.Where(x => x.Type_Key == "RLST")
                                        .Select(item => new
                                            {
                                                item.Action_Name,
                                                Name = item.Action_Description,
                                            }).ToList();

            return reportList;
        }

        [HttpGet]
        public object GetReportParametersList(int roleId)
        {
            // GETTING ALL ROLES INFORMATION
            var allRoles = _roleRepository.GetAll().Select(x => new
                {
                    x.Id,
                    x.Name
                }).ToList();

            //GETTING ALL Hierarchy INFORMATION for the user role
            var hierarchyInfo = AppContext.CurrentUserRoleHierarchyData.Select(x => new
                {
                    x.Id,
                    x.Name
                }).OrderBy(y => y.Name).ToList();

            // GETTING ALL STATUS
            //var userAllStatus = _codeValueRepository.FindBy(x => x.Code_ID == userStatusCodeId).Select(y => new { y.Code_Value_Key, y.Code_Value_Description }).ToList();
            var userAllStatus = GetCodeValue(AppConstants.CodeCategories.UserStatus);

            // GETTING ALL pillars from session
            var pillarData = AppContext.CurrentUserRolePillars;

            var lawRegData = AppContext.CurrentUserRoleLawRegs;
            var programAreaData = AppContext.CurrentUserRoleProgramAreas;

            //// GETTING ALL Law reg from session
            //var lawRegData = AppContext.CurrentUserRoleLawRegs.OrderBy(x => x.LawRegDescription);

            //// GETTING ALL Program Area from session
            //var programAreaData = AppContext.CurrentUserRoleProgramAreas.OrderBy(x => x.ProgramAreaDescription);

            // GETTING ALL fiscal years from session
            var fiscalYears = AppContext.FiscalYears;

            // GETTING ALL class codes
            var allClass = GetCodeValue(AppConstants.CodeCategories.Class);

            // GETTING ALL resource sponcers
            var allResourceSponcer = GetCodeValue(AppConstants.CodeCategories.ResourceSponsor);

            // GETTING ALL funding status
            var allApprovalStatus = GetCodeValue(AppConstants.CodeCategories.ApprovalStatuss);

            // GETTING ALL project status
            var allProjectStatus = GetCodeValue(AppConstants.CodeCategories.ProjectStatus);

            // GETTING ALL funding status
            //var allPB28Title = _pillarLawRegMappingRepository.GetPB28Title().OrderBy(x => x.TitleDescription);
            //var allPB28Catagory = _pillarLawRegMappingRepository.GetPB28Category().OrderBy(x => x.PB28CategoryDescription);
            var allPB28Title = AppContext.CurrentPB28TitleByPillar;
            var allPB28Catagory = AppContext.CurrentPB28CatagoryByPillarandTitle;

            // GETTING ALL project status
            // GETTING ALL Imapct to Mission
            var allImpacttoMission = GetCodeValue(AppConstants.CodeCategories.ImpacttoMission);

            var allIFundingStatus = GetCodeValue(AppConstants.CodeCategories.FundingStatus);

            var reportParametersAtPageLoading = new[]
                {
                    new
                        {
                            Roles = allRoles,
                            HierarchyInfo = hierarchyInfo,
                            Status = userAllStatus,
                            Pillar = pillarData,
                            LawReg = lawRegData,
                            ProgramArea = programAreaData,
                            FiscalYears = fiscalYears,
                            Class = allClass,
                            ResourceSponcer = allResourceSponcer,
                            ApprovalStatus = allApprovalStatus,
                            ProjectStatus = allProjectStatus,
                            PB28Title = allPB28Title,
                            PB28Category = allPB28Catagory,
                            ImpacttoMission = allImpacttoMission,
                            FundingStatus = allIFundingStatus
                        }
                };
            return reportParametersAtPageLoading;
        }


        private object GetCodeValue(int codId)
        {
            var codeValueList =
                _codeValueRepository.FindBy(x => x.Code_ID == codId)
                                    .OrderBy(x => x.SequenceNumber)
                                    .Select(y => new {y.Code_Value_Key, y.Code_Value_Description})
                                    .ToList();
            return codeValueList;
        }


        [HttpPost]
        public ReportParameters SelectedParametersForReport(ReportParameters objSelectedParametersForReport)
        {
            HttpContext.Current.Session["SelectedParametersForReport"] = objSelectedParametersForReport;
            return
                HttpContext.Current.Session["SelectedParametersForReport"] as ReportParameters;
        }
    }
}
