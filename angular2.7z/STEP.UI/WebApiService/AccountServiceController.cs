﻿using System;
using System.Globalization;
using System.Linq;
using System.Web.Http;
using System.Web.Security;
using STEP.Common;
using STEP.Models;
using STEP.Repository;
using System.Collections;
using System.Collections.Generic;

namespace STEP.WebAPI
{
    public class AccountServiceController : ApiController
    {
        private readonly IUserRepository _userRepository;
        private readonly ICodeValueRepository _codeValueRepository;
        private readonly IHierarchyDataRepository _hierarchyDataRepository;
        private readonly IFiscalYearRepository _fiscalYearRepository;
        private readonly IUserRolePillarAssociationRepository _userRolePillarAssociationRepository;
        private readonly IPillarLawRegMappingRepository _pillarLawRegMappingRepository;
        private readonly IRoleActionRepository _roleActionRepository;
        private readonly IUserAuditRepository _userAuditRepository;

        public AccountServiceController(IUserRepository userRepository,
                                        ICodeValueRepository codeValueRepository,
                                        IHierarchyDataRepository hierarchyDataRepository,
                                        IFiscalYearRepository fiscalYearRepository,
                                        IUserRolePillarAssociationRepository userRolePillarAssociationRepository,
                                        IPillarLawRegMappingRepository pillarLawRegMappingRepository,
                                        IRoleActionRepository roleActionRepository,
                                        IUserAuditRepository userAuditRepository
            )
        {
            _userRepository = userRepository;
            _codeValueRepository = codeValueRepository;
            _hierarchyDataRepository = hierarchyDataRepository;
            _fiscalYearRepository = fiscalYearRepository;
            _userRolePillarAssociationRepository = userRolePillarAssociationRepository;
            _pillarLawRegMappingRepository = pillarLawRegMappingRepository;
            _roleActionRepository = roleActionRepository;
            _userAuditRepository = userAuditRepository;
        }

        [HttpPost]
        public User SignIn(User model)
        {
            var userData = ProceedSignIn(model);
            if (AppContext.CurrentUser.User_Role.Any())
            {
                var firstOrDefault = AppContext.CurrentUser.User_Role.FirstOrDefault();
                if (firstOrDefault != null)
                    SetAuthCookie(AppContext.CurrentUser.Email_Id,
                                  firstOrDefault.Id.ToString(CultureInfo.InvariantCulture),
                                  false);

            }
            return userData;
        }

        private User ProceedSignIn(User user)
        {
            var userData =
                _userRepository.GetSingle(
                    u => u.Email_Id == user.Email_Id.Trim()
                    , u => u.User_Role
                    , u => u.User_Role.Select(x => x.User_Role_Hierarchy_Assoication)
                    , u => u.User_Role.Select(x => x.User_Role_Pillar_Association)
                    , u => u.User_Preference, u => u.User_Role.Select(x => x.Role)
                    ,
                    u =>
                    u.User_Role.Select(
                        x =>
                        x.User_Role_Hierarchy_Assoication.Select(y => y.Hierarchy_Data)));

            if (userData != null)
            {
                if (EncryptDecrypt.DecryptData(userData.Password) == user.Password)
                {
                    userData.User_Role =
                        userData.User_Role.Where(
                            x => x.User_Role_Status_Key == AppConstants.CodeCategories.UserStatusActive).ToList();
                    if (userData.User_Role.Any())
                    {
                        SubsequencActionAfterLoginSucceed(userData, userData.User_Role.FirstOrDefault());
                    }
                    userData.IsLoginSucessed = true;
                    if (userData.User_Role.Count() == 1)
                    {
                        var firstOrDefault = userData.User_Role.FirstOrDefault();
                        if (firstOrDefault != null)
                            _userRepository.UserAuidtTracking(firstOrDefault.Id, AppConstants.UserAuditActions.Login,
                                                              null);
                    }
                    return userData;
                }
                return null;
            }
            return null;
        }


        private void SubsequencActionAfterLoginSucceed(User userData, User_Role userRole)
        {
            var userTheme = AppConfig.DefaultTheme;
            var userPageSize = AppConfig.DefaultPageSize;
            if (userData != null)
            {
                AppContext.CurrentUser = userData;
                //var userRole = userData.User_Role.FirstOrDefault();
                if (userRole != null)
                {
                    AppContext.CurrentUserRole = userRole;
                }
                SetHierarchyDataForCurrentUserRole();
                SetSystemConstant();
                SetDefaultValues();
                SetActionData();
                SetPillarLawRegAreaForCurrentUserRole();

                var userPreference = userData.User_Preference.FirstOrDefault();
                if (userPreference != null)
                {

                    AppContext.CurrentUserTheme = userPreference.Theme_Key;
                    var codeValue =
                        _codeValueRepository.GetSingle(
                            x =>
                            x.Code_ID == userPreference.Page_Size_Id &&
                            x.Code_Value_Key == userPreference.Page_Size_Key);
                    Int32.TryParse(codeValue.Data1, out userPageSize);
                    AppContext.CurrentUserPageSize = userPageSize;
                }
                else
                {
                    AppContext.CurrentUserTheme = userTheme;
                    var codeValue =
                        _codeValueRepository.GetSingle(
                            x =>
                            x.Code_ID == AppConstants.CodeCategories.PageSize &&
                            x.Code_Value_Key == userPageSize.ToString());

                    AppContext.CurrentUserPageSize = Convert.ToInt32(codeValue.Data1);
                }
            }
        }

        [HttpGet]
        public User InvokingImpersonation(int userid, int userRoleId)
        {
            var userData = GetUserDataById(userid);
            if (!userData.IsNull())
            {
                AppContext.ImpersonatingtUser = AppContext.CurrentUser;
                AppContext.ImpersonatingUserRole = AppContext.CurrentUserRole;
                SubsequencActionAfterLoginSucceed(userData,
                                                  userData.User_Role.FirstOrDefault(x => x.Id == userRoleId));
                _userRepository.UserAuidtTracking(AppContext.CurrentUserRole.Id,
                                                  AppConstants.UserAuditActions.Impersonation,
                                                  AppContext.ImpersonatingUserRole.Id);
            }
            return userData;
        }

        [HttpGet]
        public User RollBackImpersonation()
        {
            var userId = AppContext.ImpersonatingtUser.Id;
            var userRoleId = AppContext.ImpersonatingUserRole.Id;
            _userRepository.UserAuidtTracking(AppContext.ImpersonatingUserRole.Id,
                                              AppConstants.UserAuditActions.GobacktoOriginalUser,
                                              AppContext.CurrentUserRole.Id);
            var userData = GetUserDataById(userId);
            if (!userData.IsNull())
            {
                //setting the impseronating user
                AppContext.ImpersonatingtUser = new User();
                AppContext.ImpersonatingUserRole = new User_Role();
                //setting the Current user data

                SubsequencActionAfterLoginSucceed(userData,
                                                  userData.User_Role.FirstOrDefault(x => x.Id == userRoleId));

            }
            return userData;
        }

        [HttpGet]
        public User ChangeRole()
        {
            if (STEP.Common.AppContext.CurrentUser.Id != 0)
            {
                var user = GetUserDataById(STEP.Common.AppContext.CurrentUser.Id);
                var userRoleHierarchyAssoication =
                    STEP.Common.AppContext.CurrentUserRole.User_Role_Hierarchy_Assoication.FirstOrDefault();
                user.User_Role =
                    user.User_Role.Where(
                        x =>
                        userRoleHierarchyAssoication != null && x.Id != userRoleHierarchyAssoication.User_Role_Id
                        ).ToList();
                return user;
            }
            return null;
        }

        [HttpGet]
        public User GetCurrentUser()
        {
            if (STEP.Common.AppContext.CurrentUser.Id != 0)
            {
                var user = GetUserDataById(STEP.Common.AppContext.CurrentUser.Id);
                if (user != null && user.User_Role.Count() == 1)
                {
                    var firstOrDefault = user.User_Role.FirstOrDefault();
                    if (firstOrDefault != null)
                        // UserAuidtTracking(firstOrDefault.Id);
                        _userRepository.UserAuidtTracking(firstOrDefault.Id, AppConstants.UserAuditActions.Login,
                                                              null);
                }
                return user;
            }
            return null;
        }

        private User GetUserDataById(int userid)
        {
            var userData = _userRepository.GetSingle(u => u.Id == userid
                                                     , u => u.User_Role
                                                     ,
                                                     u =>
                                                     u.User_Role
                                                      .Select(x => x.User_Role_Hierarchy_Assoication)
                                                     , u => u.User_Role.Select(x => x.User_Role_Pillar_Association)
                                                     , u => u.User_Preference, u => u.User_Role.Select(x => x.Role)
                                                     ,
                                                     u =>
                                                     u.User_Role.Select(
                                                         x =>
                                                         x.User_Role_Hierarchy_Assoication.Select(
                                                             y => y.Hierarchy_Data))
                );
            userData.User_Role =
                userData.User_Role.Where(x => x.User_Role_Status_Key == AppConstants.CodeCategories.UserStatusActive)
                        .ToList();
            return userData;
        }

        private static void SetAuthCookie(string emailId, string roleId, bool persistant)
        {
            var sUserData = emailId + "|" + roleId;
            FormsAuthentication.SetAuthCookie(sUserData, persistant);
        }

        private void SetSystemConstant()
        {
            var codeIds = new[]
                {
                    AppConstants.CodeCategories.Pillar,
                    AppConstants.CodeCategories.LawReg,
                    AppConstants.CodeCategories.ProgramArea,
                    AppConstants.CodeCategories.SystemConstant,
                };

            var codeValues = _codeValueRepository.FindBy(x => codeIds.Contains(x.Code_ID)).ToList();

            var topNRecords = 0;
            var codeValueRecords =
                codeValues.FirstOrDefault(x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.NumberofRecords));
            if (codeValueRecords != null) Int32.TryParse(codeValueRecords.Data1, out topNRecords);
            AppContext.TopNRecords = topNRecords == 0 ? (int?)null : topNRecords;

            var showTopRecords = false;
            var codeValueAllowTotalRecords =
                codeValues.FirstOrDefault(
                    x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.TotalNumberofRecordsTurnOn));
            if (codeValueAllowTotalRecords != null) bool.TryParse(codeValueAllowTotalRecords.Data1, out showTopRecords);
            AppContext.IsTopRecordsPermitted = showTopRecords;

            var pagesCountToShow = 0;
            var codeValuePagesCountToShow =
                codeValues.FirstOrDefault(x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.PagesCountToShow));
            if (codeValuePagesCountToShow != null)
                Int32.TryParse(codeValuePagesCountToShow.Data1, out pagesCountToShow);
            AppContext.PagesCountToShow = pagesCountToShow == 0 ? 10 : pagesCountToShow;

            // Application Version
            var applicatonVersion =
                codeValues.FirstOrDefault(x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.ApplicationVersion));
            AppContext.ApplicationVersion = string.Empty;
            if (applicatonVersion != null)
            {
                AppContext.ApplicationVersion = applicatonVersion.Data1;
            }

            // Checking If Client Is AMC Or USAR
            var hasAgencyIsAMC = false;
            var codeValueForAgency =
                codeValues.Where(
                    x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.Agency) && x.Data1.Equals(AppConfig.Agency))
                          .ToList();
            if (codeValueForAgency.Any())
            {
                hasAgencyIsAMC = true;
            }
            AppContext.HasAgencyIsAMC = hasAgencyIsAMC;
        }

        private void SetDefaultValues()
        {
            AppContext.CurrentFiscalYear = _fiscalYearRepository.GetFiscalYearBasedOnCurrentDate();
            AppContext.FiscalYears = _fiscalYearRepository.GetAll().ToList();

            //Set Default Value for Project Listing Search Filter
            if (AppContext.ProjectSearchFilter.FiscalYear == 0)
            {
                ProjectSearchFilter searchFilter = AppContext.ProjectSearchFilter;
                searchFilter.FiscalYear = AppContext.CurrentFiscalYear.FY;
                AppContext.ProjectSearchFilter = searchFilter;
            }
            if (AppContext.BudgetExecutionSearchFilter.FiscalYear == 0)
            {
                ProjectSearchFilter budgetExecutionSearchFilterFilter = AppContext.BudgetExecutionSearchFilter;
                budgetExecutionSearchFilterFilter.FiscalYear = AppContext.CurrentFiscalYear.FY;
                AppContext.BudgetExecutionSearchFilter = budgetExecutionSearchFilterFilter;
            }
        }

        private void SetHierarchyDataForCurrentUserRole()
        {
            if (AppContext.CurrentUserRole != null)
            {
                var hierarchyData =
                    _hierarchyDataRepository.SetCurrentUserRoleHierarchyData(
                        AppContext.CurrentUserRole.Role.Hierarchy_Level_Key, AppContext.CurrentUserRole.Id);

                AppContext.CurrentUserRoleHierarchyData = hierarchyData;
            }
        }

        private void SetActionData()
        {
            AppContext.SessionActions = _roleActionRepository.GetActions(AppContext.CurrentUserRole.Role_Id);
        }


        private void SetPillarLawRegAreaForCurrentUserRole()
        {
            if (AppContext.CurrentUser != null)
            {
                var pillarAssociation =
                    _userRolePillarAssociationRepository.GetSingle(
                        x => x.User_Role_Id == AppContext.CurrentUserRole.Id);

                AppContext.CurrentUserRolePillars =
                    _pillarLawRegMappingRepository.GetPillarsByUserRole(pillarAssociation.Pillar_Id,
                                                                        pillarAssociation.Pillar_Key);

                AppContext.CurrentUserRoleLawRegs =
             _pillarLawRegMappingRepository.GetLawRegByUserRole(pillarAssociation.Pillar_Key,
                                                                pillarAssociation.LawReg_Id,
                                                                pillarAssociation.LawReg_Key);
                AppContext.CurrentUserRoleProgramAreas =
                    _pillarLawRegMappingRepository.GetProgramAreaUserRole(pillarAssociation.Pillar_Key,
                                                                          pillarAssociation.LawReg_Key,
                                                                          pillarAssociation.ProgramArea_Id,
                                                                          pillarAssociation.ProgramArea_Key);

                var pillarKeys = AppContext.CurrentUserRolePillars.Select(x => x.PillarKey.ToUpper().ToString()).ToList();
                AppContext.CurrentPB28TitleByPillar = _pillarLawRegMappingRepository.GetPB28Title(pillarKeys);

                var pb28TitleKeys = AppContext.CurrentPB28TitleByPillar.Select(x => x.TitleKey.ToUpper().ToString()).ToList();
                AppContext.CurrentPB28CatagoryByPillarandTitle =
                    _pillarLawRegMappingRepository.GetPB28Category(pillarKeys, pb28TitleKeys);
            }
        }

        [HttpGet]
        public bool SetCurrentUserRoleIfMore(int roleId, string fromWhere)
        {
            int previousCurrentUserRoleId = AppContext.CurrentUserRole.Id;
            if (AppContext.CurrentUser == null) return false;
            AppContext.CurrentUserRole =
                AppContext.CurrentUser.User_Role.FirstOrDefault(x => x.Id.Equals(roleId));
            if (AppContext.CurrentUserRole != null)
            {
                SetHierarchyDataForCurrentUserRole();
                SetPillarLawRegAreaForCurrentUserRole();
                SetActionData();
                _userRepository.UserAuidtTracking(AppContext.CurrentUserRole.Id,
                                                  fromWhere == AppConstants.UserAuditActions.Login
                                                      ? AppConstants.UserAuditActions.Login
                                                      : AppConstants.UserAuditActions.ChangeRole,
                                                  fromWhere == AppConstants.UserAuditActions.Login
                                                      ? (int?)null
                                                      : previousCurrentUserRoleId);
            }
            return true;
        }

        [HttpGet]
        public void PillarLawRegProgramAreaAssocationByUserRole()
        {
            SetPillarLawRegAreaForCurrentUserRole();
        }

        [HttpGet]
        public object GetSessionsData()
        {
            var items = new[]
            {
               new
               {
                   SessionActions=AppContext.SessionActions,
                   CurrentUserRole=AppContext.CurrentUserRole,
                   CurrentUser=AppContext.CurrentUser
               }
            };
            return items;

        }
    }
}