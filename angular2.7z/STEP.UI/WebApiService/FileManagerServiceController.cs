﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using STEP.Models;
using STEP.Common;
using STEP.Repository;
using STEP.Repository.Interfaces;

namespace STEP.WebAPI
{
    public class FileManagerServiceController : ServiceBase
    {
        private readonly IFileManagerRepository _fileManagerRepository;
        private readonly IHelpDocumentsRepository _helpDocumentsRepository;

        public FileManagerServiceController(IFileManagerRepository fileManagerRepository,
                                            IHelpDocumentsRepository helpDocumentsRepository)
        {
            _fileManagerRepository = fileManagerRepository;
            _helpDocumentsRepository = helpDocumentsRepository;
        }

        [HttpPost]
        public ICollection<FileManagerDetails> GetFolderFiles(FileManagerSearchFilter objFileManagerSearchFilter)
        {

            return _fileManagerRepository.GetFolderFiles(objFileManagerSearchFilter);

        }

        [HttpPost]
        public ICollection<FileManagerDetails> GetSearchFiles(FileManagerSearchFilter objFileManagerSearchFilter)
        {
            //AppContext.FileManagerSearchFilter = objFileManagerSearchFilter;
            return _fileManagerRepository.GetSearchFiles(objFileManagerSearchFilter);
        }

        [HttpPost]
        public string uploadFileManagerDocument(Document document)
        {
            return _fileManagerRepository.uploadFileManagerDocument(document);

        }

        [HttpGet]
        public object GetHelpDocuments()
        {
            var fileInfoExistInDb = _helpDocumentsRepository.GetAll().ToList();
            string filePath = HttpContext.Current.Server.MapPath(AppConfig.FileManagerUploadLocation);
            ICollection<FileManagerDetails> filesInPhysicalFolder =
                Directory.GetFiles(filePath)
                         .Select(file => new FileInfo(file))
                         .Select(fileInfo => new FileManagerDetails
                             {
                                 FullName = fileInfo.FullName,
                                 Name = fileInfo.Name,
                             }).ToList();
            var resultFiles = (from fpf in filesInPhysicalFolder

                               join fdb in fileInfoExistInDb on fpf.Name equals fdb.FileName
                               //into fdbInto from fdbIntoLeft in fdbInto.DefaultIfEmpty()
                               select new FileManagerDetails
                                   {

                                       FullName = fpf.FullName,
                                       Name = fpf.Name,
                                       DisplayName = fdb.DisplayName,
                                   }).ToList();
            return resultFiles;
        }
    }
}