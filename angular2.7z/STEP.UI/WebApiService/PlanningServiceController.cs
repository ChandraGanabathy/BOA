﻿using STEP.Common;
using STEP.Models;
using STEP.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace STEP.WebAPI
{
    public class PlanningServiceController : ApiController
    {

        private readonly IHierarchyDataPlanningRepository _hdPlanningRepository;
        private readonly IHierarchyDataRepository _hdRepository;
        private readonly IFiscalYearRepository _fyRepository;
        private readonly IHierarchyDataRepository _hierarchyDataRepository;
        private readonly ICodeValueRepository _codeValueRepository;

        public PlanningServiceController(

            IHierarchyDataPlanningRepository hdPlanningRepository,
            IHierarchyDataRepository hdRepository,
            IFiscalYearRepository fyRepository,
            IHierarchyDataRepository hierarchyDataRepository,
            ICodeValueRepository codeValueRepository)
        {

            _hdPlanningRepository = hdPlanningRepository;
            _fyRepository = fyRepository;
            _hierarchyDataRepository = hierarchyDataRepository;
            _codeValueRepository = codeValueRepository;
            _hdRepository = hdRepository;
        }

        #region Public Methods

        #region PAFG

        [HttpGet]
        public object GetPAFGMasterData()
        {
            int currentFY = AppContext.CurrentFiscalYear.FY;
            var yearlist = _fyRepository.GetAll().Select(x => new {Year = x.FY}).ToList();
            ;
            var propertyList =
                AppContext.CurrentUserRoleHierarchyData.Select(x => new {Property_Text = x.Name, Property_Value = x.Id})
                          .ToList();
            var PAFGList = SearchPAFGs(new PAFGSearchFilter() {Property = string.Empty, FiscalYear = currentFY});

            var PAFGLoadList =
                new {FYList = yearlist, PropertyList = propertyList, PAFGList = PAFGList, CurrentFY = currentFY};

            return PAFGLoadList;
        }

        [HttpPost]
        public IEnumerable<Hierarchy_Data_Planning> SearchPAFGs(PAFGSearchFilter pAFGFilter)
        {

            if (pAFGFilter.FiscalYear == 0)
                pAFGFilter.FiscalYear = AppContext.CurrentFiscalYear.FY;

            var PAFGs = _hdPlanningRepository.SearchPAFGs(pAFGFilter);

            PAFGs.ToList().ForEach(x =>
                {
                    x.Allocation_Status_Key =
                        _codeValueRepository.GetCodeDescription(AppConstants.CodeCategories.PAFGStatus,
                                                                x.Allocation_Status_Key);
                    x.Priority_Status_Key =
                        _codeValueRepository.GetCodeDescription(AppConstants.CodeCategories.PrioritizationStatus,
                                                                x.Priority_Status_Key);
                });

            return PAFGs;

        }

        [HttpGet]
        public List<Hierarchy_Data_Planning> AllocatePAFG(decimal controlAmount, int propertyId, int fiscalYear,
                                                          string selectedProperty)
        {

            List<Hierarchy_Data_Planning> allocatedPAFG = _hdPlanningRepository.AllocatePAFG(controlAmount, propertyId,
                                                                                             fiscalYear,
                                                                                             selectedProperty);
            allocatedPAFG.ToList().ForEach(x =>
                {
                    x.Allocation_Status_Key =
                        _codeValueRepository.GetCodeDescription(AppConstants.CodeCategories.PAFGStatus,
                                                                x.Allocation_Status_Key);
                    x.Priority_Status_Key =
                        _codeValueRepository.GetCodeDescription(AppConstants.CodeCategories.PrioritizationStatus,
                                                                x.Priority_Status_Key);
                });
            return allocatedPAFG;

        }

        [HttpPost]
        public List<Hierarchy_Data_Planning> SavePAFGControlAmount(List<Hierarchy_Data_Planning> hdControlList)
        {

            List<Hierarchy_Data_Planning> savedHDPList = _hdPlanningRepository.SaveControlAmount(hdControlList);
            savedHDPList.ToList().ForEach(x =>
                {
                    x.Allocation_Status_Key =
                        _codeValueRepository.GetCodeDescription(AppConstants.CodeCategories.PAFGStatus,
                                                                x.Allocation_Status_Key);
                    x.Priority_Status_Key =
                        _codeValueRepository.GetCodeDescription(AppConstants.CodeCategories.PrioritizationStatus,
                                                                x.Priority_Status_Key);
                });
            return savedHDPList;
        }


        #endregion

        #region Priority

        [HttpGet]
        public object GetPriorityMasterData()
        {

            var ProjectPriorityLoadList = _hdPlanningRepository.GetProjectPrioritiesMasterData();

            return ProjectPriorityLoadList;
        }


        [HttpPost]
        public object GetProjectPriorities(PrioritizationSearchFilter searchFilter)
        {

            if (searchFilter.FiscalYear == 0)
                searchFilter.FiscalYear = AppContext.CurrentFiscalYear.FY;

            var projectPriorities = _hdPlanningRepository.SearchProjectPriorities(searchFilter);

            return projectPriorities;

        }


        [HttpPost]
        public bool SaveProjectPriorities(List<Project_Funding> projectFundingList)
        {


            if (projectFundingList.Count > 0)
            {
                _hdPlanningRepository.SaveProjectPriorities(projectFundingList,
                                                            AppConstants.CodeCategories.NotPrioritized);
            }
            return true;

        }

        [HttpPost]
        public bool FinalizeProjectPriorities(List<Project_Funding> projectFundingList)
        {


            if (projectFundingList.Count > 0)
            {
                _hdPlanningRepository.SaveProjectPriorities(projectFundingList,
                                                            AppConstants.CodeCategories.PrioritizationCompleted);
            }
            return true;

        }

        #endregion

        #endregion

        #region Private Methods

        #endregion
    }
}
