﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Web.Mvc;
using STEP.Common;
using STEP.Repository;
using STEP.Repository.Interfaces;
using STEP.Models;
using System.Linq;
using System.Collections.Generic;

namespace STEP.WebAPI
{
    public class EmailNotificationServiceController : ServiceBase
    {
        private readonly IEmailNotificationRepository _emailNotificationRepository;
        private readonly IRoleRepository _RoleRepository;
        private readonly ICodeValueRepository _CodeValueRepository;

        public EmailNotificationServiceController(IEmailNotificationRepository emailNotificationRepository,
                                                  IRoleRepository roleRepository,
                                                  ICodeValueRepository codeValueRepository)
        {
            _emailNotificationRepository = emailNotificationRepository;
            _RoleRepository = roleRepository;
            _CodeValueRepository = codeValueRepository;
        }

        [HttpGet]
        public List<Role> GetAllRolesForClient()
        {
                return _RoleRepository.GetAll().ToList();
        }

        /* Upload Document */

        [HttpPost]
        public List<Document> UploadDocument(Document document)
        {
                _emailNotificationRepository.UploadDocument(document);
                return new List<Document>();
        }

        [HttpPost]
        public HttpResponseMessage SendEmailNotification(EmailParam eparam)
        {
            var status = _emailNotificationRepository.SendEmailNotification(eparam.RoleIds, eparam.Subject, eparam.Content,
                                                                          eparam.FilePath, eparam.FileName);
            var operationStatus = new OperationStatus {Status = true};
                if (!string.IsNullOrEmpty(status))
                {
                    eparam.Message = status;
                }
                return ResponseMessage<EmailParam>(eparam, operationStatus);
        }

        public string GetEmailNotificationSignature()
        {
            var codeValues = _CodeValueRepository.GetCodeValues(100);
            var emailNotificationSignature =
                codeValues.FirstOrDefault(
                    x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.EmailNotificationSignature));
            return emailNotificationSignature != null
                       ? emailNotificationSignature.Data1.Replace("\r\n", System.Environment.NewLine)
                       : String.Empty;
        }
    }
}