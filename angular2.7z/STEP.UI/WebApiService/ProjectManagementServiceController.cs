﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using STEP.Common;
using STEP.Models;
using STEP.Models.UIModel;
using STEP.Repository;

namespace STEP.WebAPI
{
    public class ProjectManagementServiceController : ServiceBase
    {
        private readonly ICodeValueRepository _codeValueRepository;
        private readonly IProjectRepository _projectRepository;
        private readonly ICatalogRepository _catalogRepository;
        private readonly IFiscalYearRepository _fiscalYearRepository;
        private readonly ICatalogQuestionsRepository _catalogQuestionsRepository;
        private readonly IApprovalProcessRepository _approvalProcessRepository;
        private readonly IApprovalProcessEmailConfigRepository _approvalProcessEmailConfigRepository;
        private readonly IProjectFundingRepository _projectFundingRepository;
        private readonly IHierarchyDataRepository _hierarchyDataRepository;
        private readonly IAuditRepository _auditRepository;
        private readonly IProjectNoteRepository _projectNoteRepository;
        private readonly IUserRoleRepository _userRoleRepository;
        private readonly IPillarLawRegMappingRepository _pillarLawRegMappingRepository;
        private readonly IUserRepository _userRepository;

        public ProjectManagementServiceController(
            ICodeValueRepository codeValueRepository
            , IProjectRepository projectRepository
            , ICatalogRepository catalogRepository
            , IFiscalYearRepository fiscalYearRepository
            , ICatalogQuestionsRepository catalogQuestionsRepository
            , IApprovalProcessRepository approvalProcessRepository
            , IApprovalProcessEmailConfigRepository approvalProcessEmailConfigRepository
            , IProjectFundingRepository projectFundingRepository
            , IHierarchyDataRepository hierarchyDataRepository
            , IAuditRepository auditRepository
            , IProjectNoteRepository projectNoteRepository
            , IUserRoleRepository userRoleRepository
            , IPillarLawRegMappingRepository pillarLawRegMappingRepository
            , IUserRepository userRepository
            )
        {
            _codeValueRepository = codeValueRepository;
            _projectRepository = projectRepository;
            _catalogRepository = catalogRepository;
            _fiscalYearRepository = fiscalYearRepository;
            _catalogQuestionsRepository = catalogQuestionsRepository;
            _approvalProcessRepository = approvalProcessRepository;
            _approvalProcessEmailConfigRepository = approvalProcessEmailConfigRepository;
            _projectFundingRepository = projectFundingRepository;
            _hierarchyDataRepository = hierarchyDataRepository;
            _auditRepository = auditRepository;
            _projectNoteRepository = projectNoteRepository;
            _userRoleRepository = userRoleRepository;
            _pillarLawRegMappingRepository = pillarLawRegMappingRepository;
            _userRepository = userRepository;
        }

        /*===================== Project Listing API Calls - START =====================*/

        [HttpGet]
        public object GetDataForProjectListingPageLoading(string sharedPageKey)
        {
            var codeValues = GetFundingApprovalStatusCodeValues();
            var getClass = _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.Class).ToList();
            var projectListingDataAtPageLoading = new[]
                {
                    new
                        {
                            GetPillars = AppContext.CurrentUserRolePillars,
                            GetLawRegs = AppContext.CurrentUserRoleLawRegs,
                            GetProgramAreas = AppContext.CurrentUserRoleProgramAreas,
                            GetPB28Titles = AppContext.CurrentPB28TitleByPillar,
                            GetPB28Category = AppContext.CurrentPB28CatagoryByPillarandTitle ,
                            //GetPB28Titles = _pillarLawRegMappingRepository.GetPB28Title(),
                            //GetPB28Category = _pillarLawRegMappingRepository.GetPB28Category(),
                            GetProjectListData =
                                GetProjectListsData(sharedPageKey,
                                                    sharedPageKey ==
                                                    STEP.Common.AppConstants.PageSharedKey.ProjectListing
                                                        ? AppContext.ProjectSearchFilter
                                                        : AppContext.BudgetExecutionSearchFilter),
                            GetCurrentUserRoleHierarchyData = AppContext.CurrentUserRoleHierarchyData,
                            GetFundingApprovalStatus =
                                _codeValueRepository.GetCodeValues(codeValues,
                                                                   AppConstants.CodeCategories.ApprovalStatuss),
                            GetFiscalYears = GetFiscalYears(),
                            GetCurrentFiscalYear = AppContext.CurrentFiscalYear,
                            GetAllImpactMission = GetAllImpactMission(),
                            GetFundingStatus =
                                _codeValueRepository.GetCodeValues(codeValues,
                                                                   AppConstants.CodeCategories.FundingStatus),
                            GetAllClass = getClass
                        }
                };

            return projectListingDataAtPageLoading;
        }

        [HttpPost]
        public object SearchProjects(string sharedPageKey, ProjectSearchFilter searchFilter)
        {
            return GetProjectListsData(sharedPageKey, searchFilter);
        }

        [HttpGet]
        private object GetProjectListsData(string sharedPageKey, ProjectSearchFilter projectSearchFilter)
        {
            if (sharedPageKey ==
                STEP.Common.AppConstants.PageSharedKey.ProjectListing)
            {
                STEP.Common.AppContext.ProjectSearchFilter = projectSearchFilter;
            }
            else
            {
                STEP.Common.AppContext.BudgetExecutionSearchFilter = projectSearchFilter;
            }
            return _projectRepository.GetProjectListsData(projectSearchFilter);

        }

        /*===================== Project Listing API Calls - END =====================*/

        /*===================== ADD/EDIT Project API Calls - START =====================*/

        [HttpGet]
        public object GetProjectDataForPageLoading(int projectId, int catalogId)
        {
            Project getProjectById;
            if (projectId == 0)
            {
                Hierarchy_Data currentUserRoleHierarchyData = null;
                var userRoleHierarchyAssoication =
                    STEP.Common.AppContext.CurrentUserRole.User_Role_Hierarchy_Assoication.FirstOrDefault();
                if (userRoleHierarchyAssoication != null)
                {
                    currentUserRoleHierarchyData = userRoleHierarchyAssoication.Hierarchy_Data;
                }
                getProjectById = new Project
                {
                    Catalog = _catalogRepository.GetSingle(x => x.Id == catalogId
                                                               , x => x.Catalog_Questions
                                                               , x => x.Pillar_LawReg_Mapping
                                                               , x => x.Pillar_PB28_Mapping
                            ),
                    Project_Owner =
                            string.Format("{0} {1}", STEP.Common.AppContext.CurrentUser.First_Name,
                                          STEP.Common.AppContext.CurrentUser.Last_Name),
                    Hierarchy_Data = currentUserRoleHierarchyData,
                    ProjectFiscalYear = STEP.Common.AppContext.CurrentFiscalYear,
                    Owner_ID = STEP.Common.AppContext.CurrentUser.Id,
                    Created_User_Role_Id = STEP.Common.AppContext.CurrentUserRole.Id,
                    RoleName = STEP.Common.AppContext.CurrentUserRole.Role.Name,
                    Is_Recurring = true,
                };
            }
            else
            {
                getProjectById = _projectRepository.GetSingle(x => x.Id == projectId
                                                              , x => x.Catalog
                                                              , x => x.Catalog.Catalog_Questions
                                                              , x => x.Catalog.Pillar_LawReg_Mapping
                                                              , x => x.Catalog.Pillar_PB28_Mapping
                                                              , x => x.Project_Answer
                                                              , x => x.User
                                                              ,
                                                              x => x.Project_Answer.Select(y => y.Catalog_Questions)
                                                              , x => x.Project_Document
                                                              , x => x.Project_Funding
                                                              ,
                                                              x =>
                                                              x.Project_Note,
                                                              x => x.Project_Note.Select(z => z.User_Role.User)

                                                              , x => x.Project_Note.Select(z => z.User_Role.Role)
                                                              , x => x.Hierarchy_Data

                    );

                getProjectById.ProjectFiscalYear = STEP.Common.AppContext.CurrentFiscalYear;
                getProjectById.Project_Owner = string.Format("{0} {1}", getProjectById.User.First_Name,
                                                             getProjectById.User.Last_Name);

                var approvalStatusCodeValues =
                    _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.ApprovalStatuss)
                                        .ToList();

                var fundingStatusCodeValues =
                    _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.FundingStatus)
                                        .ToList();

                getProjectById.Project_Funding.ToList().ForEach(x =>
                {
                    x.ApprovalStatusCodeValue = _codeValueRepository.GetCodeValue(approvalStatusCodeValues,
                                                                                  x.Approval_Status_Id,
                                                                                  x.Approval_Status_Key);
                    if (x.Funding_Status_Code_Id != null)
                        x.FundingStatusCodeValue = _codeValueRepository.GetCodeValue(fundingStatusCodeValues,
                                                                                     x.Funding_Status_Code_Id.Value,
                                                                                     x.Funding_Status_Code_Key);
                });

                // Project_Funding
                getProjectById.Project_Funding =
                    _fiscalYearRepository.ProjectFundingManipulation(getProjectById.Project_Funding.ToList(),
                                                                     STEP.Common.AppContext.FiscalYears);

                // Project Answer 
                var lstAnswerTypesCodeValue =
                    _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.AnswerType)
                                        .ToList();
                getProjectById.Project_Answer.ToList().ForEach(x =>
                {
                    x.Catalog_Questions.CodeValueAnswerType =
                        _codeValueRepository.GetCodeValue(lstAnswerTypesCodeValue,
                                                          x.Catalog_Questions.Answer_Type_Id,
                                                          x.Catalog_Questions.Answer_Type_Key);
                });

                // Project_Note
                getProjectById = ProjectNotePopulation(getProjectById);

                getProjectById = SetApprovalProcessByProjectId(getProjectById);

                getProjectById = ApprovalProcessWorkFlowData(getProjectById);

                getProjectById.IsViewProjectHistoryVisible =
                    _auditRepository.FindBy(x => x.Project_Id == getProjectById.Id).ToList().Any();

            }

            // Set Pillar,LawReg,Program Area Code Value in Pillar_LawReg_Mapping Object

            var pillarCodeValue =
                _codeValueRepository.GetCodeValue(getProjectById.Catalog.Pillar_LawReg_Mapping.Pillar_Id,
                                                  getProjectById.Catalog.Pillar_LawReg_Mapping.Pillar_Key);



            getProjectById.Catalog.Pillar_LawReg_Mapping.PillarCodeValue = pillarCodeValue;


            getProjectById.Catalog.Pillar_LawReg_Mapping.LawRegCodeValue =
                _codeValueRepository.GetCodeValue(getProjectById.Catalog.Pillar_LawReg_Mapping.LawReg_Id,
                                                  getProjectById.Catalog.Pillar_LawReg_Mapping.LawReg_Key);

            getProjectById.Catalog.Pillar_LawReg_Mapping.ProgramAreaCodeValue =
                _codeValueRepository.GetCodeValue(getProjectById.Catalog.Pillar_LawReg_Mapping.ProgramArea_Id,
                                                  getProjectById.Catalog.Pillar_LawReg_Mapping.ProgramArea_Key);

            // Set Pillar,Category,SubCategory Value in Pillar_PB28_Mapping Object

            getProjectById.Catalog.Pillar_PB28_Mapping.PillarCodeValue =
                _codeValueRepository.GetCodeValue(getProjectById.Catalog.Pillar_PB28_Mapping.Pillar_Id,
                                                  getProjectById.Catalog.Pillar_PB28_Mapping.Pillar_Key);

            getProjectById.Catalog.Pillar_PB28_Mapping.TitleCodeValue =
                _codeValueRepository.GetCodeValue(getProjectById.Catalog.Pillar_PB28_Mapping.Title_Id,
                                                  getProjectById.Catalog.Pillar_PB28_Mapping.Title_Key);

            getProjectById.Catalog.Pillar_PB28_Mapping.CategoryCodeValue =
                _codeValueRepository.GetCodeValue(getProjectById.Catalog.Pillar_PB28_Mapping.Category_Id,
                                                  getProjectById.Catalog.Pillar_PB28_Mapping.Category_Key);

            getProjectById.Catalog.Pillar_PB28_Mapping.SubCategoryCodeValue =
                _codeValueRepository.GetCodeValue(getProjectById.Catalog.Pillar_PB28_Mapping.SubCategory_Id,
                                                  getProjectById.Catalog.Pillar_PB28_Mapping.SubCategory_Key);

            var codeIds = new[]
                {
                    AppConstants.CodeCategories.Class,
                    AppConstants.CodeCategories.ResourceSponsor,
                    AppConstants.CodeCategories.MDEP,
                    AppConstants.CodeCategories.ImpacttoMission,
                    AppConstants.CodeCategories.EnvironmentalImpact,
                    AppConstants.CodeCategories.FundingStatus
                };

            var codeValues = _codeValueRepository.FindBy(x => codeIds.Contains(x.Code_ID)).ToList();

            var projectDataForPageLoading = new[]
                {
                    new
                        {
                            GetProjectById = getProjectById,

                            GetCurrentUserRoleHierarchyData = AppContext.CurrentUserRoleHierarchyData,

                            GetClass =
                                _codeValueRepository.GetCodeValues(codeValues, AppConstants.CodeCategories.Class)
                                                    .OrderBy(x => x.SequenceNumber),
                            GetMDEP =
                                _codeValueRepository.GetCodeValues(codeValues, AppConstants.CodeCategories.MDEP),

                            GetImpacttoMission =
                                _codeValueRepository.GetCodeValues(codeValues,
                                                                   AppConstants.CodeCategories.ImpacttoMission)
                                                    .OrderBy(x => x.SequenceNumber),
                            GetEnvironmentalImpact =
                                _codeValueRepository.GetCodeValues(codeValues,
                                                                   AppConstants.CodeCategories.EnvironmentalImpact)
                                                    .OrderBy(x => x.SequenceNumber),
                            GetFundingStatus =
                                _codeValueRepository.GetCodeValues(codeValues,
                                                                   AppConstants.CodeCategories.FundingStatus),
                        }
                };

            return projectDataForPageLoading;
        }

        [HttpPost]
        public Project InsertUpdateProject(Project project)
        {
            if (project.Id == 0)
            {
                var projectBelongsToHierarchyType = project.Hierarchy_Data.Code;
                var projectNumberFormat = string.Empty;
                var codevalue = _codeValueRepository.GetSingle(
                    x =>
                    x.Code_Value_Key.Equals(AppConstants.CodeCategories.ProjectNumberFormatting) &&
                    x.Code_ID.Equals(AppConstants.CodeCategories.ProjectModuleConfig));
                if (codevalue != null)
                {
                    projectNumberFormat = codevalue.Data1;
                }
                var beginFormat = string.Format("{0}{1}{2}", projectBelongsToHierarchyType, projectNumberFormat,
                                                project.Catalog.Pillar_LawReg_Mapping.PillarCodeValue.Code_Value_Key);
                project.Project_Number = string.Format("{0}{1}", beginFormat
                                                       , _projectRepository.GenerateProjectNumber(beginFormat));
                project.Created_By = GetLoggedUserInfo();
                project.Created_Date = CreatedUpdatedDateTime();
                project.Modified_By = GetLoggedUserInfo();
                project.Modified_Date = CreatedUpdatedDateTime();
                // Get No Of Fiscal Year For Project Funding 
                var codeValue = _codeValueRepository.GetCodeValue(AppConstants.CodeCategories.SystemConstant,
                                                                  AppConstants.CodeCategories
                                                                              .NumberOfFiscalYearRowsForFunding);
                //Populate No Of Fiscal Years Rows
                int fiscalYearRows;
                Int32.TryParse(codeValue.Data1, out fiscalYearRows);
                var lstProjectFunding = new List<Project_Funding>();

                var codeValuApprovalStatus =
                    _codeValueRepository.GetCodeValue(AppConstants.CodeCategories.ApprovalStatuss,
                                                      AppConstants.ApprovalStatus.PendingSubmission);
                var codeValueFundingStatus =
                    _codeValueRepository.GetCodeValue(AppConstants.CodeCategories.FundingStatus,
                                                      AppConstants.FundingsStatus.Unfunded);

                var setFiscalYear = project.ProjectFiscalYear.FY;
                for (var i = 0; i < fiscalYearRows; i++)
                {
                    var projectFunding = new Project_Funding
                    {
                        Project_Id = 0,
                        FY = setFiscalYear,
                        Validated = 0,
                        Programmed = 0,
                        Planned = 0,
                        Funded = 0,
                        Obligated = 0,
                        Priority = 0,
                        MSC_Priority = 0,
                        HQ_Priority = 0,
                        MDEP_Id = AppConstants.CodeCategories.MDEP,
                        MDEP_Key = AppConstants.DefaultMDEP.VENQ,
                        Approval_Status_Id = AppConstants.CodeCategories.ApprovalStatuss,
                        Approval_Status_Key = AppConstants.ApprovalStatus.PendingSubmission,
                        Funding_Status_Code_Id = AppConstants.CodeCategories.FundingStatus,
                        Funding_Status_Code_Key = AppConstants.FundingsStatus.Unfunded,
                        ApprovalStatusCodeValue = codeValuApprovalStatus,
                        FundingStatusCodeValue = codeValueFundingStatus,
                        Created_By = GetLoggedUserInfo(),
                        Created_Date = CreatedUpdatedDateTime(),
                        Modified_By = GetLoggedUserInfo(),
                        Modified_Date = CreatedUpdatedDateTime()
                    };
                    setFiscalYear = setFiscalYear + 1;
                    lstProjectFunding.Add(projectFunding);
                }

                project.Project_Funding =
                    _fiscalYearRepository.ProjectFundingManipulation(lstProjectFunding,
                                                                     STEP.Common.AppContext.FiscalYears);

                // Populating Catalog Questions

                var catalogQuestions =
                    _catalogQuestionsRepository.FindBy(
                        x =>
                        x.Catalog_Id == project.Catalog_Id &&
                        (
                            x.End_FY.HasValue == false && x.Start_FY <= project.ProjectFiscalYear.FY
                            ||
                            x.End_FY.HasValue && project.ProjectFiscalYear.FY >= x.Start_FY &&
                            project.ProjectFiscalYear.FY <= x.End_FY.Value)).ToList();

                var lstProjectAnswer = new List<Project_Answer>();

                if (catalogQuestions.Any())
                {
                    foreach (var item in catalogQuestions)
                    {
                        var lstAnswerTypesCodeValue =
                            _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.AnswerType)
                                                .ToList();

                        item.CodeValueAnswerType = _codeValueRepository.GetCodeValue(lstAnswerTypesCodeValue,
                                                                                     item.Answer_Type_Id,
                                                                                     item.Answer_Type_Key);
                        var projectAnswer = new Project_Answer
                        {
                            Project_Id = 0,
                            Catalog_Question_Id = item.Id,
                            FY = project.ProjectFiscalYear.FY,
                            Answer = "",
                            Created_By = GetLoggedUserInfo(),
                            Created_Date = CreatedUpdatedDateTime(),
                            Modified_By = GetLoggedUserInfo(),
                            Modified_Date = CreatedUpdatedDateTime(),
                        };
                        lstProjectAnswer.Add(projectAnswer);
                    }
                }

                var hieraryData = project.Hierarchy_Data;

                project.Hierarchy_Data = null;
                project.Catalog = null;
                project.Project_Answer = lstProjectAnswer;
                _projectRepository.Add(project);
                _projectRepository.Commit();

                project.Project_Answer.ToList().ForEach(x =>
                {
                    x.Catalog_Questions =
                        _catalogQuestionsRepository.GetSingle(z => z.Id == x.Catalog_Question_Id);
                    if (x.Catalog_Questions != null)
                    {
                        x.Catalog_Questions.CodeValueAnswerType =
                            _codeValueRepository.GetSingle(
                                c =>
                                c.Code_ID == x.Catalog_Questions.Answer_Type_Id &&
                                c.Code_Value_Key == x.Catalog_Questions.Answer_Type_Key);
                    }
                });

                project.Hierarchy_Data = hieraryData;
                project = SetApprovalProcessByProjectId(project);
                return project;
            }
            else
            {
                var dataProject = _projectRepository.UpdateProject(project);
                int hierarchyDataId = 0;
                if (dataProject.Hierarchy_Data_Id != null)
                {
                    hierarchyDataId = dataProject.Hierarchy_Data_Id.Value;
                }
                dataProject.Hierarchy_Data =
                    _hierarchyDataRepository.GetSingle(x => x.Id == hierarchyDataId);

                dataProject = ProjectDataAfterUpdate(dataProject);
                dataProject = SetApprovalProcessByProjectId(dataProject);
                // Project_Note
                dataProject = ProjectNotePopulation(dataProject);

                return dataProject;
            }
        }

        [HttpPost]
        public Project ProjectApprovalProcess(Project project)
        {
            var newApprovalStatusToBeUpdate = string.Empty;
            var approvalProcess = new Approval_Process();
            if (project.ApprovalProcess != null &&
                (project.ApprovalProcess.Any() && project.ApprovalProcess.Count() == 1))
            {
                approvalProcess = project.ApprovalProcess.FirstOrDefault();
                if (approvalProcess != null)
                    newApprovalStatusToBeUpdate = approvalProcess.NewStatus_Approval_Status_Key;
            }

            else if (project.ApprovalProcess != null &&
                     (project.ApprovalProcess.Any() && project.ApprovalProcess.Count() > 1))
            {
                //var approvalProcess =
                approvalProcess =
                   project.ApprovalProcess.FirstOrDefault(x => x.Action_Key == project.ApprovalAction);
                if (approvalProcess != null)
                    newApprovalStatusToBeUpdate =
                        approvalProcess
                            .NewStatus_Approval_Status_Key;
            }

            var projectFunding =
                project.Project_Funding.ToList()
                       .FirstOrDefault(y => y.FY == STEP.Common.AppContext.CurrentFiscalYear.FY);

            var updateProjectFunding = _projectFundingRepository.GetSingle(x => x.Id == projectFunding.Id);

            //Updating Validated with Programmed if status to be funding eligible.
            if (newApprovalStatusToBeUpdate == STEP.Common.AppConstants.ApprovalStatus.FundingEligible)
            {
                updateProjectFunding.Validated = updateProjectFunding.Programmed;
            }

            updateProjectFunding.Approval_Status_Key = newApprovalStatusToBeUpdate;
            updateProjectFunding.Modified_By = GetLoggedUserInfo();
            updateProjectFunding.Modified_Date = CreatedUpdatedDateTime();
            _projectFundingRepository.Edit(updateProjectFunding);
            _projectFundingRepository.Commit();

            // Sending Notification for Users 
            ApprovalProcessEmailNotification(project, approvalProcess);

            updateProjectFunding.ApprovalStatusCodeValue =
                _codeValueRepository.GetSingle(
                    x =>
                    x.Code_ID == updateProjectFunding.Approval_Status_Id &&
                    x.Code_Value_Key == updateProjectFunding.Approval_Status_Key);

            var lstProjectFunding = project.Project_Funding.ToList();

            for (var i = 0; i < lstProjectFunding.Count(); i++)
            {
                if (lstProjectFunding[i].Id == updateProjectFunding.Id)
                {
                    updateProjectFunding.FundingStatusCodeValue = lstProjectFunding[i].FundingStatusCodeValue;
                    lstProjectFunding[i] = updateProjectFunding;

                }
            }

            project.Project_Funding = _fiscalYearRepository.ProjectFundingManipulation(lstProjectFunding,
                                                                                       STEP.Common.AppContext
                                                                                           .FiscalYears);

            project = SetApprovalProcessByProjectId(project);

            // Added Entry in project note table for any approval action with Subsystem ref id is funding_Id
            InsertProjectNoteForAnyApprovalAction(project, updateProjectFunding);

            project = ApprovalProcessWorkFlowData(project);

            return project;
        }

        #region Private Functions

        private List<Code_Value> GetFundingApprovalStatusCodeValues()
        {
            var codeValues = _codeValueRepository.FindBy(x =>
                                                         (x.Code_ID == AppConstants.CodeCategories.PB28Title &&
                                                          x.Code_Value_Key.ToUpper() !=
                                                          AppConstants.CodeCategories.ALL.ToUpper())
                                                         ||
                                                         (x.Code_ID == AppConstants.CodeCategories.PB28Category &&
                                                          x.Code_Value_Key.ToUpper() !=
                                                          AppConstants.CodeCategories.ALL.ToUpper()
                                                          ||
                                                          x.Code_ID ==
                                                          AppConstants.CodeCategories.ApprovalStatuss
                                                         )
                                                         ||
                                                         (x.Code_ID ==
                                                          AppConstants.CodeCategories.FundingStatus)

                ).ToList();
            return codeValues;
        }

        private object GetFiscalYears()
        {
            var getFiscalYears = STEP.Common.AppContext.FiscalYears.Select(x => new
            {
                x.Id,
                x.FY
            }).ToList();
            return getFiscalYears;
        }

        private void ApprovalProcessEmailNotification(Project project, Approval_Process approvalProcess)
        {
            var approvalEmailConfig =
                _approvalProcessEmailConfigRepository.GetSingle(x => x.Approval_Process_Id == approvalProcess.Id,
                                                                x => x.Role);
            if (approvalEmailConfig == null) return;

            if (project.Owner_ID != null && project.Hierarchy_Data_Id != null)
            {

                var users = _userRepository.GetUsersForApprovalNotification(approvalEmailConfig,
                                                                            project.Hierarchy_Data_Id.Value,
                                                                            project.Owner_ID.Value,
                                                                            approvalProcess.Project_Type_Key);
                if (users == null) return;
                var enumerable = users as IList<User> ?? users.ToList();
                if (enumerable.Any())
                {
                    var userEmailIds = enumerable.Select(x => x.Email_Id).ToList();
                    var strEmailtoUsers = userEmailIds.Aggregate(string.Empty, (current, item) => current + (item + ";"));

                    // For Testing Purpose [Start] and comment below lines when doing actual configuration.
                    var testUsers = new List<string>
                        {
                            "sankar@ilink-systems.com",
                            //"syedarifm@ilink-systems.com",
                            //"pandeeshwarip@ilink-systems.com"
                        };
                    strEmailtoUsers = testUsers.Aggregate(string.Empty, (current, item) => current + (item + ";"));
                    //For Testing Purpose [End]

                    if (SendEmailEnabled())
                    {
                        var subject = string.Format(approvalEmailConfig.Subject, project.Project_Number);
                        var content = string.Format(approvalEmailConfig.Message, project.Project_Number,
                                                    approvalEmailConfig.Role == null
                                                        ? string.Empty
                                                        : approvalEmailConfig.Role
                                                                             .Name);
                        // Uncomment below email code when going to staging/production. Make sure that email server configuration is avaliable

                        /*var strMessage = new MailMessages().SendEmailNotification(strEmailtoUsers, string.Empty, subject,
                                                                                  content, string.Empty,
                                                                                  string.Empty);*/

                    }
                }
            }
        }

        private Project ProjectNotePopulation(Project dataProject)
        {
            if (dataProject.Project_Note != null && dataProject.Project_Note.Any())
            {
                dataProject.Project_Note.ToList().ForEach(x =>
                {
                    if (x.User_Role == null)
                    {
                        var userRole =
                            _userRoleRepository.AllIncluding(y => y.Role, y => y.User)
                                               .FirstOrDefault(y => y.Id == x.User_Role_Id);
                        if (userRole != null)
                        {
                            x.RoleName = userRole.Role.Name;
                            x.Created_By = string.Format("{0} {1} {2}", userRole.User.First_Name,
                                                         userRole.User.Last_Name, userRole.User.Middle_Name);
                        }
                    }
                    else
                    {
                        x.RoleName = x.User_Role.Role.Name;
                        x.Created_By = string.Format("{0} {1} {2}", x.User_Role.User.First_Name,
                                                     x.User_Role.User.Last_Name, x.User_Role.User.Middle_Name);
                    }

                });
                // In Project Note Get Recorod only type is manual since it was getting inserted through UI only
                dataProject.Project_Note =
                    dataProject.Project_Note.ToList()
                               .Where(x => x.Type_Key == AppConstants.Types.Manual)
                               .ToList();
            }
            return dataProject;
        }

        private Project SetApprovalProcessByProjectId(Project project)
        {
            var projectFunding = project.Project_Funding.ToList().FirstOrDefault(
                y => y.FY == STEP.Common.AppContext.CurrentFiscalYear.FY);

            //if (project.Created_User_Role_Id != null && (project.Owner_ID == AppContext.CurrentUser.Id &&
            //                                             project.Created_User_Role_Id.Value ==
            //                                             AppContext.CurrentUserRole.Id))
            //{
            project.Project_Funding.ToList().ForEach(x =>
            {
                /* if (projectFunding != null &&
                     (x.FY == projectFunding.FY
                      && project.Owner_ID == STEP.Common.AppContext.CurrentUser.Id
                      &&
                     (x.Approval_Status_Key == AppConstants.ApprovalStatus.PendingSubmission
                      || x.Approval_Status_Key == AppConstants.ApprovalStatus.FundingEligible
                       //|| x.Approval_Status_Key == AppConstants.ApprovalStatus.FundingIneligible

                      // Added later
                      || x.Approval_Status_Key == AppConstants.ApprovalStatus.InstallationAdminDisapproved
                      || x.Approval_Status_Key == AppConstants.ApprovalStatus.MSCAdminDisapproved

                    )
                     )
                     )
                {
                    x.IsCurrentRequiredEditable = true;
                 }*/

                // Programmed and MDEP will be editable for project owner when the project is in funding eligible status or pending submission 
                if (x.IsCurrentRequiredEditable == true && project.Owner_ID == STEP.Common.AppContext.CurrentUser.Id
                    &&
                    (x.Approval_Status_Key == AppConstants.ApprovalStatus.PendingSubmission
                     || x.Approval_Status_Key == AppConstants.ApprovalStatus.FundingEligible
                     // Added later
                     || x.Approval_Status_Key == AppConstants.ApprovalStatus.InstallationAdminDisapproved
                     || x.Approval_Status_Key == AppConstants.ApprovalStatus.MSCAdminDisapproved

                    )
                    )
                {
                    x.IsCurrentRequiredEditable = true;
                }
                else
                {
                    x.IsCurrentRequiredEditable = false;
                }

                /*
                //Obligated will be available for editing for project
                //owner when the project is in funding eligible status
                if (project.Owner_ID == STEP.Common.AppContext.CurrentUser.Id
                    &&
                    (
                        x.Approval_Status_Key == AppConstants.ApprovalStatus.FundingEligible
                    )
                    )
                {
                    x.IsObligatedEditable = true;
        }
                else
                {
                    x.IsObligatedEditable = false;
                }*/

                //Obligated Amount editable by Project Owner at any time 
                if (x.IsObligatedEditable && project.Owner_ID == STEP.Common.AppContext.CurrentUser.Id)
                {
                    x.IsObligatedEditable = true;
                }
                else
                {
                    x.IsObligatedEditable = false;
                }

                if (project.Owner_ID == AppContext.CurrentUser.Id && x.FY == AppContext.CurrentFiscalYear.FY)
                {
                    x.IsUFREditable = true;
                }
                else
                {
                    x.IsUFREditable = false;
                }

            });
            // }

            if (projectFunding != null)
            {
                // Condition [ Role,Type Of Project (HQ,MSC,Installation) & Cuurent Approval Status ]
                var approvalProcess = _approvalProcessRepository.FindBy(
                    x => x.Role_Id == STEP.Common.AppContext.CurrentUserRole.Role_Id
                         && x.Project_Type_Key == project.Hierarchy_Data.Hierarchy_Level_Key
                         && x.CurrentStatus_Approval_Status_Key == projectFunding.Approval_Status_Key
                    ).ToList();

                project.ApprovalProcess = approvalProcess;

                project.IsSubmitForApprovalVisible =
                    approvalProcess.Any(x => x.Action_Key == AppConstants.ApprovalActions.SubmitForApproval) &&
                    STEP.Common.AppContext.CurrentUser.Id == project.Owner_ID;

                project.IsApproveVisible =
                    approvalProcess.Any(x => x.Action_Key == AppConstants.ApprovalActions.Approve);

                project.IsDisapproveVisible =
                    approvalProcess.Any(x => x.Action_Key == AppConstants.ApprovalActions.Disapprove);
            }
            return project;
        }

        private Project ProjectDataAfterUpdate(Project dataProject)
        {
            var ids =
                dataProject.Project_Answer.Select(
                    y => y.Catalog_Question_Id != null ? y.Catalog_Question_Id.Value : 0).ToList();

            var catalogQuestions =
                _catalogQuestionsRepository.FindBy(
                    x => ids.Contains(x.Id)).ToList();

            var lstProjectAnswer = dataProject.Project_Answer.ToList();
            for (var i = 0; i < lstProjectAnswer.Count(); i++)
            {
                var lstAnswerTypesCodeValue =
                    _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.AnswerType)
                                        .ToList();

                var cQuestions =
                    catalogQuestions.FirstOrDefault(x => x.Id == lstProjectAnswer[i].Catalog_Question_Id);

                if (cQuestions != null)
                {
                    cQuestions.CodeValueAnswerType = _codeValueRepository.GetCodeValue(lstAnswerTypesCodeValue,
                                                                                       cQuestions
                                                                                           .Answer_Type_Id,
                                                                                       cQuestions
                                                                                           .Answer_Type_Key);
                    lstProjectAnswer[i].Catalog_Questions = cQuestions;
                }
            }

            dataProject.Project_Answer = lstProjectAnswer;

            var approvalStatusCodeValues =
                _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.ApprovalStatuss)
                                    .ToList();
            var fundingStatusCodeValues =
                _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.FundingStatus)
                                    .ToList();

            dataProject.Project_Funding.ToList().ForEach(x =>
            {
                if (x.Approval_Status_Id != null)
                    x.ApprovalStatusCodeValue = _codeValueRepository.GetCodeValue(approvalStatusCodeValues,
                                                                                      x.Approval_Status_Id,
                                                                                  x.Approval_Status_Key);

                if (x.Funding_Status_Code_Id != null)
                    x.FundingStatusCodeValue = _codeValueRepository.GetCodeValue(fundingStatusCodeValues,
                                                                                 x.Funding_Status_Code_Id.Value,
                                                                                 x.Funding_Status_Code_Key);
            });

            dataProject.Project_Funding =
                _fiscalYearRepository.ProjectFundingManipulation(dataProject.Project_Funding.ToList(),
                                                                 STEP.Common.AppContext.FiscalYears);

            // Pouplate Funding Status work flow data for each funding id
            dataProject = ApprovalProcessWorkFlowData(dataProject);

            return dataProject;
        }

        private Project ApprovalProcessWorkFlowData(Project project)
        {
            var approvalStatusCodeValues =
                _codeValueRepository.FindBy(x => x.Code_ID == AppConstants.CodeCategories.ApprovalStatuss)
                                    .ToList();

            if (project.Project_Funding != null && project.Project_Funding.Any())
            {

                project.Project_Funding.ToList().ForEach(x =>
                {
                    var approvalWorkFlowData = _projectNoteRepository.AllIncluding(y => y.User_Role
                                                                                   , y => y.User_Role.Role
                                                                                   , y => y.User_Role.User)
                                                                     .Where(y => y.SubSystem_Ref_Id == x.Id)
                                                                     .OrderByDescending(y => y.Modified_Date)
                                                                     .ToList();
                    approvalWorkFlowData.ForEach(m =>
                    {
                        if (m.Approval_Status_Id != null)
                            m.ApprovalStatusCodeValue =
                                _codeValueRepository.GetCodeValue(approvalStatusCodeValues,
                                                                  m.Approval_Status_Id.Value,
                                                                  m.Approval_Status_Key);
                        m.RoleName = m.User_Role.Role.Name;
                        m.Created_By = string.Format("{0} {1} {2}", m.User_Role.User.First_Name,
                                                     m.User_Role.User.Last_Name, m.User_Role.User.Middle_Name);
                    });
                    x.ApprovalProcessWorkFlow = approvalWorkFlowData;
                });
            }
            return project;
        }

        private void InsertProjectNoteForAnyApprovalAction(Project project, Project_Funding updateProjectFunding)
        {
            var projectNote = new Project_Note
            {
                Project_Id = project.Id,
                Type_Id = AppConstants.CodeCategories.Type,
                Type_Key = AppConstants.Types.Approval,
                User_Role_Id = STEP.Common.AppContext.CurrentUserRole.Id,
                Notes = project.ApproveDisapproveNotes,
                SubSystem_Ref_Id = updateProjectFunding.Id,
                Approval_Status_Id = updateProjectFunding.Approval_Status_Id,
                Approval_Status_Key = updateProjectFunding.Approval_Status_Key,
                Created_By = GetLoggedUserInfo(),
                Created_Date = CreatedUpdatedDateTime(),
                Modified_By = GetLoggedUserInfo(),
                Modified_Date = CreatedUpdatedDateTime()
            };

            _projectNoteRepository.Add(projectNote);
            _projectNoteRepository.Commit();
        }

        #endregion

        [HttpGet]
        public object ViewProjectHistoryByProjectId(int projectId)
        {
            var projectHistory = _projectRepository.ViewProjectHistoryByProjectId(projectId);
            return projectHistory;
        }

        /*===================== ADD/EDIT Project API Calls - END =====================*/

        /*===================== Budget Execution API Calls - START =====================*/

        [HttpPost]
        public bool BudgetExecutionUpdate(List<Project_Funding> projectFunding)
        {
            var result = _projectRepository.ProjectFundingBulkUpdate(projectFunding);
            return result;
        }

        /*===================== Budget Execution API Calls - END =====================*/

        [HttpGet]
        public object MyInboxProjects(ProjectSearchFilter projectSearchFilter)
        {
            var projects = _projectRepository.MyInboxProjects();
            return projects;
        }

        [HttpGet]
        public object GetDataForDashboard()
        {
            var lstStatus = new List<string>
                    {
                        AppConstants.ApprovalStatus.FundingEligible
                    };
            var lstHId = AppContext.CurrentUserRoleHierarchyData.Select(x => x.Id).ToList();

            var searchFilter = new KpiFilter
            {
                AmountType = "Funded",
                FY = STEP.Common.AppContext.CurrentFiscalYear.FY,
                ProjectStatusesData = lstStatus,
                RoleHierarchyData = lstHId
            };

            var dashboardData = new[]
                    {
                        new
                            {
                                MyProjects = _projectRepository.MyProjects(AppContext.CurrentUser.Id,
                                                                   AppContext.CurrentFiscalYear),
                                PFChartData =
                                    _projectRepository.PFChartData(AppContext.CurrentUserRoleHierarchyData,
                                                                   AppContext.CurrentFiscalYear),
                                PercentFundChartData =
                                    _projectRepository.PercentFundedChartDetailsData(searchFilter),
                                ApprovalInboxProjects = _projectRepository.GetMyApprovalInboxProjects()
                            }
                    };

            return dashboardData;
        }

        [HttpGet]
        public object GetDataForDashboardMyInboxPageLoading()
        {
            return GetProjectListsData(STEP.Common.AppConstants.PageSharedKey.ProjectListing, STEP.Common.AppContext.ProjectSearchFilter);
        }

        [HttpGet]
        public object GetDataForDashboardChartDetails()
        {
            var DashboardData = new[]
                    {
                        new
                            {
                                Fiscal_Years = STEP.Common.AppContext.FiscalYears,
                                RoleHierarchyData = STEP.Common.AppContext.CurrentUserRoleHierarchyData.OrderBy(x => x.Name),
                                PFChartData =
                                    _projectRepository.PFChartData(AppContext.CurrentUserRoleHierarchyData,
                                                                   AppContext.CurrentFiscalYear),
                                PercentFundChartData =
                                    _projectRepository.PercentFundChartData(AppContext.CurrentUserRoleHierarchyData),
                                Pillars = STEP.Common.AppContext.CurrentUserRolePillars,
                                LawRegs = STEP.Common.AppContext.CurrentUserRoleLawRegs,
                                ProgramAreas = STEP.Common.AppContext.CurrentUserRoleProgramAreas,
                                CurrentFY = STEP.Common.AppContext.CurrentFiscalYear.FY,
                                ProjectStatusesData = _projectRepository.GetProjectStatuses()
                            }
                    };

            return DashboardData;
        }

        [HttpPost]
        public object PFChartDetailsData(KpiFilter searchFilter)
        {
            return _projectRepository.PFChartDetailsData(searchFilter);
        }

        [HttpPost]
        public object PercentFundedChartDetailsData(KpiFilter searchFilter)
        {
            return _projectRepository.PercentFundedChartDetailsData(searchFilter);
        }

        #region changing project owner"

        [HttpGet]
        private object GetProjectOwnerData(ProjectOwnerSearchFilter projectOwnerFilter)
        {
            STEP.Common.AppContext.ProjectOwnerSearchFilter = projectOwnerFilter;
            return _projectRepository.GetProjectOwnerListData(projectOwnerFilter);
        }

        [HttpPost]
        public bool UpdateOwnerList(List<ProjectOwnerDetails> projectOwnerDetails)
        {
            return _projectRepository.UpdateOwnerList(projectOwnerDetails);
        }

        [HttpPost]
        public object SearchProjectOwner(ProjectOwnerSearchFilter projectOwnerFilter)
        {
            return GetProjectOwnerData(projectOwnerFilter);
        }

        [HttpGet]
        public object GetAllusers()
        {
            return _projectRepository.GetAllusers();
        }

        [HttpGet]
        public object GetDataForProjectOwnerPageLoading()
        {
            var codeValues = _codeValueRepository.FindBy(x =>
                                                         (x.Code_ID == AppConstants.CodeCategories.PB28Title &&
                                                          x.Code_Value_Key.ToUpper() !=
                                                          AppConstants.CodeCategories.ALL.ToUpper())
                                                         ||
                                                         (x.Code_ID == AppConstants.CodeCategories.PB28Category &&
                                                          x.Code_Value_Key.ToUpper() !=
                                                          AppConstants.CodeCategories.ALL.ToUpper()
                                                          ||
                                                          x.Code_ID ==
                                                          AppConstants.CodeCategories.ApprovalStatuss
                                                         )
                ).ToList();



            var projectOwnerDataAtPageLoading = new[]
                    {
                        new
                            {
                                GetPillars = AppContext.CurrentUserRolePillars,
                                GetLawRegs = AppContext.CurrentUserRoleLawRegs,
                                GetProgramAreas = AppContext.CurrentUserRoleProgramAreas,
                                GetProjectOwnerData = GetProjectOwnerData(AppContext.ProjectOwnerSearchFilter),
                                GetCurrentUserRoleHierarchyData = AppContext.CurrentUserRoleHierarchyData,
                                GetProjectOwner = AppContext.CurrentUser,
                                GetAllUsers = GetAllusers(),
                            GetAllImpactMission = GetAllImpactMission(),
                            }
                    };

            return projectOwnerDataAtPageLoading;


        }

        [HttpGet]
        public object GetAllImpactMission()
        {
            return _projectRepository.GetAllImpactMission();
        }

        #endregion

        #region Roles and Actions"

        [HttpGet]
        public object GetDataForRolesActionPageLoading()
        {
            var RoleActionDataAtPageLoading = new[]
                    {
                        new
                            {
                            GetRoleData = GetRoleData(),
                               GetActionData = GetActionData()

                            }
                    };

            return RoleActionDataAtPageLoading;
        }

        [HttpGet]
        public object GetRoleActionData(int RoleId)
        {
            return _projectRepository.GetRoleActionData(RoleId);
        }

        [HttpGet]
        private object GetRoleData()
        {
            return _projectRepository.GetRoleListData();

        }

        [HttpGet]
        private object GetActionData()
        {
            return _projectRepository.GetActionListData();

        }

        [HttpPost]
        public bool UpdateRoleActionList(List<Roles> role)
        {
            return _projectRepository.UpdateRoleActionList(role);
        }

        #endregion

        [HttpGet]
        public object GetHelptext(int codeId)
        {
            var helptexts =
                _codeValueRepository.FindBy(x => x.Code_ID == codeId).OrderBy(x => x.SequenceNumber).Select(x => new
                {
                    x.Code_Value_Description,
                    x.Data1
                }).ToList();
            return helptexts;

        }
    }
}
