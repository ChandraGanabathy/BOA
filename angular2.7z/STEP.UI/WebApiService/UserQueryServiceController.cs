﻿using System;
using System.Web.Http;
using STEP.Repository;

namespace STEP.WebAPI
{
    public class UserQueryServiceController : ServiceBase
    {
      private readonly IUserRepository _userRepository;

      public UserQueryServiceController(IUserRepository userRepository)
      {
          _userRepository = userRepository;
      }

        [HttpPost]
        public dynamic ExecuteAdminQuery(object sqlQuery)
        {
                return _userRepository.ExecuteAdminQuery(sqlQuery as string);
            }

        [HttpGet]
        public string GetAdminSecuritytext()
        {
                return _userRepository.GetAdminSecuritytext();
            }
    }
}
