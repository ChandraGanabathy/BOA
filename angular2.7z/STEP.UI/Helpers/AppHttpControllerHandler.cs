﻿using System.Web;
using System.Web.Http.WebHost;
using System.Web.Routing;
using System.Web.SessionState;

namespace STEP.Helpers 
{
    public class AppHttpControllerHandler : HttpControllerHandler, IRequiresSessionState
    {
        public AppHttpControllerHandler(RouteData routeData)
            : base(routeData)
        {
        }
    }

    public class AppHttpControllerRouteHandler : HttpControllerRouteHandler
    {
        protected override IHttpHandler GetHttpHandler(RequestContext requestContext)
        {
            return new AppHttpControllerHandler(requestContext.RouteData);
        }
    } 
}