﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;
using System.Security.Cryptography;
using System.Web.Mvc;
using STEP.Common;

namespace STEP.Helpers
{
    public static class UIHelper
    {
        private static readonly MD5CryptoServiceProvider Md5 = new MD5CryptoServiceProvider();
        private static readonly Dictionary<string, Guid> FileHash = new Dictionary<string, Guid>();

        public static MvcHtmlString Image(this HtmlHelper helper, string imageName, string altText = "")
        {
            var builder = new TagBuilder("img");
            builder.MergeAttribute("src", AppConstants.ImageFolderPath + imageName);
            builder.MergeAttribute("alt", altText);
            return MvcHtmlString.Create(builder.ToString(TagRenderMode.SelfClosing));
        }

        public static MvcHtmlString ImageBox(this HtmlHelper html, string imagePath, string hoverText, string alt = "", string classAttr = "")
        {

            var url = new UrlHelper(html.ViewContext.RequestContext);
            var imgBuilder = new TagBuilder("img");
            imgBuilder.MergeAttribute("src", url.Content(imagePath));
            imgBuilder.MergeAttribute("alt", alt);
            string imgHtml = imgBuilder.ToString(TagRenderMode.SelfClosing);
            imgHtml += hoverText;
            var spanBuilder = new TagBuilder("span");
            spanBuilder.InnerHtml = imgHtml;
            string spanHtml = spanBuilder.ToString();
            var sectionBuilder = new TagBuilder("section");
            sectionBuilder.MergeAttribute("class", classAttr);
            sectionBuilder.InnerHtml = spanHtml;
            string sectionHtml = sectionBuilder.ToString(TagRenderMode.Normal);
            return MvcHtmlString.Create(sectionHtml);
        }


        public static MvcHtmlString PropertyTokenInput(this HtmlHelper html, string elementId, string optionValues)
        {
            var url = new UrlHelper(html.ViewContext.RequestContext);
            var inpBuilder = new TagBuilder("input");
            inpBuilder.MergeAttribute("type", "text");
            inpBuilder.MergeAttribute("id", elementId);

            var spanHtml = new TagBuilder("span");
            spanHtml.MergeAttribute("style", "display:none");

            var tag = new TagBuilder("ul");
            tag.MergeAttribute("data-bind", "foreach:" + optionValues);
            var itemTag = new TagBuilder("li");
            itemTag.MergeAttribute("data-bind", "click:function(data,event){ $parent.changePropertyToSearch(data,event)},attr:{id:name},text:name");
            tag.InnerHtml = itemTag.ToString();

            var divHtml = new TagBuilder("div");
            divHtml.MergeAttribute("onClick", "customSelect(this,event)");
            divHtml.AddCssClass("custom-select");
            divHtml.InnerHtml = spanHtml.ToString();
            divHtml.InnerHtml += tag.ToString();

            var divWrapper = new TagBuilder("div");
            divWrapper.InnerHtml = inpBuilder.ToString();
            divWrapper.InnerHtml += divHtml.ToString();
            return MvcHtmlString.Create(divWrapper.ToString());
        }
        /// <summary>
        /// Appends the hash of the file as a querystring parameter to a supplied string.
        /// </summary>
        /// <param name="fname">The filename.</param>
        /// <param name="request">The current HttpRequest.</param>
        /// <returns>String with hash of the file appended.</returns>
        public static string AppendHash(this string fname, HttpRequest request)
        {
            return String.Format(@"{0}?hash={1}", fname, GetFileHash(fname, request));
        }

        /// <summary>
        /// Returns a hash of the supplied file.
        /// </summary>
        /// <param name="fname">The name of the file.</param>
        /// <param name="request">The current HttpRequest.</param>
        /// <returns>A Guid representing the hash of the file.</returns>
        public static Guid GetFileHash(string fname, HttpRequest request)
        {
            Guid hash;
            var localPath = request.RequestContext.HttpContext.Server.MapPath(fname.Replace('/', '\\'));

            using (var ms = new MemoryStream())
            {
                using (var fs = new FileStream(localPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    StreamCopy(fs, ms);
                }

                hash = new Guid(Md5.ComputeHash(ms.ToArray()));
                Guid check;
                if (!FileHash.TryGetValue(localPath, out check))
                {
                    FileHash.Add(localPath, hash);
                }
                else if (check != hash)
                {
                    FileHash[localPath] = hash;
                }
            }

            return hash;
        }

        /// <summary>
        /// Copies from one Stream to another.
        /// </summary>
        /// <param name="from">The Stream to copy from.</param>
        /// <param name="to">The Stream to copy to.</param>
        public static void StreamCopy(Stream from, Stream to)
        {
            if (from == to)
            {
                return;
            }

            var buffer = new byte[4096];

            from.Seek(0, SeekOrigin.Begin);

            while (true)
            {
                var done = from.Read(buffer, 0, 4096);

                if (done <= 0)
                {
                    return;
                }

                to.Write(buffer, 0, done);
            }
        }


    }

    public static class App
    {
        public static string StartupTimeStamp { get; set; }
    }

    public class Bootstrap
    {
        public const string BundleBase = "~/BootStrap/css/";

        public class Theme
        {
            public const string Green = "GREN";
            public const string Orange = "ORNG";
            public const string Blue = "BLUE";
        }

        public static HashSet<string> Themes = new HashSet<string>
            {
                Theme.Green,
                Theme.Orange,
                Theme.Blue
            };

        public static string Bundle(string themename)
        {
            return BundleBase + themename;
        }
    }
}