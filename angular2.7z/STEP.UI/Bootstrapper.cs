using System.Web.Http;
using System.Web.Mvc;
using STEP.Repository;
using STEP.Repository.Interfaces;
using Microsoft.Practices.Unity;
using Unity.Mvc4;

namespace STEP
{
    public static class Bootstrapper
    {
        public static IUnityContainer Container { get; set; }

        public static void Initialise()
        {
            Container = BuildUnityContainer();
            DependencyResolver.SetResolver(new UnityDependencyResolver(Container));
            GlobalConfiguration.Configuration.DependencyResolver = new Unity.WebApi.UnityDependencyResolver(Container);
        }

        private static IUnityContainer BuildUnityContainer()
        {
            var container = new UnityContainer();
            // register all your components with the container here
            container.RegisterType<IFileManagerRepository, FileManagerRepository>();
            //Register User Module  in the container
            container.RegisterType<IUserRepository, UserRepository>();
            container.RegisterType<IUserRoleRepository, UserRoleRepository>();
            container.RegisterType<IHierarchyDataRepository, HierarchyDataRepository>();
            container.RegisterType<IUserHierarchyAssociationRepository, UserHierarchyAssociationRepository>();
            container.RegisterType<IUserRolePillarAssociationRepository, UserRolePillarAssociationRepository>();
            container.RegisterType<IUserPreferenceRepository, UserPreferenceRepository>();
            container.RegisterType<IUserAuditRepository, UserAuditRepository>();
            container.RegisterType<IEmailNotificationRepository, EmailNotificationRepository>();
            container.RegisterType<IRoleRepository, RoleRepository>();
            container.RegisterType<ICodeValueRepository, CodeValueRepository>();
            container.RegisterType<IRoleMappingRepository, RoleMappingRepository>();
            // Register Catalog Module in Container
            container.RegisterType<ICatalogRepository, CatalogRepository>();
            container.RegisterType<ICodeValueRepository, CodeValueRepository>();
            container.RegisterType<IAMSCORepository, AMSCORepository>();
            container.RegisterType<ICatalogAMSCORepository, CatalogAMSCORepository>();
            container.RegisterType<ICatalogQuestionsRepository, CatalogQuestionsRepository>();
            container.RegisterType<IFiscalYearRepository, FiscalYearRepository>();
            container.RegisterType<IPillarPB28MappingRepository, PillarPB28MappingRepository>();
            container.RegisterType<IPillarLawRegMappingRepository, PillarLawRegMappingRepository>();
            container.RegisterType<IMDEPRepository, MDEPRepository>();
            // Register Planning Module in Container
            container.RegisterType<IHierarchyDataPlanningRepository, HierarchyDataPlanningRepository>();
            // Register Project Module in Container
            container.RegisterType<IProjectRepository, ProjectRepository>();
            container.RegisterType<IProjectAnswerRepository, ProjectAnswerRepository>();
            container.RegisterType<IProjectDocumentRepository, ProjectDocumentRepository>();
            container.RegisterType<IProjectFundingRepository, ProjectFundingRepository>();
            container.RegisterType<IProjectNoteRepository, ProjectNoteRepository>();
            container.RegisterType<IApprovalProcessRepository, ApprovalProcessRepository>();
            container.RegisterType<IApprovalProcessEmailConfigRepository, ApprovalProcessEmailConfigRepository>();
            container.RegisterType<IAuditRepository, AuditRepository>();
            container.RegisterType<IAuditDetailsRepository, AuditDetailsRepository>();
            container.RegisterType<IAuditDisplayRepository, AuditDisplayRepository>();
            container.RegisterType<IRoleActionRepository, RoleActionRepository>();
            container.RegisterType<IHelpDocumentsRepository, HelpDocumentsRepository>();
            return container;
        }
    }
}