﻿using System;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Tracing;
using System.Web.Mvc;
using System.Web.Security;
using STEP.Common;
using STEP.Helpers;

namespace STEP.UI.Controllers
{
    public class AuthorizationAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (AppContext.CurrentUser == null || AppContext.CurrentUser.Id == 0)
            {
                FormsAuthentication.SignOut();
                string sessionRedirectUrl =
                    System.Configuration.ConfigurationManager.AppSettings.Get("SessionTimeoutRedirect");
                filterContext.Result = new RedirectResult(sessionRedirectUrl);
                return;
            }

            string actionName = filterContext.ActionDescriptor.ActionName;
            string controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            var firstOrDefault = AppContext.CurrentUser.User_Role.FirstOrDefault();
            if (firstOrDefault != null &&
                (filterContext.ParentActionViewContext == null && !String.IsNullOrWhiteSpace(actionName) &&
                 firstOrDefault.Role.Id != 0))
            {
                var actionsList = AppContext.SessionActions;
                if (actionsList.Any(x => x.Action_Name.ToUpper().Equals((actionName.Trim().ToUpper()))
                                         &&
                                         x.Controller_Name.ToUpper()
                                          .Equals((controllerName.Trim().ToUpper()))
                                         &&
                                         x.Type_Key.ToUpper()
                                          .Equals((AppConstants.RoleAction.Mvc))) == false)
                {
                    filterContext.Result = new RedirectResult("~/Home/NoAccess");
                }
            }
        }
    }

    public class CustomHandleErrorAttribute : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            var controllerName = (string) filterContext.RouteData.Values["controller"];
            var actionName = (string) filterContext.RouteData.Values["action"];
            var model = new HandleErrorInfo(filterContext.Exception, controllerName, actionName);

            filterContext.Result = new ViewResult
                {
                    ViewName = View,
                    MasterName = Master,
                    ViewData = new ViewDataDictionary(model),
                    TempData = filterContext.Controller.TempData
                };
            GlobalConfiguration.Configuration.Services.Replace(typeof (ITraceWriter), new NLogger());
            var trace = GlobalConfiguration.Configuration.Services.GetTraceWriter();
            trace.Error(null, "Controller : " + controllerName + Environment.NewLine
                              + "Action : " + actionName, filterContext.Exception);
            filterContext.ExceptionHandled = true;
            filterContext.HttpContext.Response.Clear();
            filterContext.HttpContext.Response.StatusCode = 500;
        }
    }
}
