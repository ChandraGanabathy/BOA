﻿using System;
using System.Web.Mvc;
using System.Web.Security;
using System.Linq;
using System.Globalization;
using STEP.Common;
using STEP.Repository;
using STEP.Models;
using System.Configuration;

namespace STEP.UI.Controllers
{
    public class UserManagementController : Controller
    {
        private readonly IUserRepository _userRepository;
        private readonly ICodeValueRepository _codeValueRepository;
        private readonly IHierarchyDataRepository _hierarchyDataRepository;
        private readonly IFiscalYearRepository _fiscalYearRepository;
        private readonly IUserRolePillarAssociationRepository _userRolePillarAssociationRepository;
        private readonly IPillarLawRegMappingRepository _pillarLawRegMappingRepository;
        private readonly IRoleActionRepository _roleActionRepository;

        string ApplicationURL = AppConfig.ApplicationURL;
        string WebcassURL = AppConfig.WebcassURL;
        bool EnableCAC = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings.Get("EnableCAC"));

        public UserManagementController(IUserRepository UserRepository,
                                        ICodeValueRepository codeValueRepository,
                                        IHierarchyDataRepository hierarchyDataRepository,
                                        IFiscalYearRepository fiscalYearRepository,
                                        IUserRolePillarAssociationRepository userRolePillarAssociationRepository,
                                        IPillarLawRegMappingRepository pillarLawRegMappingRepository,
                                        IRoleActionRepository roleActionRepository)
        {
            _userRepository = UserRepository;
            _codeValueRepository = codeValueRepository;
            _hierarchyDataRepository = hierarchyDataRepository;
            _fiscalYearRepository = fiscalYearRepository;
            _userRolePillarAssociationRepository = userRolePillarAssociationRepository;
            _pillarLawRegMappingRepository = pillarLawRegMappingRepository;
            _roleActionRepository = roleActionRepository;
        }

        public ActionResult AppUserLogin()
        {
            return View();
        }

        public ActionResult SignOut()
        {
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            AppContext.CurrentUser = null;
            FormsAuthentication.SignOut();

            if (EnableCAC)
                return new RedirectResult(WebcassURL);
            else
                return RedirectToAction("AppUserLogin", "UserManagement");
        }

        public ActionResult SessionTimeOut()
        {
            return View();
        }

        public ActionResult CACWelcomePage()
        {
            Session.Abandon();

            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult CACWelcomePage(bool isCac = false)
        {

            if (Request.Form["hdnAKOEmail"] != null)
                AppContext.CurrentUserEmail = Request.Form["hdnAKOEmail"].ToString();
            else
                AppContext.CurrentUserEmail = System.Configuration.ConfigurationManager.AppSettings.Get("AKOUserEmail");

            bool bEnableCAC = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings.Get("EnableCAC"));

            if (bEnableCAC)
            {
                #region CAC(Code Access Card)
                if (!string.IsNullOrEmpty(AppContext.CurrentUserEmail))
                {
                    string sAKOusername = string.Empty;
                    bool bReadFromCACHeader = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings.Get("ReadFromCACHeader"));

                    if (bEnableCAC)
                    {
                        if (bReadFromCACHeader)
                        {
                            string sAKOIDVariable = System.Configuration.ConfigurationManager.AppSettings.Get("CACIDVariable");
                            sAKOusername = Request.ServerVariables.Get(sAKOIDVariable).ToLower();
                        }
                        else
                        {
                            sAKOusername = AppContext.CurrentUserEmail;
                        }
                    }
                    if (ModelState.IsValid)
                    {
                        var objUsers = _userRepository.ValidateUserEmail(sAKOusername);

                        if (objUsers != null)
                        {
                            User model = new User();
                            model.Email_Id = sAKOusername;

                            var userData = ProceedSignIn(model);
                            if (AppContext.CurrentUser.User_Role.Any())
                            {
                                var firstOrDefault = AppContext.CurrentUser.User_Role.FirstOrDefault();
                                if (firstOrDefault != null)
                                    SetAuthCookie(AppContext.CurrentUser.Email_Id,
                                                  firstOrDefault.Id.ToString(CultureInfo.InvariantCulture),
                                                  false);
                            }
                        }
                    }
                }
                #endregion
            }

            return View();
        }

        private User ProceedSignIn(User user)
        {

            var userData = _userRepository.GetSingle(u => u.Email_Id == user.Email_Id.Trim()
                                                     , u => u.User_Role
                                                     , u => u.User_Role.Select(x => x.User_Role_Hierarchy_Assoication)
                                                     , u => u.User_Role.Select(x => x.User_Role_Pillar_Association)
                                                     , u => u.User_Preference, u => u.User_Role.Select(x => x.Role)
                                                     ,
                                                     u =>
                                                     u.User_Role.Select(
                                                         x =>
                                                         x.User_Role_Hierarchy_Assoication.Select(y => y.Hierarchy_Data)));

            if (userData != null)
            {
                userData.User_Role = userData.User_Role.Where(x => x.User_Role_Status_Key == "ACTV").ToList();
                SubsequencActionAfterLoginSucceed(userData, userData.User_Role.FirstOrDefault());
            }
            return userData;
        }


        private void SubsequencActionAfterLoginSucceed(User userData, User_Role userRole)
        {
            var userTheme = AppConfig.DefaultTheme;
            var userPageSize = AppConfig.DefaultPageSize;
            if (userData != null)
            {
                userData.IsLoginSucessed = true;
                AppContext.CurrentUser = userData;
                //var userRole = userData.User_Role.FirstOrDefault();
                if (userRole != null)
                {
                    AppContext.CurrentUserRole = userRole;
                }
                else
                    AppContext.CurrentUserRole = null;

                SetHierarchyDataForCurrentUserRole();
                SetSystemConstant();
                SetDefaultValues();
                SetActionData();
                SetPillarLawRegAreaForCurrentUserRole();

                var userPreference = userData.User_Preference.FirstOrDefault();
                if (userPreference != null)
                {

                    AppContext.CurrentUserTheme = userPreference.Theme_Key;
                    var codeValue =
                        _codeValueRepository.GetSingle(
                            x =>
                            x.Code_ID == userPreference.Page_Size_Id &&
                            x.Code_Value_Key == userPreference.Page_Size_Key);
                    Int32.TryParse(codeValue.Data1, out userPageSize);
                    AppContext.CurrentUserPageSize = userPageSize;
                }
                else
                {
                    AppContext.CurrentUserTheme = userTheme;
                    var codeValue =
                        _codeValueRepository.GetSingle(
                            x =>
                            x.Code_ID == AppConstants.CodeCategories.PageSize &&
                            x.Code_Value_Key == userPageSize.ToString());

                    AppContext.CurrentUserPageSize = Convert.ToInt32(codeValue.Data1);
                }
            }
        }

        private static void SetAuthCookie(string emailId, string roleId, bool persistant)
        {
            var sUserData = emailId + "|" + roleId;
            FormsAuthentication.SetAuthCookie(sUserData, persistant);
        }

        private void SetSystemConstant()
        {

            var codeIds = new[]
                {
                    AppConstants.CodeCategories.Pillar,
                    AppConstants.CodeCategories.LawReg,
                    AppConstants.CodeCategories.ProgramArea,
                    AppConstants.CodeCategories.SystemConstant,
                };

            var codeValues = _codeValueRepository.FindBy(x => codeIds.Contains(x.Code_ID)).ToList();

            var topNRecords = 0;
            var codeValueRecords =
                codeValues.FirstOrDefault(x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.NumberofRecords));
            if (codeValueRecords != null) Int32.TryParse(codeValueRecords.Data1, out topNRecords);
            AppContext.TopNRecords = topNRecords == 0 ? (int?)null : topNRecords;

            var showTopRecords = false;
            var codeValueAllowTotalRecords =
                codeValues.FirstOrDefault(
                    x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.TotalNumberofRecordsTurnOn));
            if (codeValueAllowTotalRecords != null) bool.TryParse(codeValueAllowTotalRecords.Data1, out showTopRecords);
            AppContext.IsTopRecordsPermitted = showTopRecords;

            var pagesCountToShow = 0;
            var codeValuePagesCountToShow =
                codeValues.FirstOrDefault(x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.PagesCountToShow));
            if (codeValuePagesCountToShow != null)
                Int32.TryParse(codeValuePagesCountToShow.Data1, out pagesCountToShow);
            AppContext.PagesCountToShow = pagesCountToShow == 0 ? 10 : pagesCountToShow;

            // Application Version
            var applicatonVersion =
                codeValues.FirstOrDefault(x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.ApplicationVersion));
            AppContext.ApplicationVersion = string.Empty;
            if (applicatonVersion != null)
            {
                AppContext.ApplicationVersion = applicatonVersion.Data1;
            }

            // Checking If Client Is AMC Or USAR
            var hasAgencyIsAMC = false;
            var codeValueForAgency =
                codeValues.Where(
                    x => x.Code_Value_Key.Equals(AppConstants.CodeCategories.Agency) && x.Data1.Equals(AppConfig.Agency))
                          .ToList();
            if (codeValueForAgency.Any())
            {
                hasAgencyIsAMC = true;
            }
            AppContext.HasAgencyIsAMC = hasAgencyIsAMC;
        }

        private void SetDefaultValues()
        {
            AppContext.CurrentFiscalYear = _fiscalYearRepository.GetFiscalYearBasedOnCurrentDate();
            AppContext.FiscalYears = _fiscalYearRepository.GetAll().ToList();

            //Set Default Value for Project Listing Search Filter
            if (AppContext.ProjectSearchFilter.FiscalYear == 0)
            {
                ProjectSearchFilter searchFilter = AppContext.ProjectSearchFilter;
                searchFilter.FiscalYear = AppContext.CurrentFiscalYear.FY;
                AppContext.ProjectSearchFilter = searchFilter;
            }
            if (AppContext.BudgetExecutionSearchFilter.FiscalYear == 0)
            {
                ProjectSearchFilter budgetExecutionSearchFilterFilter = AppContext.BudgetExecutionSearchFilter;
                budgetExecutionSearchFilterFilter.FiscalYear = AppContext.CurrentFiscalYear.FY;
                AppContext.BudgetExecutionSearchFilter = budgetExecutionSearchFilterFilter;
            }
        }

        private void SetHierarchyDataForCurrentUserRole()
        {
            if (AppContext.CurrentUserRole.Role_Id > 0)
            {
                var hierarchyData =
                    _hierarchyDataRepository.SetCurrentUserRoleHierarchyData(
                        AppContext.CurrentUserRole.Role.Hierarchy_Level_Key, AppContext.CurrentUserRole.Id);

                AppContext.CurrentUserRoleHierarchyData = hierarchyData;
            }
        }

        private void SetActionData()
        {
            AppContext.SessionActions = _roleActionRepository.GetActions(AppContext.CurrentUserRole.Role_Id);
        }

        private void SetPillarLawRegAreaForCurrentUserRole()
        {
            if (AppContext.CurrentUser != null && AppContext.CurrentUserRole.Role_Id > 0)
            {
                var pillarAssociation =
                    _userRolePillarAssociationRepository.GetSingle(
                        x => x.User_Role_Id == AppContext.CurrentUserRole.Id);

                AppContext.CurrentUserRolePillars =
                    _pillarLawRegMappingRepository.GetPillarsByUserRole(pillarAssociation.Pillar_Id,
                                                                        pillarAssociation.Pillar_Key);
                AppContext.CurrentUserRoleLawRegs =
                    _pillarLawRegMappingRepository.GetLawRegByUserRole(pillarAssociation.Pillar_Key, pillarAssociation.LawReg_Id,
                                                                       pillarAssociation.LawReg_Key);
                AppContext.CurrentUserRoleProgramAreas =
                    _pillarLawRegMappingRepository.GetProgramAreaUserRole(pillarAssociation.Pillar_Key, pillarAssociation.LawReg_Key, pillarAssociation.ProgramArea_Id,
                                                                          pillarAssociation.ProgramArea_Key);
            }
        }
    }
}
