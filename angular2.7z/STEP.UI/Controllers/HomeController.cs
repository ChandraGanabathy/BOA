﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace STEP.UI.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        //public ActionResult LegacyPage(String page)
        //{
        //    if (string.Compare(page, "indexAngular", true) == 0)
        //    {
        //        return RedirectToActionPermanent("indexAngular.html");
        //    }

        //    if (string.Compare(page, "coupons", true) == 0)
        //    {
        //        return RedirectToActionPermanent("Coupons");
        //    }

        //    if (string.Compare(page, "history", true) == 0)
        //    {
        //        return RedirectToActionPermanent("History");
        //    }

        //    return RedirectToAction("Error404");
        //}

        //public ActionResult indexAngular(string page)
        //{
        //    ViewBag.Page = page;
        //    return View();
        //}
    }
}
