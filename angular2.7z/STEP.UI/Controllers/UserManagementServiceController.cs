﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using STEP.Common;
using STEP.Models;
using STEP.Repository;

namespace STEP.WebAPI
{
    public class UserManagementServiceController : ApiController
    {
        private readonly IUserRepository _userRepository;
        private readonly ICodeValueRepository _codeValueRepository;
        private readonly IRoleRepository _roleRepository;
        private readonly IRoleMappingRepository _roleMappingRepository;
        private readonly IUserPreferenceRepository _userPreferenceRepository;
        private readonly IPillarLawRegMappingRepository _pillarLawRegMappingRepository;
        private readonly IFiscalYearRepository _fiscalYearRepository;
        private readonly IHierarchyDataRepository _hierarchyDataRepository;

        public UserManagementServiceController(
            IUserRepository userRepository,
            ICodeValueRepository codeValueRepository,
            IRoleRepository roleRepository,
            IRoleMappingRepository roleMappingRepository,
            IUserPreferenceRepository userPreferenceRepository,
            IPillarLawRegMappingRepository pillarLawRegMappingRepository,
            IFiscalYearRepository fiscalYearRepository,
            IHierarchyDataRepository hierarchyDataRepository
            )
        {
            _userRepository = userRepository;
            _codeValueRepository = codeValueRepository;
            _roleRepository = roleRepository;
            _roleMappingRepository = roleMappingRepository;
            _userPreferenceRepository = userPreferenceRepository;
            _pillarLawRegMappingRepository = pillarLawRegMappingRepository;
            _fiscalYearRepository = fiscalYearRepository;
            _hierarchyDataRepository = hierarchyDataRepository;
        }

        [HttpGet]
        public object GetUserDataAtPageLoading(int userId, string inviteStatusFromLogin, string isUserInfo)
        {
            var codeValue = string.Empty;

            if (userId == 0)
            {
                codeValue = AppConstants.CodeCategories.UserStatusInvited;
            }
            else
            {
                if (string.IsNullOrEmpty(inviteStatusFromLogin) == false && inviteStatusFromLogin == "true")
                {
                    codeValue = AppConstants.CodeCategories.UserStatusActive;
                }
            }

            var getUser = _userRepository.GetSingle(x => x.Id == userId, x => x.User_Role,
                                                    x => x.User_Role.Select(y => y.User_Role_Hierarchy_Assoication),
                                                    x => x.User_Role.Select(y => y.User_Role_Pillar_Association));

            // Get all Roles
            var getAllRoles = _roleRepository.GetAll().Select(x => new
            {
                x.Id,
                x.Role_Key,
                x.Name
            }).ToList();

            var getLoggedInUserRoleId = AppContext.CurrentUserRole.Role_Id;

            // Get Immediate Child Role Data
            var getRolesForInvite = GetImmedidateChildRoles();


            // Get Hierarchy Data for Current User Role Id
            /*var getAllHierarchyDatas = AppContext.CurrentUserRoleHierarchyData.Select(y => new
                {
                    y.Id,
                    y.Parent_Id,
                    y.Code,
                    y.Name,
                    y.Hierarchy_Level_Id,
                    y.Hierarchy_Level_Key,
                    y.State_Id,
                    y.State_Key
                });*/
            var getAllHierarchyDatas = _hierarchyDataRepository.GetAll().ToList().Select(y => new
            {
                y.Id,
                y.Parent_Id,
                y.Code,
                y.Name,
                y.Hierarchy_Level_Id,
                y.Hierarchy_Level_Key,
                y.State_Id,
                y.State_Key
            });

            // Get All Code Value Based on Code Ids
            var codeIds = new[]
                {
                        AppConstants.CodeCategories.State, AppConstants.CodeCategories.UserStatus,
                        //AppConstants.CodeCategories.Pillar, AppConstants.CodeCategories.LawReg,
                        //AppConstants.CodeCategories.ProgramArea
                    };

            var codeValues = _codeValueRepository.FindBy(x => codeIds.Contains(x.Code_ID)).ToList();

            // User Status From Code Value
            var getUserStatus = codeValues
                .FirstOrDefault(
                    us =>
                    us.Code_Value_Key.Equals(codeValue,
                                             StringComparison.OrdinalIgnoreCase));


            var getLoginUserRole = STEP.Common.AppContext.CurrentUserRole;

            // Grouping all the data in anonyoumous variable 
            // Usage is to restrict many ajax request and make it as single ajax request
            var userDataAtPageLoading = new[]
                {
                        new
                            {
                                GetUser = getUser,
                                GetUserStatus = getUserStatus,
                                GetAllRoles = getAllRoles,
                                GetLoggedInUserRoleId = getLoggedInUserRoleId,
                                GetAllStates =
                                    _codeValueRepository.GetCodeValues(codeValues, AppConstants.CodeCategories.State),
                                GetRolesForInvite = getRolesForInvite,

                                GetPillars =
                                    _pillarLawRegMappingRepository.GetPillarsByUserRole(
                                        AppConstants.CodeCategories.Pillar, string.Empty),
                                GetLawRegs =
                                    _pillarLawRegMappingRepository.GetLawRegByUserRole(
                                        AppConstants.CodeCategories.LawReg, string.Empty),

                                GetProgramAreas =
                                    _pillarLawRegMappingRepository.GetProgramAreaUserRole(
                                        AppConstants.CodeCategories.ProgramArea, string.Empty),
                                GetAllHierarchyData = getAllHierarchyDatas,
                                GetLoginUserRole = getLoginUserRole
                            }
                    };
            return userDataAtPageLoading;
        }

        [HttpGet]
        public bool DoesUserExists(string emailId)
        {
            var isUserExists =
                //_userRepository.FindBy(x => x.Email_Id == emailId && x.Ako_Email_Id == akoEmailId).Any();
                _userRepository.FindBy(x => x.Email_Id == emailId).Any();
            return isUserExists;
        }

        [HttpPost]
        public User CreateUser(User user)
        {
            var objUser = _userRepository.CreateUpdateUser(user);
            return objUser;
        }

        [HttpGet]
        public string GetSessionTimeOutRedirectUrl()
        {
            var codeValues =
                _codeValueRepository.FindBy(
                    x =>
                    x.Code_ID == AppConstants.CodeCategories.SystemConstant &&
                    x.Code_Value_Key == AppConstants.CodeCategories.SessionTimeoutRedirectCodeValue)
                                    .FirstOrDefault();
            return codeValues != null ? codeValues.Data1 : AppConstants.CodeCategories.SessionTimeoutRedirectUrl;
        }

        [HttpPost]
        public IEnumerable<User> GetAllUsers(UserSearchFilter userSearchFilter)
        {
            AppContext.UserSearchFilter = userSearchFilter;
            var objUsers = _userRepository.GetAllUsers(userSearchFilter, STEP.Common.AppContext.CurrentUserRole.Id);
            return objUsers;
        }

        //[Route("customers/{customerId}/orders")]
        //[HttpGet]
        //public IEnumerable<User> GetUsers(int customerId)
        //{

        //    var objUsers = _userRepository.GetAll().ToList();
        //    return objUsers;
        //}

        [Route("api/UserManagementService/GetUsers")]
        [HttpGet]
        public IEnumerable<User> GetUsers()
        {

            var objUsers = _userRepository.GetAll().ToList();
            return objUsers;
        }

        [HttpGet]
        public object GetUserListingPageLoading()
        {
            // Get Immediate Child Role Data
            var getImmediateChildRoles = GetImmedidateChildRoles();
            var getUserStatus =
                _codeValueRepository.FindBy(x => x.Code_ID.Equals(AppConstants.CodeCategories.UserStatus)).ToList();
            var userListingDataAtPageLoading = new[]
                {
                        new
                            {
                                GetRoles = getImmediateChildRoles,
                                GetUserStatus = getUserStatus
                            }
                    };
            return userListingDataAtPageLoading;
        }

        private object GetImmedidateChildRoles()
        {
            return _roleMappingRepository.
                AllIncluding(x => x.Child_Role, x => x.Parent_Role).Where(x =>
                                                                          x.Parent_Role_Id ==
                                                                          AppContext.CurrentUserRole
                                                                                    .Role_Id &&
                                                                          x.Child_Role_Id >=
                                                                          AppContext.CurrentUserRole
                                                                                    .Role_Id)
                                         .Select(item => new
                                         {
                                             item.Id,
                                             item.Child_Role_Id,
                                             item.Parent_Role_Id,
                                             item.Child_Role.Role_Key,
                                             item.Child_Role.Name,
                                             RoleID = item.Child_Role.Id,
                                         }).OrderBy(x => x.Child_Role_Id).ToList();
        }

        /// <summary>
        /// Get All Data for User Preference Page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public object GetUserPreferenceDataAtPageLoading()
        {
            // Get All Code Value Based on Code Ids
            var codeIds = new[] { AppConstants.CodeCategories.Theme, AppConstants.CodeCategories.PageSize };
            var codeValues = _codeValueRepository.FindBy(x => codeIds.Contains(x.Code_ID)).ToList();

            // Theme Data Data
            var getAllThemes =
                codeValues.Where(x => x.Code_ID == AppConstants.CodeCategories.Theme).Select(y => new
                {
                    y.Code_ID,
                    y.Code_Value_Key,
                    y.Code_Value_Description,
                    y.Data1
                });

            // Page Size Data
            var getPageSize =
                codeValues.Where(x => x.Code_ID == AppConstants.CodeCategories.PageSize).Select(y => new
                {
                    y.Code_ID,
                    y.Code_Value_Key,
                    y.Code_Value_Description,
                    y.Data1
                });

            // Get User Preference data
            var getUserPreference = AppContext.CurrentUser.User_Preference.FirstOrDefault();

            var userPreferenceAtPageLoading = new[]
                {
                        new
                            {
                                GetAllThemes = getAllThemes,
                                GetPageSize = getPageSize,
                                GetUserPreference = getUserPreference,
                            }
                    };
            return userPreferenceAtPageLoading;
        }

        [HttpPost]
        public User_Preference SaveUpdateUserPreference(User_Preference userPreference)
        {
            // Add User_Preference
            if (userPreference.Id == 0)
            {
                userPreference.Created_By = GetLoggedUserInfo();
                userPreference.Created_Date = CreatedUpdatedDateTime();
                userPreference.Modified_By = GetLoggedUserInfo();
                userPreference.Modified_Date = CreatedUpdatedDateTime();

                _userPreferenceRepository.Add(userPreference);
                _userPreferenceRepository.Commit();
            }
            // Update User Preference
            else
            {
                var updateUserPreference = _userPreferenceRepository.GetSingle(r => r.Id == userPreference.Id);

                updateUserPreference.User_Id = userPreference.User_Id;
                updateUserPreference.Theme_Id = userPreference.Theme_Id;
                updateUserPreference.Theme_Key = userPreference.Theme_Key;
                updateUserPreference.Page_Size_Id = userPreference.Page_Size_Id;
                updateUserPreference.Page_Size_Key = userPreference.Page_Size_Key;
                updateUserPreference.Modified_By = GetLoggedUserInfo();
                updateUserPreference.Modified_Date = CreatedUpdatedDateTime();

                _userPreferenceRepository.Edit(updateUserPreference);
                _userPreferenceRepository.Commit();
            }

            STEP.Common.AppContext.CurrentUserTheme =
                _codeValueRepository.GetCodeValue(userPreference.Theme_Id, userPreference.Theme_Key).Code_Value_Key;

            int pageSize;
            var getPageSize = _codeValueRepository.GetCodeValue(userPreference.Page_Size_Id,
                                                                userPreference.Page_Size_Key);
            Int32.TryParse(getPageSize.Code_Value_Description, out pageSize);
            STEP.Common.AppContext.CurrentUserPageSize = pageSize;

            var user = AppContext.CurrentUser;

            var lstUserPreference = new List<User_Preference> { userPreference };
            user.User_Preference = lstUserPreference;
            AppContext.CurrentUser = user;

            return userPreference;
        }

        [HttpPost]
        public User UpdateUserStatus(User user)
        {
            var updateUser = _userRepository.GetSingle(x => x.Id == user.Id);
            updateUser.User_Status_Id = user.User_Status_Id;
            updateUser.User_Status_Key = user.User_Status_Key;
            updateUser.Modified_By = GetLoggedUserInfo();
            updateUser.Modified_Date = CreatedUpdatedDateTime();
            _userRepository.Edit(updateUser);
            _userRepository.Commit();
            return updateUser;
        }

        [HttpGet]
        public int DeleteUser(int userId)
        {
            var deleteUser = _userRepository.GetSingle(r => r.Id == userId);
            _userRepository.Delete(deleteUser);
            _userRepository.Commit();
            return 1;
        }

        [HttpGet]
        public object GetFiscalDataAtPageLoading(int FiscalId)
        {
            return _fiscalYearRepository.GetFiscalDataAtPageLoading(FiscalId);
        }

        [HttpGet]
        public List<object> GetAllFiscal()
        {
            var objUsers = _fiscalYearRepository.GetAllFiscal();
            return objUsers;
        }

        [HttpPost]
        public Fiscal_Year CreateFiscalValue(Fiscal_Year fiscalValue)
        {
            var objFiscal = _fiscalYearRepository.CreateFiscalValue(fiscalValue);
            return objFiscal;
        }
        public string GetLoggedUserInfo()
        {
            if (AppContext.CurrentUser != null)
                return AppContext.CurrentUser.First_Name + ' ' + AppContext.CurrentUser.Last_Name;
            return string.Empty;
        }

        public DateTime CreatedUpdatedDateTime()
        {
            return DateTime.Now;
        }
    }
}