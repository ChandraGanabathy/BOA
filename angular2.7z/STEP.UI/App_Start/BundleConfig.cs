﻿using STEP.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Optimization;

namespace STEP.UI
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        /*
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                "~/Scripts/jquery.unobtrusive*",
                "~/Scripts/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/bundles/knockout").Include(
                "~/Scripts/knockout-{version}.js",
                "~/Scripts/knockout.validation.js"));

            bundles.Add(new ScriptBundle("~/bundles/app").Include(
                "~/Scripts/sammy-{version}.js",
                "~/Scripts/app/common.js",
                "~/Scripts/app/app.datamodel.js",
                "~/Scripts/app/app.viewmodel.js",
                "~/Scripts/app/home.viewmodel.js",
                "~/Scripts/app/_run.js"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                "~/Scripts/bootstrap.js",
                "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                 "~/Bootstrap/css/Bootstrap.css"));

            bundles.Add(new StyleBundle("~/BootStrap/css/Site").Include(
              "~/Bootstrap/css/site.css"));
        }*/
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/FrameWork").Include(
                "~/Scripts/Framework/autonumeric.js",
                "~/Scripts/Framework/jquery-{version}.js",
                "~/Scripts/Framework/jquery-ui-{version}.js",
                "~/Scripts/Framework/jquery.unobtrusive*",
                "~/Scripts/Framework/jquery.validate*",
                "~/Scripts/Framework/jquery.*",
                "~/Scripts/Framework/modernizr-*",
                "~/Scripts/Framework/knockout-*",
                "~/Scripts/Framework/knockout.*",
                 "~/Scripts/Framework/ko-protected-*",
                "~/Scripts/Framework/knockout.validation.*",
                "~/Scripts/Framework/ddaccordion.js",
                "~/Scripts/Framework/html5shiv.js",
                "~/Scripts/Framework/flotr2.js",
                "~/Scripts/Framework/jquery.battatech.excelexport.js",
                "~/Scripts/Framework/moment.js",
                "~/Scripts/Framework/bootstrap-datetimepicker.js",
                "~/Scripts/Framework/jquery.maskedinput.js",
                "~/Scripts/Framework/jquery.bootstrap.wizard.js",
                "~/Scripts/Framework/prettify.js",
                "~/Scripts/Framework/bootstrap-filestyle.js",
                "~/Scripts/Framework/highcharts.js",
                "~/Scripts/Framework/highcharts-3d.js",
                "~/Scripts/Framework/drilldown.js",
                "~/Scripts/Framework/exporting.js"
                            ));
            bundles.Add(new ScriptBundle("~/bundles/Bootstrap").Include(
                "~/Bootstrap/js/bootstrap.js"));

            bundles.Add(new ScriptBundle("~/bundles/UserManagement").IncludeDirectory(
                "~/Scripts/Application/UserManagement",
                "*.js"));

            bundles.Add(new ScriptBundle("~/bundles/Application").IncludeDirectory(
               "~/Scripts/Application",
               "*.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                "~/Content/bootstrap-datetimepicker.css",
                "~/Content/prettify.css"
                ));

            foreach (var theme in Bootstrap.Themes)
            {
                switch (theme)
                {
                    case Bootstrap.Theme.Green:
                        bundles.Add(new StyleBundle(Bootstrap.BundleBase + Bootstrap.Theme.Green).Include(
                            "~/Bootstrap/css/Bootstrap.css"
                                        ));
                        break;
                    case Bootstrap.Theme.Blue:
                        bundles.Add(new StyleBundle(Bootstrap.BundleBase + Bootstrap.Theme.Blue).Include(
                            "~/Bootstrap/css/CoolBlue.css"
                                        ));
                        break;
                    case Bootstrap.Theme.Orange:
                        bundles.Add(new StyleBundle(Bootstrap.BundleBase + Bootstrap.Theme.Orange).Include(
                            "~/Bootstrap/css/Orange.css"
                                        ));
                        break;

                }
            }
            bundles.Add(new StyleBundle("~/BootStrap/css/Site").Include(
               "~/Bootstrap/css/site.css"));

            bundles.Add(new StyleBundle("~/BootStrap/css/Login").Include(
              "~/Bootstrap/css/Bootstrap.css"
               ));
        }
    }
}
