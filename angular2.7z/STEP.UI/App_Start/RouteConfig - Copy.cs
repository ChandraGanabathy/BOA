﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace STEP.UI
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            /*routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.MapMvcAttributeRoutes();

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Account", action = "Login", id = UrlParameter.Optional }
            );*/
            bool EnableCAC = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings.Get("EnableCAC"));
            string straction = string.Empty;
            straction = EnableCAC ? "CACWelcomePage" : "AppUserLogin";
            routes.MapMvcAttributeRoutes();
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            //routes.MapRoute(
            //    name: "STEP",
            //     url: "{controller}/{action}/{id}",
            //    defaults: new { controller = "UserManagement", action = straction, id = UrlParameter.Optional }
            //);
            //routes.IgnoreRoute("{resource}.axd/{*everything}");

            //routes.RouteExistingFiles = true;

            //routes.MapRoute(
            //    name: "staticFileRoute",
            //    url: "Public/{*file}",
            //    defaults: new { controller = "Home", action = "HandleStatic" }
            //);

            routes.MapRoute(
    name: "LegacyHtml",
    url: "{page}.html",
    defaults: new { controller = "Home", action = "LegacyPage", page = UrlParameter.Optional }
);

            routes.MapRoute(
                name: "LegacyAspx",
                url: "{page}.aspx",
                defaults: new { controller = "Home", action = "LegacyPage", page = UrlParameter.Optional }
            );

            routes.MapRoute(
                name: "STEP",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "UserManagement", action = straction, id = UrlParameter.Optional }
            );

        }
    }
}
