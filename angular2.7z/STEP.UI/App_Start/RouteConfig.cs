﻿using System;
using System.Web.Mvc;
using System.Web.Routing;

namespace STEP.UI
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            bool EnableCAC = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings.Get("EnableCAC"));
            string straction = string.Empty;
            straction = EnableCAC ? "CACWelcomePage" : "AppUserLogin";
            routes.MapMvcAttributeRoutes();
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            /*  =============  Angular Routing Url Pattern With MVC Pattern to solve issue for refreshing issues - Approach 2. Approach 1 implemented in global.asax file=================*/
            routes.MapRoute(
                      name: "Home",
                      url: "home",
                      defaults: new { controller = "Home", action = "Index" }
                      );

            routes.MapRoute(
                       name: "User-Edit",
                       url: "users/{id}/{edit}/{save}",
                       defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional, edit = UrlParameter.Optional, save = UrlParameter.Optional }
                      );

            /*routes.MapRoute(
                       name: "UserSave",
                       url: "users/{id}/save",
                       defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
              );*/
            /*  =============  Angular Routing With MVC - Approach 2. Approach 1 implemented in global.asax file=================*/

            /* ============== Default MVC Routing. No Angular Routing Involved */
            routes.MapRoute(
                    name: "Default",
                    url: "{controller}/{action}/{id}",
                    defaults: new { controller = "UserManagement", action = straction, id = UrlParameter.Optional }
            );
        }
    }
}
