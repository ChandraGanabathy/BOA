﻿/// <reference path="../_references.js" />STEP.dataService.searchHWPS

STEP.dataService = function () {

    /*============ Private Common API calls START here ==============*/
    handleException = function (errorCode, failureCallback) {
        STEP.DisapperaFooter();
        switch (errorCode) {
            case 400: /*Bad Request*/
                if (failureCallback != null) failureCallback();
                break;
            case 401: /*UnAuthorized*/
                location.href = STEP.NavigateTo.LoginPage;
                break;
            case 403: /*Access Forbidden */
                STEP.ShowStatusMessageBoxAtFooter("Access is not granted for this feature.", "Error");
                break;
            default:
                STEP.ShowStatusMessageBoxAtFooter("Requested service is unavailable. Please try again later. Contact system support if the problem persists.", "Error");
                STEP.ShowStatusMessageBoxAtFooterLogin("Requested service is unavailable. Please try again later. Contact system support if the problem persists.", "Error");

        }
    },
    ajaxGet = function (serviceUrl, successCallback, callerName, noSpinner) {
        STEP.DisapperaFooter();
        noSpinner = typeof noSpinner !== 'undefined' ? noSpinner : false;
        $.ajax({
            beforeSend: function () {
            },
            complete: function () {
            },
            url: STEP.serviceBase + serviceUrl,
            accepts: "application/json",
            cache: false,
            statusCode: {
                200: function (data) {
                    successCallback(data);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                handleException(jqXHR.status);
            }
        });
    },
    ajaxGetHomeService = function (model, serviceUrl, successCallback, callerName) {
        STEP.DisapperaFooter();
        $.ajax({
            url: STEP.serviceBase + serviceUrl,
            data: { 'startDate': model.StartDate(), 'endDate': model.EndDate(), 'generatorStatus': model.GeneratorStatus().toString(), 'installation': model.Installation().toString(), 'top': model.Top() },
            accepts: "application/json; charset=utf-8",
            cache: false,
            statusCode: {
                200: function (data) {
                    successCallback(data);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                handleException(jqXHR.status);
            }
        });
    },
    ajaxPost = function (model, serviceUrl, successCallback, failureCallback, callerName, noSpinner) {
        STEP.DisapperaFooter();
        noSpinner = typeof noSpinner !== 'undefined' ? noSpinner : false;
        var jsonObj = ko.toJSON(model);
        $.ajax({
            beforeSend: function () {
            },
            complete: function () {
            },
            url: STEP.serviceBase + serviceUrl,
            cache: false,
            type: 'POST',
            data: jsonObj,
            contentType: 'application/json; charset=utf-8',
            statusCode: {
                200 /*Get*/: function (responseData) {
                    successCallback(responseData);
                },
                201 /*Created*/: function (responseData) {
                    successCallback(responseData);
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $.log(jqXHR);
                $.log("Ajax Post Exception for : " + callerName + " on " + STEP.GetCurrentDateTime() + " - " + textStatus + "-" + errorThrown);
                handleException(jqXHR.status, failureCallback);
            }
        });
    },


    AjaxPostWithoutQuerystring = function (url, jsondata) {
        $.ajax({
            url: STEP.UrlBase + url,
            type: 'POST',
            data: JSON.stringify(jsondata),
            contentType: 'application/json; charset=utf-8',
            success: function (data) {
                var redirectURL = "/" + data.ControllerName + "/" + data.ActionName;
                window.location.href = STEP.UrlBase + redirectURL;
            },
        });
    },

    /*============ Private Common API calls END here ==============*/

    /*============ AppUserService API calls START here ==============*/
    getUserStatus = function (codeValue, successCallback, noSpinner) {
        ajaxGet('AppUserService/GetUserStatus/?codeValue=' + codeValue, successCallback, "getUserStatus", noSpinner);
    },

    getUserPreferenceDataAtPageLoading = function (successCallback, noSpinner) {
        ajaxGet('UserManagementService/GetUserPreferenceDataAtPageLoading/', successCallback, "getUserPreferenceDataAtPageLoading", noSpinner);
    },
    saveUpdateUserPreference = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'UserManagementService/SaveUpdateUserPreference/', successCallback, failureCallback, "saveUpdateUserPreference", noSpinner);
    },
    getAllRoles = function (successCallback) {
        ajaxGet('AppUserService/GetAllRoles/', successCallback, "getAllRoles");
    },
    getRolesForInvite = function (successCallback) {
        ajaxGet('AppUserService/GetRolesForInvite/', successCallback, "getRolesForInvite");
    },
    getAllAppUsers = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'UserManagementService/GetAllUsers/', successCallback, failureCallback, "getAllAppUsers", noSpinner);
    },
    getUserListingPageLoading = function (successCallback) {
        ajaxGet('UserManagementService/GetUserListingPageLoading/', successCallback, "getUserListingPageLoading");
    },
    deleteUser = function (userId, successCalback) {
        ajaxGet('UserManagementService/DeleteUser/?userId=' + userId, successCalback, "deleteUser");
    },
    inviteUser = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'UserManagementService/CreateUser/', successCallback, failureCallback, "inviteUser");
    },
    updateUserStatus = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'UserManagementService/UpdateUserStatus/', successCallback, failureCallback, "updateUserStatus");
    },
    doesUserExists = function (emailId, successCallback, failureCallback) {
        ajaxGet('UserManagementService/DoesUserExists/?emailId=' + emailId, successCallback, failureCallback, "doesUserExists");
    },
    getAllUserStatus = function (successCalback) {
        ajaxGet('AppUserService/GetAllUserStatus/', successCalback, "getAllUserStatus");
    },
    getUser = function (userId, successCallback) {
        ajaxGet('AppUserService/GetUser/?userId=' + userId, successCallback, "getUser");
    },

    getUserDataAtPageLoading = function (userId, inviteStatusFromLogin, isUserInfo, successCallback, noSpinner) {
        ajaxGet('UserManagementService/GetUserDataAtPageLoading/?userId=' + userId + '&inviteStatusFromLogin=' + inviteStatusFromLogin + '&isUserInfo=' + isUserInfo, successCallback, "getUserDataAtPageLoading", noSpinner);
    },
    getActions = function (roleId, successCallback) {
        ajaxGet('AppUserService/GetActions/?roleId=' + roleId, successCallback, "getActions");
    },
    getLoggedInUserRoleId = function (successCallback, noSpinner) {
        ajaxGet('AppUserService/GetLoggedInUserRoleId', successCallback, "getLoggedInUserRoleId", noSpinner);
    };
    getSessionTimeOutRedirectUrl = function (successCallback, noSpinner) {
        ajaxGet('UserManagementService/GetSessionTimeOutRedirectUrl', successCallback, "getSessionTimeOutRedirectUrl", noSpinner);
    };

    executeAdminQuery = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'UserQueryService/ExecuteAdminQuery', successCallback, failureCallback, "executeAdminQuery");
    },
   getAdminSecuritytext = function (successCallback, failureCallback) {
       ajaxGet('UserQueryService/GetAdminSecuritytext', successCallback, failureCallback, "getAdminSecuritytext");
   },
    /*============ AppUserService API calls END here ==============*/

    /*============ AuthorizationService API calls START here ==============*/
    signIn = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'AccountService/SignIn', successCallback, failureCallback, "signIn");
    },
    CACsignIn = function (model, successCallback, failureCallback) {
        ajaxGet('AccountService/GetCurrentUser', successCallback, failureCallback, "CACsignIn");
    },
    setCurrentUserRoleIfMore = function (roleId, successCallback) {
        ajaxGet('AccountService/SetCurrentUserRoleIfMore/?roleId=' + roleId, successCallback, "setCurrentUserRoleIfMore");
    },
    getUserData = function (successCallback) {
        ajaxGet('AuthorizationService/GetUserData/', successCallback, "getUserData");
    },
    getPermission = function (successCallback) {
        ajaxGet('AuthorizationService/GetPermission/', successCallback, "getPermission");
    },

    invokingImpersonation = function (userId, userRoleId, successCallback) {
        ajaxGet('AccountService/InvokingImpersonation/?userId=' + userId + '&userRoleId=' + userRoleId, successCallback, "invokingImpersonation");
    },
    rollBackImpersonation = function (successCallback) {
        ajaxGet('AccountService/RollBackImpersonation/', successCallback, "rollBackImpersonation");
    },
     changeRole = function (successCallback) {
         ajaxGet('AccountService/ChangeRole/', successCallback, "changeRole");
     },
    /*============ AuthorizationService API calls END here ==============*/

    /*============ CatalogService API calls START here ==============*/
    getDataForCatalogListingPageLoading = function (sharedPageKey,successCallback, noSpinner) {
        ajaxGet('CatalogService/GetDataForCatalogListingPageLoading/?sharedPageKey=' + sharedPageKey, successCallback, "getDataForCatalogListingPageLoading", noSpinner);
    },
      searchCatalogs = function (sharedPageKey, model, successCallback, failureCallback, noSpinner) {
          ajaxPost(model, 'CatalogService/SearchCatalogs/?sharedPageKey=' + sharedPageKey, successCallback, failureCallback, "searchCatalogs", noSpinner);
      },
    manageCatalog = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'CatalogService/ManageCatalog/', successCallback, failureCallback, "manageCatalog", noSpinner);
    },
    getCatalogById = function (catalogId, successCallback, noSpinner) {
        ajaxGet('CatalogService/GetCatalogById/?catalogId=' + catalogId, successCallback, "getCatalogById", noSpinner);
    },
    getCatalogMasterData = function (successCallback, noSpinner) {
        ajaxGet('CatalogService/GetCatalogMasterData/', successCallback, "getCatalogMasterData", noSpinner);
    },
    createUpdateCatalog = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'CatalogService/CreateUpdateCatalog/', successCallback, failureCallback, "createUpdateCatalog", noSpinner);
    },
    /*============ CatalogService API calls END here ==============*/

    /*============ PlanningService API calls START here ==============*/
    getPAFGMasterData = function (successCallback, noSpinner) {
        ajaxGet('PlanningService/GetPAFGMasterData/', successCallback, "getPAFGMasterData", noSpinner);
    },
    searchPAFGs = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'PlanningService/SearchPAFGs/', successCallback, failureCallback, "searchPAFGs", noSpinner);
    },
    allocatePAFG = function (controlAmount, propertyId, fiscalYear, selectedProperty, successCallback, noSpinner) {
        ajaxGet('PlanningService/AllocatePAFG/?controlAmount=' + controlAmount + '&propertyId=' + propertyId + '&fiscalYear=' + fiscalYear + '&selectedProperty=' + selectedProperty, successCallback, "allocatePAFG", noSpinner);
    },
    savePAFGControlAmount = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'PlanningService/SavePAFGControlAmount/', successCallback, failureCallback, "savePAFGControlAmount", noSpinner);
    },
    getPriorityMasterData = function (successCallback, noSpinner) {
        ajaxGet('PlanningService/GetPriorityMasterData/', successCallback, "getPriorityMasterData", noSpinner);
    },
    getProjectPriorities = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'PlanningService/GetProjectPriorities/', successCallback, failureCallback, "getProjectPriorities", noSpinner);
    },
     finalizeProjectPriorities = function (model, successCallback, failureCallback, noSpinner) {
         ajaxPost(model, 'PlanningService/FinalizeProjectPriorities/', successCallback, failureCallback, "finalizeProjectPriorities", noSpinner);
     },
     saveProjectPriorities = function (model, successCallback, failureCallback, noSpinner) {
         ajaxPost(model, 'PlanningService/SaveProjectPriorities/', successCallback, failureCallback, "saveProjectPriorities", noSpinner);
     },



    /*============ PlanningService API calls END here ==============*/



    /*============ ProjectService API calls Start here ==============*/
     getDataForProjectListingPageLoading = function (sharedPageKey, successCallback, noSpinner) {
         ajaxGet('ProjectManagementService/GetDataForProjectListingPageLoading/?sharedPageKey=' + sharedPageKey, successCallback, "getDataForCatalogListingPageLoading", noSpinner);
     },
     searchProjects = function (model, sharedPageKey, successCallback, failureCallback, noSpinner) {
         ajaxPost(model, 'ProjectManagementService/SearchProjects/?sharedPageKey=' + sharedPageKey, successCallback, failureCallback, "searchProjects", noSpinner);
     },

    getProjectDataForPageLoading = function (projectId, catalogId, successCallback, noSpinner) {
        ajaxGet('ProjectManagementService/GetProjectDataForPageLoading/?projectId=' + projectId + '&catalogId=' + catalogId, successCallback, "getProjectDataForPageLoading", noSpinner);
    },

    insertUpdateProject = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'ProjectManagementService/InsertUpdateProject/', successCallback, failureCallback, "insertUpdateProject");
    },

projectApprovalProcess = function (model, successCallback, failureCallback) {
    ajaxPost(model, 'ProjectManagementService/ProjectApprovalProcess/', successCallback, failureCallback, "projectApprovalProcess");
},
     viewProjectHistoryByProjectId = function (projectId, successCallback, noSpinner) {
         ajaxGet('ProjectManagementService/ViewProjectHistoryByProjectId/?projectId=' + projectId, successCallback, "viewProjectHistoryByProjectId", noSpinner);
     },
getHelptext = function (codeId, successCallback, noSpinner) {
    ajaxGet('ProjectManagementService/GetHelptext/?codeId=' + codeId, successCallback, "getHelptext", noSpinner);
},
    /*============ ProjectService API calls END here ==============*/
    /*===================== Budget Execution API Calls - START =====================*/
    budgetExecutionUpdate = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'ProjectManagementService/BudgetExecutionUpdate/', successCallback, failureCallback, "budgetExecutionUpdate");
    },
    /*===================== Budget Execution API Calls - END =====================*/

    /*============ EmailNotificationService API calls START here ==============*/
    getAllRolesForClient = function (successCallback, noSpinner) {
        ajaxGet('EmailNotificationService/GetAllRolesForClient/', successCallback, "getAllRolesForClient", noSpinner);
    },
    getEmailNotificationSignature = function (successCallback, noSpinner) {
        ajaxGet('EmailNotificationService/GetEmailNotificationSignature', successCallback, "getEmailNotificationSignature", noSpinner);
    },
     uploadDocument = function (model, successCallback, failureCallback) {
         ajaxPost(model, 'EmailNotificationService/UploadDocument', successCallback, failureCallback, "uploadDocument");
     },
     sendEmailNotification = function (model, successCallback, failureCallback) {
         ajaxPost(model, 'EmailNotificationService/SendEmailNotification', successCallback, failureCallback, "sendEmailNotification");
     },
    /*============ EmailNotificationService API calls END here ==============*/

    /*============ FileManagerService API calls START here ==============*/
    RetrieveFileManagerList = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'FileManagerService/GetFolderFiles/', successCallback, failureCallback, "RetrieveFileManagerList", noSpinner);
    },
    SearchFileManagerList = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'FileManagerService/GetSearchFiles/', successCallback, failureCallback, "SearchFileManagerList", noSpinner);
    },
     uploadFileManagerDocument = function (model, successCallback, failureCallback) {
         ajaxPost(model, 'FileManagerService/uploadFileManagerDocument', successCallback, failureCallback, "uploadFileManagerDocument");
     },
    getHelpDocuments = function (successCallback, failureCallback, noSpinner) {
        ajaxGet('FileManagerService/GetHelpDocuments/', successCallback, "getHelpDocuments", noSpinner);
    },
    /*============ FileManagerService API calls END here ==============*/

    /*============ FiscalService API calls START here ==============*/

    getAllFiscalData = function (successCallback, failureCallback, noSpinner) {
        ajaxGet('UserManagementService/GetAllFiscal/', successCallback, "getAllFiscalData", noSpinner);
    },

    getFiscalDataAtPageLoading = function (FiscalId, successCallback, noSpinner) {
        ajaxGet('UserManagementService/GetFiscalDataAtPageLoading/?FiscalId=' + FiscalId, successCallback, "getFiscalDataAtPageLoading", noSpinner);
    },

    invitefiscalValue = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'UserManagementService/CreateFiscalValue/', successCallback, failureCallback, "invitefiscalValue");
    },
    /*============ FiscalService API calls End here ==============*/

    /*============ Dashboard START here ==============*/
    getDataForDashboardMyInboxPageLoading = function (successCallback, noSpinner) {
        ajaxGet('ProjectManagementService/GetDataForDashboardMyInboxPageLoading/', successCallback, "GetDataForProjectListingPageLoading", noSpinner);
    },
    myInboxProjects = function (model, successCallback, failureCallback, noSpinner) {
        ajaxPost(model, 'ProjectManagementService/MyInboxProjects/', successCallback, failureCallback, "MyInboxProjects", noSpinner);
    },
    getDataForDashboard = function (successCallback, noSpinner) {
        ajaxGet('ProjectManagementService/GetDataForDashboard/', successCallback, "GetDataForDashboard", noSpinner);
    },
    getDataForDashboardChartDetails = function (successCallback, noSpinner) {
        ajaxGet('ProjectManagementService/GetDataForDashboardChartDetails/', successCallback, "GetDataForDashboardChartDetails", noSpinner);
    },
    getPFChartDetailsData = function (model, successCallback) {
        ajaxPost(model, 'ProjectManagementService/PFChartDetailsData/', successCallback, "PFChartDetailsData");
    },
    getPercentFundedChartDetailsData = function (model, successCallback) {
        ajaxPost(model, 'ProjectManagementService/PercentFundedChartDetailsData/', successCallback, "PercentFundedChartDetailsData");
    },
    /*============ Dashboard END here ==============*/

    /* =========== Report Section Starts Here========================== */

    getReportListItems = function (roleId, successCallback, failureCallback, noSpinner) {
        ajaxGet('ReportsService/GetReportListItems/?roleId=' + roleId, successCallback, "getReportListItems", noSpinner);
    }
    getReportParametersList = function (roleId, successCallback, failureCallback, noSpinner) {
        ajaxGet('ReportsService/GetReportParametersList/?roleId=' + roleId, successCallback, "getReportParametersList", noSpinner);
    }
    selectedParametersForReport = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'ReportsService/SelectedParametersForReport', successCallback, failureCallback, "selectedParametersForReport");
    }

    /* =========== Report Section END Here========================== */

    /* =========== Changing project owner Section Starts Here========================== */
    getDataForProjectOwnerPageLoading = function (successCallback, noSpinner) {
        ajaxGet('ProjectManagementService/GetDataForProjectOwnerPageLoading/', successCallback, "getDataForProjectOwnerPageLoading", noSpinner);
    },

	  searchProjectOwner = function (model, successCallback, failureCallback, noSpinner) {
	      ajaxPost(model, 'ProjectManagementService/SearchProjectOwner/', successCallback, failureCallback, "searchProjectOwner", noSpinner);
	  },

    inviteOwnerList = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'ProjectManagementService/UpdateOwnerList/', successCallback, failureCallback, "inviteOwnerList");
    }
    /* =========== Changing project owner Section END Here========================== */

    /* =========== Roles and Actions Section Starts Here========================== */

    getDataForRolesActionPageLoading = function (successCallback, noSpinner) {
        ajaxGet('ProjectManagementService/GetDataForRolesActionPageLoading/', successCallback, "getDataForRolesActionPageLoading", noSpinner);
    },

    inviteRoleActionList = function (model, successCallback, failureCallback) {
        ajaxPost(model, 'ProjectManagementService/UpdateRoleActionList/', successCallback, failureCallback, "inviteRoleActionList");
    },

    getRoleActionData = function (RoleId, successCallback, noSpinner) {
        ajaxGet('ProjectManagementService/GetRoleActionData/?RoleId=' + RoleId, successCallback, "getRoleActionData", noSpinner);
    }

    /* =========== Roles and Actions Section END Here========================== */


    return {
        AjaxPostWithoutQuerystring: AjaxPostWithoutQuerystring,
        /*============ AppUserService API calls register START here ==============*/
        getUserStatus: getUserStatus,
        getUserPreferenceDataAtPageLoading: getUserPreferenceDataAtPageLoading,
        saveUpdateUserPreference: saveUpdateUserPreference,
        getAllRoles: getAllRoles,
        getRolesForInvite: getRolesForInvite,
        getAllAppUsers: getAllAppUsers,
        deleteUser: deleteUser,
        inviteUser: inviteUser,
        updateUserStatus: updateUserStatus,
        doesUserExists: doesUserExists,
        getAllUserStatus: getAllUserStatus,
        getUser: getUser,
        getUserDataAtPageLoading: getUserDataAtPageLoading,
        getActions: getActions,
        getLoggedInUserRoleId: getLoggedInUserRoleId,
        getSessionTimeOutRedirectUrl: getSessionTimeOutRedirectUrl,
        getUserListingPageLoading: getUserListingPageLoading,
        /*============ AppUserService API calls register END here ==============*/
        /*============ AuthorizationService API calls register START here ==============*/
        CACsignIn: CACsignIn,
        signIn: signIn,
        setCurrentUserRoleIfMore: setCurrentUserRoleIfMore,
        getUserData: getUserData,
        getPermission: getPermission,
        invokingImpersonation: invokingImpersonation,
        rollBackImpersonation: rollBackImpersonation,
        changeRole: changeRole,
        /*============ AuthorizationService API calls register END here ==============*/
        /*============ UserQueryService API calls register START here ==============*/
        executeAdminQuery: executeAdminQuery,
        getAdminSecuritytext: getAdminSecuritytext,
        /*============ UserQueryService API calls register END here ==============*/
        /*============ CatalogService API calls register START here ==============*/
        getDataForCatalogListingPageLoading: getDataForCatalogListingPageLoading,
        manageCatalog: manageCatalog,
        searchCatalogs: searchCatalogs,
        getCatalogById: getCatalogById,
        getCatalogMasterData: getCatalogMasterData,
        createUpdateCatalog: createUpdateCatalog,
        /*============ CatalogService API calls register END here ==============*/

        /*============ ProjectService API calls register START here ==============*/
        getDataForProjectListingPageLoading: getDataForProjectListingPageLoading,
        searchProjects: searchProjects,
        getProjectDataForPageLoading: getProjectDataForPageLoading,
        insertUpdateProject: insertUpdateProject,
        projectApprovalProcess: projectApprovalProcess,
        viewProjectHistoryByProjectId: viewProjectHistoryByProjectId,
        getHelptext: getHelptext,
        /*============ ProjectService API calls register END here ==============*/

        /*===================== Budget Execution API Calls - START =====================*/
        budgetExecutionUpdate: budgetExecutionUpdate,
        /*===================== Budget Execution API Calls - END =====================*/

        /*============ EmailNotificationService API calls register START here ==============*/
        getAllRolesForClient: getAllRolesForClient,
        getEmailNotificationSignature: getEmailNotificationSignature,
        uploadDocument: uploadDocument,
        sendEmailNotification: sendEmailNotification,
        /*============ EmailNotificationService API calls register START here ==============*/

        /*============ FileManagerService API calls register START here ==============*/
        RetrieveFileManagerList: RetrieveFileManagerList,
        SearchFileManagerList: SearchFileManagerList,
        uploadFileManagerDocument: uploadFileManagerDocument,
        getHelpDocuments:getHelpDocuments,
        /*============ FileManagerService API calls register START here ==============*/

        /*============ FiscalService API calls register START here ==============*/
        getFiscalDataAtPageLoading: getFiscalDataAtPageLoading,
        getAllFiscalData: getAllFiscalData,
        invitefiscalValue: invitefiscalValue,
        /*============ FiscalService API calls register END here ==============*/


        /*============ Dashboard START here ==============*/
        getDataForDashboardMyInboxPageLoading: getDataForDashboardMyInboxPageLoading,
        myInboxProjects: myInboxProjects,
        getDataForDashboard: getDataForDashboard,
        getDataForDashboardChartDetails: getDataForDashboardChartDetails,
        getPFChartDetailsData: getPFChartDetailsData,
        getPercentFundedChartDetailsData: getPercentFundedChartDetailsData,

        /*============ Dashboard END here ==============*/
        /* =========== Report Section Starts Here========================== */
        getReportListItems: getReportListItems,
        getReportParametersList: getReportParametersList,
        selectedParametersForReport: selectedParametersForReport,
        /* =========== Report Section END Here========================== */

        /* =========== Planning Section Starts Here========================== */
        getPAFGMasterData: getPAFGMasterData,
        searchPAFGs: searchPAFGs,
        allocatePAFG: allocatePAFG,
        savePAFGControlAmount: savePAFGControlAmount,
        getPriorityMasterData: getPriorityMasterData,
        getProjectPriorities: getProjectPriorities,
        finalizeProjectPriorities: finalizeProjectPriorities,
        saveProjectPriorities: saveProjectPriorities,
        /* =========== Planning Section END Here========================== */

        /* =========== Canging project owner section Start Here========================== */
        getDataForProjectOwnerPageLoading: getDataForProjectOwnerPageLoading,
        inviteOwnerList: inviteOwnerList,
        searchProjectOwner: searchProjectOwner,
        /* =========== Canging project owner section Section END Here========================== */

        /* =========== Roles and Actions section Start Here========================== */
        getDataForRolesActionPageLoading: getDataForRolesActionPageLoading,
        inviteRoleActionList: inviteRoleActionList,
        getRoleActionData: getRoleActionData
        /* =========== Roles and Actions section Section END Here========================== */
    };
}();
