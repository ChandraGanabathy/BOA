﻿// page level name space
STEP.AppUserLogin = {};
ko.validation.rules.pattern.message = 'Invalid.';
STEP.AppUserLogin.FailureCallback = function () {
    STEP.ShowStatusMessageBoxAtFooterLogin("Service not available. Please try again later.", "Error");
};

var UserRoleHierarchyModel = function (userRoleId, hierarchyDataId, hierarchyName, hierarchyType) {
    var self = this;
    self.UserRoleId = ko.observable(userRoleId);
    self.HierarchyDataId = ko.observable(hierarchyDataId);
    self.HierarchyName = ko.observable(hierarchyName);
    self.HierarchyType = ko.observable(hierarchyType);
};

STEP.AppUserLogin.LoginViewModel = function (actionsList) {
    var self = this;
    self.userPreferenceData = ko.observableArray();
    self.Email_Id = ko.observable('HQ_Admin@amc.army.mil').extend({ required: { message: 'Please enter Email Address' } });
    self.Password = ko.observable('step').extend({ required: { message: 'Please enter Password' } });
    self.RememberMe = ko.observable();
    self.UserRoleData = ko.observableArray();
    self.SelectedRole = ko.observable();
    self.UserData = ko.observable();
    self.IsLoginSucessed = ko.observable(false);
    self.DistinctRoles = ko.observableArray();
    self.FilterRoles = ko.observableArray();
    self.HierarchyType = ko.observable();
    self.SelectedUserRole = ko.observable();

    self.SignIn = function () {
        self.UserRoleData([]);
        self.UserData([]);
        self.CancelPopup();
        if (self.errors().length == 0) {
            STEP.dataService.signIn(self, function (data) {
                $('#footerLogin').hide();
                if (data != null && data.IsLoginSucessed) {
                    if (data.User_Status_Key == 'IACT') {
                        STEP.ShowStatusMessageBoxAtFooterLogin("You are inactivated from the system. Please contact the Support", "Error");
                        return;
                    }
                    self.UserData(data);
                    if (data.User_Role.length > 1) {
                        self.UserRoleData([]);
                        ko.utils.arrayForEach(data.User_Role, function (urItem) {
                            self.UserRoleData.push(urItem);
                        });
                        var roleTypes = ko.utils.arrayMap(self.UserRoleData(), function (item) { return item.Role.Name; });
                        var distinctRoles = ko.utils.arrayGetDistinctValues(roleTypes).sort();
                        ko.utils.arrayForEach(distinctRoles, function (rItem) {
                            self.DistinctRoles.push(rItem);
                        });
                        $('#popupRoleSelection').modal('show');
                        $('#footerPopup').hide();
                    } else if (data.User_Role.length == 0 && self.UserData().User_Status_Key == 'ACTV') {
                        STEP.ShowStatusMessageBoxAtFooterLogin("You are not having any active role in the system. Please contact the Support Team.", "Error");
                        return;
                    }
                    else {
                        if (self.UserData().User_Status_Key == 'INVT') {
                            var qstring = { "Id": data.Id, "IsUserInfo": "true", "Status": "true", "ControllerName": "UserManagement", "ActionName": "UserInfo" };
                            STEP.dataService.AjaxPostWithoutQuerystring('/Home/AjaxPostWithoutQuerystring', qstring);
                        } else if (self.UserData().User_Status_Key == 'ACTV') {
                            window.location.href = STEP.UrlBase + "/Home/Index";
                            //window.location.href = STEP.UrlBase + "/Index.html";
                            //window.location.href = STEP.UrlBase + "/Home/LegacyPage/?page=indexAngular";
                        } else if (self.UserData().User_Status_Key == 'IACT' || self.UserData().User_Status_Key == 'TERM') {
                            STEP.ShowStatusMessageBoxAtFooterLogin("You are inactivated from the system. Please contact the Support", "Error");
                            return;
                        }
                    }
                }
                else {
                    STEP.ShowStatusMessageBoxAtFooterLogin("Unable to Login. The user name or password provided is incorrect.", "Error");
                }
            }, STEP.AppUserLogin.FailureCallback);
        }
        else {
            var li = '';
            ko.utils.arrayMap(self.errors(), function (errorItem) {
                li = li + '<li>' + errorItem + '</li>';
            });
            STEP.ShowStatusMessageBoxAtFooterLogin(li, "Error");
        }
    };

    self.CancelPopup = function () {
        $('#popupRoleSelection').modal('hide');
        $('#footerPopup').hide();
        self.DistinctRoles([]);
        self.FilterRoles([]);
        self.SelectedRole(null);
        self.UserRoleData([]);
        STEP.DisapperaFooter();
        self.SelectedUserRole(null);
    };

    self.GoToApplication = function () {
        if (self.SelectedRole() == undefined || self.SelectedRole() == null) {
            STEP.ShowStatusMessageBoxAtFooterAtPopup(" </br> Please select a Role to proceed.", "Error", "footerPopup", "statusMessageRoleSelection", "divStatusBarRoleSelection");
            return;
        }
        var currentUserRoleId = undefined;
        if (self.FilterRoles() != undefined && self.FilterRoles().length == 1) {
            currentUserRoleId = self.FilterRoles()[0].UserRoleId();
        }
        if (self.FilterRoles() != undefined && self.FilterRoles().length > 1) {
            if (self.SelectedUserRole() == undefined) {
                STEP.ShowStatusMessageBoxAtFooterAtPopup(" </br> Please select a Property to proceed.", "Error", "footerPopup", "statusMessageRoleSelection", "divStatusBarRoleSelection");
                return;
            }
            currentUserRoleId = self.SelectedUserRole();
        }
        if (self.UserData().User_Status_Key == 'IACT') {
            STEP.ShowStatusMessageBoxAtFooterLogin("You are inactivated from the system. Please contact the Support", "Error");
        }
        STEP.dataService.setCurrentUserRoleIfMore(currentUserRoleId, function (data) {
            if (data) {
                if (self.UserData().User_Status_Key == 'INVT') {
                    var qstring = { "Id": self.UserData().Id, "IsUserInfo": "true", "Status": "true", "ControllerName": "UserManagement", "ActionName": "UserInfo" };
                    STEP.dataService.AjaxPostWithoutQuerystring('/Home/AjaxPostWithoutQuerystring', qstring);
                }
                if (self.UserData().User_Status_Key == 'ACTV') {
                    window.location.href = STEP.UrlBase + "/Home/Index";
                }
            }
        });
    };

    self.SessionRedirectUrl = function () {
        STEP.dataService.getSessionTimeOutRedirectUrl(function (data) {
            window.location.href = STEP.UrlBase + data;
        });
    };

    self.ActualRoleLength = ko.observableArray();

    self.SelectRole = function (data, propertyId) {
        if (data == undefined) return;
        $('#footerPopup').hide();
        self.FilterRoles([]);
        var filterRoles = ko.utils.arrayFilter(self.UserRoleData(), function (item) {
            return item.Role.Name == data;
        });

        if (filterRoles != undefined && filterRoles.length > 1) {
            ko.utils.arrayForEach(filterRoles, function (urItem) {
                var userRoleHierarchyModel = new UserRoleHierarchyModel(urItem.Id, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Id, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Name, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Hierarchy_Level_Key);
                self.FilterRoles.push(userRoleHierarchyModel);
            });
            if (self.FilterRoles()[0].HierarchyType() == STEP.HierarchyLevel.Installation) {
                self.HierarchyType('Installation');
            }
            if (self.FilterRoles()[0].HierarchyType() == STEP.HierarchyLevel.MajorSubCommand) {
                self.HierarchyType('Major SubCommand');
            }
        } else {
            ko.utils.arrayForEach(filterRoles, function (urItem) {
                var userRoleHierarchyModel = new UserRoleHierarchyModel(urItem.Id, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Id, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Name, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Hierarchy_Level_Key);
                self.FilterRoles.push(userRoleHierarchyModel);
            });
        }
        return true;
    };

    self.ChangeRole = function () {
        STEP.dataService.changeRole(function (data) {
            self.UserData(data);
            self.UserRoleData([]);
            ko.utils.arrayForEach(data.User_Role, function (urItem) {
                self.UserRoleData.push(urItem);
            });
            var roleTypes = ko.utils.arrayMap(self.UserRoleData(), function (item) { return item.Role.Name; });
            var distinctRoles = ko.utils.arrayGetDistinctValues(roleTypes).sort();
            ko.utils.arrayForEach(distinctRoles, function (rItem) {
                self.DistinctRoles.push(rItem);
            });
            $('#popupRoleSelection').modal('show');
            $('#footerPopup').hide();

        });
    };

    self.showPage = function (controllerName, actionName, typeKey) {
        var flag = false;
        var actionItem = $.grep(actionsList, function (item) {
            return item.Action_Name == actionName && item.Controller_Name == controllerName && item.Type_Key == typeKey;
        });
        if (actionItem != undefined && actionItem.length != 0) {
            flag = true;
        }
        return flag;
    };

    self.impersonate_Click = function () {
        STEP.dataService.rollBackImpersonation(function (userdata) {
            if (userdata != undefined) {
                window.location.href = STEP.UrlBase + '/Home/Index';
            }
        },
            function (err) {
                STEP.ShowStatusMessageBoxAtFooter("Error imps User!", "Error");
            });
    };
};

STEP.AppUserLogin.CACLoginViewModel = function () {
    var self = this;
    self.userPreferenceData = ko.observableArray();
    self.Email_Id = ko.observable('').extend({ required: { message: 'Enter a User Name' } }); //HQ_Admin@amc.army.mil
    self.Password = ko.observable('').extend({ required: { message: 'Enter a Password' } });
    self.RememberMe = ko.observable();
    self.UserRoleData = ko.observableArray();
    self.SelectedRole = ko.observable();
    self.UserData = ko.observable();
    self.IsLoginSucessed = ko.observable(false);
    self.DistinctRoles = ko.observableArray();
    self.FilterRoles = ko.observableArray();
    self.HierarchyType = ko.observable();
    self.SelectedUserRole = ko.observable();

    self.SignIn = function () {
        self.UserRoleData([]);
        self.UserData([]);

        STEP.dataService.CACsignIn(self, function (data) {
            if (data != null) {
                self.UserData(data);
                if (data.User_Role.length > 1 && self.UserData().User_Status_Key == 'ACTV') {
                    self.UserRoleData([]);
                    ko.utils.arrayForEach(data.User_Role, function (urItem) {
                        self.UserRoleData.push(urItem);
                    });
                    console.log("UserRoleData", self.UserRoleData());
                    var roleTypes = ko.utils.arrayMap(self.UserRoleData(), function (item) { return item.Role.Name; });
                    var distinctRoles = ko.utils.arrayGetDistinctValues(roleTypes).sort();
                    ko.utils.arrayForEach(distinctRoles, function (rItem) {
                        self.DistinctRoles.push(rItem);
                    });
                    $('#popupRoleSelection').modal('show');
                    $('#footerPopup').hide();
                } else if (data.User_Role.length == 0 && self.UserData().User_Status_Key == 'ACTV') {
                    STEP.ShowStatusMessageBoxAtFooterLogin("You are not having any active role in the system. Please contact the Support Team.", "Error");
                    return;
                } else {
                    if (self.UserData().User_Status_Key == 'INVT') {
                        var qstring = { "Id": data.Id, "IsUserInfo": "true", "Status": "true", "ControllerName": "UserManagement", "ActionName": "UserInfo" };
                        STEP.dataService.AjaxPostWithoutQuerystring('/Home/AjaxPostWithoutQuerystring', qstring);
                    } else if (self.UserData().User_Status_Key == 'ACTV') {
                        window.location.href = STEP.UrlBase + "/Home/Index";
                    } else if (self.UserData().User_Status_Key == 'IACT' || self.UserData().User_Status_Key == 'TERM') {
                        STEP.ShowStatusMessageBoxAtFooterLogin("Your account is in Inactive status. Please contact support team.", "Error");
                        return;
                    }
                }
            } else {
                //STEP.ShowStatusMessageBoxAtFooterLogin("Unable to Login. Please contact support team.", "Error");
                window.location.href = STEP.UrlBase + "/UserManagement/AppUserLogin";
            }
        }, STEP.AppUserLogin.FailureCallback);
    };

    self.SignIn();

    self.CancelPopup = function () {
        $('#popupRoleSelection').modal('hide');
        $('#footerPopup').hide();
        self.DistinctRoles([]);
        self.FilterRoles([]);
        self.SelectedRole(null);
        self.UserRoleData([]);
        STEP.DisapperaFooter();
        self.SelectedUserRole(null);
    };

    self.GoToApplication = function () {
        if (self.SelectedRole() == undefined || self.SelectedRole() == null) {
            STEP.ShowStatusMessageBoxAtFooterAtPopup(" </br> - No Role selected. Please select a Role to proceed.", "Error", "footerPopup", "statusMessageRoleSelection", "divStatusBarRoleSelection");
            return;
        }
        var currentUserRoleId = undefined;
        if (self.FilterRoles() != undefined && self.FilterRoles().length == 1) {
            currentUserRoleId = self.FilterRoles()[0].UserRoleId();
        }
        if (self.FilterRoles() != undefined && self.FilterRoles().length > 1) {
            if (self.SelectedUserRole() == undefined) {
                STEP.ShowStatusMessageBoxAtFooterAtPopup(" </br> - No Property selected. Please select a Property to proceed.", "Error", "footerPopup", "statusMessageRoleSelection", "divStatusBarRoleSelection");
                return;
            }
            currentUserRoleId = self.SelectedUserRole();
        }
        STEP.dataService.setCurrentUserRoleIfMore(currentUserRoleId, function (data) {
            if (data) {
                if (self.UserData().User_Status_Key == 'INVT') {
                    var qstring = { "Id": self.UserData().Id, "IsUserInfo": "true", "Status": "true", "ControllerName": "UserManagement", "ActionName": "UserInfo" };
                    STEP.dataService.AjaxPostWithoutQuerystring('/Home/AjaxPostWithoutQuerystring', qstring);
                }
                if (self.UserData().User_Status_Key == 'ACTV') {
                    window.location.href = STEP.UrlBase + "/Home/Index";
                }
            }
        });
    };

    self.showPage = function (controllerName, actionName, typeKey) {
        var flag = false;
        var actionItem = $.grep(actionsList, function (item) {
            return item.Action_Name == actionName && item.Controller_Name == controllerName && item.Type_Key == typeKey;
        });
        if (actionItem != undefined && actionItem.length != 0) {
            flag = true;
        }
        return flag;
    };

    self.impersonate_Click = function () {
        STEP.dataService.rollBackImpersonation(function (userdata) {
            if (userdata != undefined) {
                window.location.href = STEP.UrlBase + '/Home/Index';
            }
        },
            function (err) {
                STEP.ShowStatusMessageBoxAtFooter("Error imps User!", "Error");
            });
    };

    self.SessionRedirectUrl = function () {
        STEP.dataService.getSessionTimeOutRedirectUrl(function (data) {
            window.location.href = STEP.UrlBase + data;
        });
    };

    self.SelectedRole.subscribe(function (data) {
        if (data == undefined) return;
        $('#footerPopup').hide();
        self.FilterRoles([]);
        var filterRoles = ko.utils.arrayFilter(self.UserRoleData(), function (item) {
            return item.Role.Name == data;
        });

        if (filterRoles != undefined && filterRoles.length > 1) {
            ko.utils.arrayForEach(filterRoles, function (urItem) {
                var userRoleHierarchyModel = new UserRoleHierarchyModel(urItem.Id, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Id, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Name, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Hierarchy_Level_Key);
                self.FilterRoles.push(userRoleHierarchyModel);
            });
            if (self.FilterRoles()[0].HierarchyType() == STEP.HierarchyLevel.Installation) {
                self.HierarchyType('Installation');
            }
            if (self.FilterRoles()[0].HierarchyType() == STEP.HierarchyLevel.MajorSubCommand) {
                self.HierarchyType('Major SubCommand');
            }
        } else {
            ko.utils.arrayForEach(filterRoles, function (urItem) {
                var userRoleHierarchyModel = new UserRoleHierarchyModel(urItem.Id, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Id, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Name, urItem.User_Role_Hierarchy_Assoication[0].Hierarchy_Data.Hierarchy_Level_Key);
                self.FilterRoles.push(userRoleHierarchyModel);
            });
        }
    });
};

STEP.ShowStatusMessageBoxAtFooterLogin = function (statusMessage, severity) {
    var divStatusContainer = $(document).find('div[id="footerLogin"]');
    divStatusContainer.find("#divStatusBar").removeClass('alert alert-success');
    divStatusContainer.find("#divStatusBar").removeClass('alert alert-danger');
    divStatusContainer.find("#statusMessage").html(statusMessage);
    if (severity == 'Sucess')
        divStatusContainer.find("#divStatusBar").addClass('alert alert-success');
    else if (severity == 'Error')
        divStatusContainer.find("#divStatusBar").addClass('alert alert-danger');
    divStatusContainer.show();
};


