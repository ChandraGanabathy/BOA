﻿/// <reference path="../_references.js" />
// Global NameSpace
(function (window, undefined) {
    var STEP = window.STEP = window.STEP || {};
})(window);

/*============ Uncomment Below Line of codes when doing deployment in IIS*/
STEP.UrlBase = "";
pathArray = window.location.href.split('/');
protocol = pathArray[0];
host = pathArray[2];
name = pathArray[3];
STEP.UrlBase = protocol + '//' + host + "/" + name;
STEP.serviceBase = STEP.UrlBase + "/Api/";

//Global Variables
STEP.DateFormat = "mm/dd/yy";                     // Short Data Format
STEP.LongDateFormat = "dd/mm/yyyy hh:MM:ss:l";      // Long Date Format

// Global Knockout Validation Configuration
ko.validation.configure({
    registerExtenders: true,
    insertMessages: false,
    messagesOnModified: true,
    messageTemplate: null,
    decorateElement: true,
    errorElementClass: 'validationMessage',
    errorMessageClass: 'help-block'
});



/*============ Use below line while deveolopment in Visual studio in order to run it ,Other wise comment it */
//STEP.serviceBase = "../Api/";                     // WebAPI service path
STEP.GridPageSize = [10, 20, 50, 100, 300, 500];
STEP.TextLimit = 300;
STEP.EmailFormat = {
    Enterprise: '',
    AKO: 'us.army.mil1'
};

STEP.Page = {
    Catalog: "Catalog",
    Project: "Projects",
    Planning: "Project"
};


//Message Constants
STEP.Message = {
    DropDownText: "All",
    NoRecordsFound: "No Results found.",
    Error: "Error Occured.",
    Required: "Fields are Required",
    Failure: "Save action failed.Please try again and reach out system support if the problem persists.",
    CatalogSuccessful: "Catalog Information Saved Successfully",
    CatalogError: "Failed to Save Catalog Information",
    InviteUserError: "Failed to Save User Information",
    UserSavedUpdatedSucessful: "User Information Saved Successfully.",
    UserPreferenceSavedUpdatedSucessful: "User Preference Saved Successfully!",
    MediaUploadFiletype: "Invalid file extension",
    MediaUploadFileSize: "Attachment should not exceed the limit of 4MB.",
    UploadFileSize: "Upload file size should not exceed the limit of 4MB.",
    //ErrorComment: "Error:",
    ErrorComment: "",
    DeleteAlert: "Are you sure you want to delete this Record ?",
    //UserInActiveAlert: "Are you sure you want to Inactivate the user? ",
    //UserActiveAlert: "Are you sure you want to Activate the user? ",
    UserInActiveAlert: "Inactivate User? ",
    UserActiveAlert: "Activate User ? ",
    EmailSendAlert: "Are you sure you wish to send this email?",
    CatalogSearchError: "Catalog Search Failed due to error.",
    PrioritySuccessful: "Project Priorities updated Successfully!",
    PriorityFinalizeSuccessful: "Project Priorities got finalized!",
    ProjectSuccessful: "Project Saved Successfully",
    ApprovalProcessSuccessful: "Approval Process Saved Successfully",
    PFAGSearchError: "Planning and Control Search Failed due to error.",
    BulkExecutionSuccessful: "Funding amount saved successfully.",
    /* Report validation message 
        Added by Sankar.
        28/06/2016
    */
    RequriedRoles: "Please select atleast one role.",
    RequriedProperty: "Please select atleast one property.",
    RequriedUserStatus: "Please select atleast one user status.",
    RequriedPillar: "Please select atleast one pillar.",
    RequriedLawReg: "Please select atleast one lawreg.",
    RequriedProgramArea: "Please select atleast one program area.",
    RequriedFiscalYear: "Please select atleast one fiscal year.",
    RequriedClass: "Please select atleast one class.",
    RequriedResourceSponcer: "Please select atleast one resource sponcer.",
    RequriedFundingStatus: "Please select atleast one approval status.",
    RequriedProjectStatus: "Please select atleast one project status.",
    RequriedPB28Title: "Please select atleast one PB28 Title.",
    RequriedPB28Category: "Please select atleast one PB28 Category.",
    FiscalSavedUpdatedSucessful: "Fiscal Year Details Saved Successfully.",
    DuplicateFiscal: "Duplicate FY Should not be Created!",
    CatalogRequired: "Please select a catalog.",
    ProjectOwnerUpdateSuccessful: "Project Owner Updated Successfully.",
    ProjectOwnerUpdateFailed: "Project Owner Updation failed.",
    RoleActionUpdatedSuccessful: "Role and Action Updated Successfully. ",
    UserRoleSameInvitationAlert: "- Already assigned this selected role with same property.",
    RequriedImpacttoMission: "Please select atleast one Mission Impact.",
    PrioritizationNoRecords: "No records available for prioritization.",
    BudgetExecutionNoRecords: "No changes available for budget execution.",
    RequiredFundStatus: "Please select atleast one funding status."
};

STEP.Default = {
    Theme: "GREN",
    PageSize: "2",
    ALL: "ALL",
};

STEP.ApprovalMessage = {
    SubmitForApproval: "Project submitted for Approval",
    Approve: "Project Approved",
    DisApprove: "Project Disapproved",
};

STEP.ApprovalActions = {
    SubmitForApproval: "SUBT",
    Approve: "APPR",
    Disapprove: "DAPP",
};
STEP.ReportTypes = {
    User: "User",
    CatalogSummary: "CatalogSummary",
    CatalogDetail: "CatalogDetail",
    ProjectSummary: "ProjectSummary",
    ProjectDetail: "ProjectDetail",
    FundingSummarybyLawReg: "FSbyMLawReg",
    FundingSummarybyPb28: "FSbyPB28",
    CatalogUsageReport: "CatalogUsage",
    RoleAction: "RoleAction",
};

STEP.PageSharedKey = {
    ProjectListing: "ProjectListing",
    BudgetExecution: "BudgetExecution",
    CataLogListing: "CataLogListing",
    AddEditProject: "AddEditProject",
};

STEP.FileSize = {
    //in KB
    Logo: 5242880,
    Photo: 5242880, //For the physicians
    ProfilePhto: 5242880,
    //Media: 1048576 * 100
    Media: 1048576 * 4,
    FileManagerMedia: 1048576 * 100
};
STEP.Imagetypes = ['gif', 'png', 'jpg', 'jpeg', 'bmp'];
STEP.Videotypes = ['mp4', 'webm'];
STEP.Documentypes = ['docx', 'doc', 'xls', 'pdf', 'xlsx'];
STEP.Mediatypes = ['gif', 'png', 'jpg', 'jpeg', 'bmp', 'doc', 'docx', 'xls', 'pdf', 'webm', 'mp4', 'xlsx', 'txt'];

STEP.recordesToShow = 25;
STEP.pageCountToShow = 10;

STEP.AdminRecordsToShow = 25;
STEP.AdminpageCountToShow = 250;

STEP.RoleKey = {
    WebAdministrator: "WEBADMN",
    HQAdministrator: "HQADMN",
    HQUser: "HQUSER",
    HQReadOnlyUser: "HQREAD",
    MSCAdministrator: "MSCADMN",
    MSCUser: "MSCUSER",
    MSCReadOnlyUser: "MSCREAD",
    InstallationAdministrator: "INSTADMN",
    InstallationUser: "INSTUSER",
    InstallationReadOnlyUser: "INSTREAD",
};

STEP.HierarchyLevel = {
    HeadQuarters: "HQ",
    MajorSubCommand: "MSC",
    Installation: "INST"
};

STEP.Code = {
    StateId: 200,
};

STEP.StatusId = 1300;
STEP.Status = {
    Active: "ACTV",
    InActive: "IACT",
    Invited: "INVT",
};
STEP.ApprovalStatus = {
    FundingEligible: "FELI",
    PendingSubmission: "PRCR"
};

STEP.FundingsStatus = {
    Unfunded: "UNFU",
    Funded: "FUND",
    Obligated: "OBLI",
};

STEP.ProjectStatus = {
    Active: "ACTV",
    Completed: "CMPL",
    Discontinued: "DISC",
};
STEP.MissionToImpact = {
    Low: "ITML",
    Medium: "ITMM",
    High: "ITMH",
};

ko.bindingHandlers.autoNumeric = {
    init: function (el, valueAccessor, bindingsAccessor, viewModel) {
        var $el = $(el),
            bindings = bindingsAccessor(),
            settings = bindings.settings,
            value = valueAccessor();

        $el.autoNumeric(settings);
        $el.autoNumeric('set', parseFloat(ko.utils.unwrapObservable(value()), 10));
        $el.change(function () {
            value(parseFloat($el.autoNumeric('get'), 10));
        });
    },
    update: function (el, valueAccessor, bindingsAccessor, viewModel) {
        var $el = $(el),
            newValue = ko.utils.unwrapObservable(valueAccessor()),
            elementValue = $el.autoNumeric('get'),
            valueHasChanged = (newValue != elementValue);

        if ((newValue === 0) && (elementValue !== 0) && (elementValue !== "0")) {
            valueHasChanged = true;
        }

        if (valueHasChanged) {
            if (elementValue == '' || elementValue == undefined)
                $el.autoNumeric('set', 0);
            else
                $el.autoNumeric('set', newValue);
        }
        if (valueHasChanged) {
            if (newValue == undefined) {
                newValue = 0;
            }
            $el.autoNumeric('set', newValue);
            setTimeout(function () {
                $el.change()
            }, 0);
        }

    }
};

$(document).ready(function () {
    $(document).ajaxStop(function () {
        $('#stepProcessingDialog').modal('hide');
    });
    $(document).ajaxStart(function () {
        $('#stepProcessingDialog').modal('show');
    });
    $('.scroll-pane').jScrollPane();
    $(".spaceRestriction").keypress(function (e) {
        if (e.which == 32) {
            return false;
        }
        return true;
    });

    // Added code to make characters to be uppercase once we leave the box
    $('.upperCaseTextBox').focusout(function () {
        // Uppercase-ize contents
        this.value = this.value.toLocaleUpperCase();
    });

    $('.upperCaseSubFromTextBox').keyup(function () {
        // Uppercase-ize contents
        this.value = this.value.toLocaleUpperCase();
    });

    // Added Code to Bootstrap Data Picker control behavior for the class 
    $('.datePickerAction').datetimepicker({
        format: 'MM/DD/YYYY',
        icons: {
            previous: 'glyphicon-chevron-left',
            next: 'glyphicon-chevron-right',
        },
    });

    // Added Code for Phone Formatting Using Masked input jquery plugin
    $(".PhoneFormat").mask("999-999-9999");

    // Added Code for Zip Formatting Using Masked input jquery plugin
    $(".ZipFormat").mask("99999?-9999");

    $(".ZipFormatFiveDigit").mask("99999");

    // Added Code for Quantity Formatting Using Masked input jquery plugin
    $(".Quantity").mask("?99999");

    // Required field function
    $('.required-icon').tooltip({
        placement: 'left',
        title: 'Required field'
    });

    // Toop Tip        
    $('[data-toggle="tooltip"]').tooltip({
        'placement': 'top'
    });

    $('[data-toggle="popover"]').popover({
        trigger: 'hover',
        'placement': 'top'
    });

    $('.groupOfTexbox').keypress(function (event) {
        return isNumber(event, this);
    });
});

function isNumber(evt, element) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (
        (charCode != 45 || $(element).val().indexOf('-') != -1) &&      // “-” CHECK MINUS, AND ONLY ONE.
        (charCode != 46 || $(element).val().indexOf('.') != -1) &&      // “.” CHECK DOT, AND ONLY ONE.
        (charCode < 48 || charCode > 57))
        return false;
    return true;
}

// Application Navigation Path
STEP.NavigateTo = {
    LoginPage: "../AppUser/AppUserLogin",
};

STEP.Sorting = function (Lists, columnName, order) {
    Lists.sort(function (a, b) {
        var va = (eval("a." + columnName) === null) ? "" : eval("a." + columnName),
            vb = (eval("b." + columnName) === null) ? "" : eval("b." + columnName);
        if (order) {
            return va > vb ? 1 : (va === vb ? 0 : -1);
        } else {
            return va < vb ? 1 : (va === vb ? 0 : -1);
        }
    });
};

STEP.SortingForObservableProperty = function (Lists, columnName, order) {
    Lists.sort(function (a, b) {
        var va = (eval("a." + columnName) === null) ? "" : eval("a." + columnName),
            vb = (eval("b." + columnName) === null) ? "" : eval("b." + columnName);
        if (order) {
            return va() > vb() ? 1 : (va() === vb() ? 0 : -1);
        } else {
            return va() < vb() ? 1 : (va() === vb() ? 0 : -1);
        }
    });
};

STEP.SortingNumber = function (lists, columnName, order) {
    lists.sort(function (a, b) {
        var va = (a[columnName] === null) ? "" : "" + a[columnName],
            vb = (b[columnName] === null) ? "" : "" + b[columnName];
        if (order)
            return va - vb;
        else
            return vb - va;
    });
};

STEP.SortingDate = function (lists, columnName, order) {
    var datea = a.split(/[\/-]/);
    var dateb = b.split(/[\/-]/);
    var x = (datea[2] + datea[1] + datea[0]) * 1;
    var y = (dateb[2] + dateb[1] + dateb[0]) * 1;
    if (isNaN(x)) { x = 0; }
    if (isNaN(y)) { y = 0; }
    if (order)
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    else
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
};

//Global Common Functions


STEP.FormattingDate = function (dateInput) {
    return new Date(dateInput).format("mm/dd/yyyy");
};
//MessageBox Function
STEP.showMessageBox = function (message, okCallBack) {
    var container = $(document).find('div[id="stepPopupDialog"]');
    container.find("#popupMessageDiv").html(message);
    var okBtn = container.find("#popupOKBtn").unbind('click').bind('click', function () {
        if (okCallBack != undefined) {
            okCallBack();
            $('#stepPopupDialog').modal('hide');
        } else {
            $('#stepPopupDialog').modal('hide');
        }
    });
    $('#stepPopupDialog').modal('show');
};
STEP.showMessageBoxYesOrNo = function (message, okCallBack) {
    var container = $(document).find('div[id="stepPopupDialogYesOrNo"]');
    container.find("#popupMessageDivYesOrNo").html(message);
    var okBtn = container.find("#popupOKBtnYesOrNo").unbind('click').bind('click', function () {
        if (okCallBack != undefined) {
            okCallBack();
            $('#stepPopupDialogYesOrNo').modal('hide');
        } else {
            $('#stepPopupDialogYesOrNo').modal('hide');
        }
    });
    $('#stepPopupDialogYesOrNo').modal('show');
};

STEP.showMessageBoxOK = function (message, okCallBack) {
    var container = $(document).find('div[id="stepPopupDialogOK"]');
    container.find("#popupMessageDivOK").html(message);
    var okBtn = container.find("#popupOKBtnOK").unbind('click').bind('click', function () {
        if (okCallBack != undefined) {
            okCallBack();
            $('#stepPopupDialogOK').modal('hide');
        } else {
            $('#stepPopupDialogOK').modal('hide');
        }
    });
    $('#stepPopupDialogOK').modal('show');
};

STEP.ShowStatusMessageBoxAtFooter = function (statusMessage, severity, showAddtionalInfo) {
    if (severity == 'Error') {
        if (showAddtionalInfo == undefined || showAddtionalInfo == true) {
            statusMessage = STEP.Message.ErrorComment + statusMessage;
        }
    }

    var divStatusContainer = $(document).find('div[id="footer"]');
    divStatusContainer.find("#statusMessage").html(statusMessage);
    if (severity == 'Sucess')
        divStatusContainer.find("#divStatusBar").addClass('alert alert-success').removeClass('alert alert-danger');
    else if (severity == 'Error')
        divStatusContainer.find("#divStatusBar").addClass('alert alert-danger').removeClass('alert alert-success');
    if (severity == 'Sucess')
        divStatusContainer.find("#divStatusBar").addClass('alert alert-success');
    else if (severity == 'Error')
        divStatusContainer.find("#divStatusBar").addClass('alert alert-danger');
    divStatusContainer.show();
};

STEP.ShowStatusMessageBoxAtFooterAtPopup = function (statusMessage, severity, divPopupId, divStatusId, divStatusBarId) {
    statusMessage = STEP.Message.ErrorComment + statusMessage;
    var divStatusContainer = $(document).find('div[id=' + divPopupId + ']');
    divStatusContainer.find('#' + divStatusId).html(statusMessage);
    if (severity == 'Sucess')
        divStatusContainer.find('#' + divStatusBarId).addClass('alert alert-success').removeClass('alert alert-danger');
    else if (severity == 'Error')
        divStatusContainer.find('#' + divStatusBarId).addClass('alert alert-danger').removeClass('alert alert-success');
    if (severity == 'Sucess')
        divStatusContainer.find('#' + divStatusBarId).addClass('alert alert-success');
    else if (severity == 'Error')
        divStatusContainer.find('#' + divStatusBarId).addClass('alert alert-danger');
    divStatusContainer.show();
};


STEP.DisapperaFooter = function () {
    $(document).find('div[id="footer"]').hide();
};


//Confirmation Dialog Function
STEP.showConfirmationBox = function (message, okCallBack, cancelCallBack) {
    $.blockUI.defaults.css = {};
    var container = $(document).find('div[id="stepConfirmationDialog"]');
    container.find("#confirmationMessageDiv").html(message);
    container.find("#confirmationOKBtn").unbind('click').bind('click', function () {
        if (okCallBack != undefined) {
            okCallBack();
            $.unblockUI();
        } else {
            $.unblockUI();
        }
    });
    container.find("#confirmationCancelBtn").unbind('click').bind('click', function () {
        if (cancelCallBack != undefined) {
            cancelCallBack();
        } else {
            $.unblockUI();
        }
    });

    var widowHeight = $(window).height();
    $.blockUI({
        message: container,
        css: { top: '0%', left: '0%', margin: (widowHeight * .25) + 'px 30%', width: '40%', height: '50%' }
    });
};

STEP.GetCurrentDateTime = function () {
    return new Date().format(STEP.LongDateFormat);
};

STEP.GetCurrentDate = function () {
    return new Date().format("mm/dd/yyyy");
};

ko.bindingHandlers.bindDate = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel) {
        var x = valueAccessor();
        // var parseDate = new Date(dateStr);
        if (viewModel[x] == "" || viewModel[x] == undefined || viewModel[x] == null)
            viewModel[x] = "";
        else
            viewModel[x] = dateFormat(viewModel[x], "mm/dd/yyyy");

        //dateFormattedStr = parseDate != null ? dateFormat(parseDate, "mm/dd/yyyy") : '';
        //element.innerHTML = dateFormattedStr;
    },
    update: function (element, valueAccessor, allBindingsAccessor, viewModel) {
        //var x = valueAccessor();
        //if (viewModel[x] == "" || viewModel[x] == undefined || viewModel[x] == null)
        //    viewModel[x] = "";
        //else
        //    viewModel[x] = dateFormat(viewModel[x], "mm/dd/yyyy"); 

    }
};

ko.bindingHandlers.readOnly = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor());
        if (value) {
            element.setAttribute("readOnly", true);
        } else {
            element.removeAttribute("readOnly");
        }
    }
};

ko.extenders.numeric = function (target, precision) {
    //create a writeable computed observable to intercept writes to our observable
    var result = ko.computed({
        read: target,  //always return the original observables value
        write: function (newValue) {
            var current = target(),
                roundingMultiplier = Math.pow(10, precision),
                newValueAsNum = isNaN(newValue) ? 0 : parseFloat(+newValue),
                valueToWrite = Math.round(newValueAsNum * roundingMultiplier) / roundingMultiplier;

            //only write if it changed
            if (valueToWrite !== current) {
                target(valueToWrite != 0 ? valueToWrite : "");//
            } else {
                //if the rounded value is the same, but a different value was written, force a notification for the current field
                if (newValue !== current) {
                    target.notifySubscribers(valueToWrite);
                }
            }
        }
    });
    //initialize with current value to make sure it is rounded appropriately
    result(target());
    //return the new computed observable
    return result;
};

var textOnly = function (target) {
    if (target == undefined || target == "" || target == null)
        return true;
    if (!(target.match(/[^a-zA-Z ]/g))) {
        return true;
    } else {
        return false;
    }
};
var alphaNumeric = function (target) {
    if (target == undefined || target == "" || target == null)
        return true;
    if (!(target.match(/[^a-zA-Z0-9 ]/g))) {
        return true;
    } else {
        return false;
    }
};

var alphaNumericOnly = function (target) {
    if (target == undefined || target == "" || target == null)
        return true;
    if (!(target.match(/[^a-zA-Z0-9]/g))) {
        return true;
    } else {
        return false;
    }
};

var alphaNumericDotHypen = function (target) {
    if (target == undefined || target == "" || target == null)
        return true;
    if (!(target.match(/[^a-zA-Z0-9-. ]/g))) {
        return true;
    } else {
        return false;
    }
};

var alphaNumericHypen = function (target) {
    if (target == undefined || target == "" || target == null)
        return true;
    if (!(target.match(/[^a-zA-Z0-9- ]/g))) {
        return true;
    } else {
        return false;
    }
};
var alphaNumericSpecial = function (target) {
    if (target == undefined || target == "" || target == null)
        return true;
    if (!(target.match(/[^a-zA-Z0-9-.;:^ ]/g))) {
        return true;
    } else {
        return false;
    }
};
var alphaSpecial = function (target) {
    if (target == undefined || target == "" || target == null)
        return true;
    if (!(target.match(/[^a-zA-Z-.;:^ ]/g))) {
        return true;
    } else {
        return false;
    }
};


var decimalValue = function (target, params) {
    if (target == undefined || target == "" || target == null)
        return true;
    var itemstring = target.toString();
    var number = itemstring.split(".");
    if (number.length > 1) {
        if ((number[0].length > 0 && number[0].length <= params.numberlength) && (number[1].length >= 0 && number[1].length <= params.decimallength)) {
            return true;
        } else {
            return false;
        }
    } else {
        if (number[0].length > 0 && number[0].length <= params.numberlength) {
            return true;
        } else {
            return false;
        }
    }
};

var numericPattern = function (target, params) {
    if (target == undefined || target == "" || target == null)
        return true;
    var itemstring = target.toString();
    var number = itemstring.split(".");
    if (number.length > 1) {
        if ((number[0].length > 0 && number[0].length <= params.numberlength) || (number[1].length >= 0 && number[1].length <= params.decimallength)) {
            return true;
        } else {
            return false;
        }
    } else {
        if (number[0].length > 0 && number[0].length <= params.numberlength) {
            return true;
        } else {
            return false;
        }
    }
};

var numericPatternTotalDisposalCost = function (target, params) {
    if (target == undefined || target == "" || target == null)
        return true;
    var itemstring = target.toString();
    var number = itemstring.split(".");
    if (number.length > 1) {
        if ((number[0].length > 0 && number[0].length <= params.numberlength) && (number[1].length >= 0 && number[1].length <= params.decimallength)) {
            return true;
        } else {
            return false;
        }
    } else {
        if (number[0].length > 0 && number[0].length <= params.numberlength) {
            return true;
        } else {
            return false;
        }
    }
};

// Convert JSON Date
ko.bindingHandlers.jsondateFormat = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel) {
        var jsonDate = valueAccessor();
        var value = new Date(parseInt(jsonDate().substr(6)));
        var ret = value.getMonth() + 1 + "/" + value.getDate() + "/" + value.getFullYear();
        element.setAttribute('value', ret);
    },
    update: function (element, valueAccessor, allBindingsAccessor, viewModel) {
    }
};

var CodeValueModel = function (codeId, codeValue, codeValueDescription) {
    this.codeId = ko.observable(codeId);
    this.codeValue = ko.observable(codeValue);
    this.codeValueDescription = ko.observable(codeValueDescription);
};


STEP.GetQueryStringByName = function (name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
};

ko.bindingHandlers.money = {

    init: function (element, valueAccessor, allBindingsAccessor, viewModel) {

        $(element).on("keydown", function (event) {
            // Allow: backspace, delete, tab, escape, and enter

            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
                // Allow: Ctrl+A
                (event.keyCode == 65 && event.ctrlKey === true) ||
                // Allow: . ,
                (event.keyCode == 188 || event.keyCode == 190 || event.keyCode == 110) ||
                // Allow: home, end, left, right
                (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything        
                // $(element).value($(element).toFixed(2));
                return;
            }
            else {
                // Ensure that it is a number and stop the keypress
                if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                    event.preventDefault();
                }
            }
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor, viewModel) {
        var x = valueAccessor();
        if (ko.isObservable(x)) {
            var value = ko.unwrap(valueAccessor());
            $(element).text(moneyFormat(decimalMoney(value.toString()), "$"));
        }
        else {
            if (viewModel[x] == "" || viewModel[x] == undefined || viewModel[x] == null)
                viewModel[x] = 0;

            viewModel[x] = moneyFormat(decimalMoney(viewModel[x].toString()), "$");

        }

        $(element).on("focusout", function (event) {

            if (event.currentTarget.value == "")
                event.currentTarget.value = "0";
            event.currentTarget.value = moneyFormat(decimalMoney(event.currentTarget.value), "$");

        });
    }

};

ko.bindingHandlers.integer = {

    init: function (element, valueAccessor, allBindingsAccessor, viewModel) {

        $(element).on("keydown", function (event) {
            // Allow: backspace, delete, tab, escape, and enter

            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
                // Allow: Ctrl+A
                (event.keyCode == 65 && event.ctrlKey === true) ||
                // Allow: home, end, left, right
                (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything        
                // $(element).value($(element).toFixed(2));
                return;
            }
            else {
                // Ensure that it is a number and stop the keypress
                if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                    event.preventDefault();
                }
            }
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor, viewModel) {
        var x = valueAccessor();
        if (viewModel[x] == "" || viewModel[x] == undefined || viewModel[x] == null)
            viewModel[x] = 0;

    }

};

function AvoidSpace(event) {
    var k = event ? event.which : window.event.keyCode;
    if (k == 32) return false;
    return true;
}

function moneyFormat(n, currency) {
    return currency + " " + n.toString().replace(/./g, function (c, i, a) {
        return i > 0 && c !== "." && (a.length - i) % 3 === 0 ? "," + c : c;
    });
}

function decimalMoney(decimalString) {
    var itemstring = "0";
    if (decimalString == undefined || decimalString == "" || decimalString == null)
        itemstring = "0";
    else
        itemstring = decimalString.toString();
    return parseFloat(itemstring.split('$').join('').split(',').join(''));

}

//Validate Date

function IsNumberValid(input) {
    if ($.isNumeric(input)) {
        return true;
    } else {
        return false;
    }
}

function IsDate(input) {
    var currVal = input;
    if (currVal == '')
        return false;

    //Declare Regex  
    var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;
    var dtArray = currVal.match(rxDatePattern); // is format OK?

    if (dtArray == null)
        return false;

    //Checks for mm/dd/yyyy format.
    dtMonth = dtArray[1];
    dtDay = dtArray[3];
    dtYear = dtArray[5];

    if (dtMonth < 1 || dtMonth > 12)
        return false;
    else if (dtDay < 1 || dtDay > 31)
        return false;
    else if ((dtMonth == 4 || dtMonth == 6 || dtMonth == 9 || dtMonth == 11) && dtDay == 31)
        return false;
    else if (dtMonth == 2) {
        var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
        if (dtDay > 29 || (dtDay == 29 && !isleap))
            return false;
    }
    return true;
}

