﻿/// <reference path="jquery-1.7.1-vsdoc.js" />

$.extend({
    getUrlVars: function () {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            if (hash[1] != undefined) vars[hash[0]]=hash[1].replace(new RegExp("[\\[\\]?*+|{}\\\\()@.\n\r]", "g"), " ");   
        }
        return vars;
    },
    getUrlVar: function (name) {
        return $.getUrlVars()[name];
    },
    getAbsolutePath: function () {
        return window.location.host + '/' + window.location.pathname.split('/')[1];
    },

    log: function (msg) {
        if (window.console) {
            console.log(msg);
        }
    },
    
    isEmpty: function(value) {
        return (value === undefined || value == null || value.length <= 0) ? true : false;
    }
});